Gesture Capture. Upload this zip as app.zip to GitHub; the workflow builds the APK.
