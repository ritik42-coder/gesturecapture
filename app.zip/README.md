Gesture Capture. Upload this zip as app.zip to GitHub; the workflow builds the APK.

Volume bar (Style tab -> Volume bar)
- 12 animated styles: Water, RGB Neon, Red Pill, Equalizer, Lava, Aurora Glass, Candy, Plasma Flow, Neon Dial, Liquid Orb, Activity Rings, Orbit.
- Show: Default (system panel), My bar (replaces it), Both.
- Customize: 8 quick looks, 6 palettes + RGB cycle + app accent + 2 custom colors, solid/gradient, position (left/right/center/top/bottom), distance from edge, size, stay time, speed, glow, roundness, opacity, dark/light panel, haptics, number label.
- Drag the bar on screen to change volume. Needs the Accessibility service enabled.

Dynamic Island (Island tab)
- Colour: 13 presets (Black, Midnight, Graphite, Glass, Accent, RGB, Aurora, Neon, Lava, Candy, Galaxy, Ice) or three colours of your own.
- Motion: Still, Flow (the gradient slides), RGB cycle (the whole palette rotates through the spectrum), Aurora drift, Pulse and Sweep — plus a coloured glow, a hairline border, breathing while idle, corner rounding (0 = full pill), opacity and motion speed.
- Hybrid of a nav bar and a dynamic island. Idle pill shows time + battery around the camera. Tap or swipe down = quick dock (Back, Home, Recents, Notifications, Quick settings, Screenshot, Lock, Torch, Power menu, Hotspot, Bluetooth; pick up to 8). Swipe up closes it.
- Music: album art, title, artist, seek bar, prev / play-pause / next, animated equalizer, glow from the artwork. Swipe left/right on the compact pill to skip tracks. Needs Notification access (Island tab -> Access for new features).
- Hotspot: shows on/off and number of connected devices; tap for the list. Android does not give apps device names, so nickname each device in Island tab -> Hotspot devices. Needs Location / Nearby devices permission.
- Also: Bluetooth connect/disconnect, ringer mode (silent / vibrate / sound), low battery, plus the existing recording, call, message, charging and volume states.

Volume bar extras
- Tap the small arrow on the bar to expand it into all volume bars (Media, Ring, Alerts, System) with an animated open/close. Works with every style, including the dials.
- Holding a volume key keeps changing the volume (the service repeats the step itself; if Android repeats on its own, it stands down so nothing doubles).

Gesture library: draw a letter (Gestures tab -> Draw pad)
- Draw one stroke on the pad and the letter's action runs: C opens the camera, W opens WhatsApp, O starts recording, an arrow goes back / skips track / changes volume. One tap on "Draw pack" in Quick setup sets those five for you.
- Letters: C O S W M V U N Z L. Arrows: left, right, up, down. Matching happens on the phone, so it works offline and nothing leaves the device.
- There is no floating button on screen any more. Drawing is opened by a gesture on the edge grip: slide the grip up or down and the Draw panel slides out, hold the grip for the full-screen pad, or set any gesture to "Draw pad". The pad is also in the edge panel (Tools).
- When a letter is recognised the pad lifts and fades out and the action runs, so the jump into the app feels like one move.

Premium extras (Premium tab)
- Edge lighting: when a notification arrives the rim of the screen comes alive and fades away by itself. Nine effects — Glow, Multicolour, Spotlight, Eclipse, Echo, Glitter, Bubbles, Hearts, Fireworks — with your own two colours, rim width, speed, stay time and optional vibration. Touch passes straight through, so nothing is blocked. There is a live preview in the settings page.
- Charging animation: plug the cable in and the screen lights up while your battery fills. Six looks — Ring, MagSafe (frosted ring, pulse waves, orbiting sparks), Cosmos (particle vortex into a glowing core), Water (liquid fills to your level with a sloshing surface and bubbles), Prism (glass shards and a laser sweep) and Aurora (polar ribbons with rising embers). Each one uses your two colours, speed and stay time, and there is a live preview.
- Glance: a dim clock, date and battery strip. It appears when you wake the screen while charging and when you plug in, then fades after a few seconds. Tap it to dismiss. Stay time, dimness and height on screen are adjustable.
- App lock: pick any apps and they ask for a PIN before they open. Leaving the app locks it again. The PIN is 4-8 digits, kept in this app's private storage on the phone, never sent anywhere. Default is 1234 until you set your own. Launchers, System UI, Settings and this app can never be locked, and there is always a "go home" escape.

Edge panel (Edge tab)
- The grip sits flush on the screen edge, rounded on the inside only; a "Grip distance from edge" slider lifts it if you want. Pull it and the panel follows your finger; let go and it springs into place.
- Grip gestures: pull inwards = panel, slide up/down = the Draw panel slides out, hold = full-screen draw pad, tap = panel opens.
- New Draw panel: draw one letter or arrow straight on the panel; it is recognised on the phone and its action runs, then the panel closes.
- Several panels in one, one by one, like Samsung: Apps, Draw, Actions, Compass and Tools. Swipe left / right inside the panel, dots at the bottom show where you are. Swipe down, tap outside or press X to close.
- Colour: 9 presets or any two colours of your own, plus panel opacity and corner radius.
- Animation: Slide, Spring, Elastic, Fade and Cover flow, with Fast / Normal / Slow timing, background darkening and optional background blur.
- Size: panel width, grip length, grip position, side (left or right).
- Apps panel: up to 8 shortcuts. Actions panel: torch, screenshot, timer, lock, home, back, alerts, recents, draw, settings. Compass panel: live heading from the phone's sensors. Tools panel: draw pad, timers, stopwatch, record, capture, clock and battery.
- The panel is built once and reused, and the drag only moves a layer, so opening it stays smooth.

Live charging island (Island tab)
- While the cable is in, the island keeps a small charging pill: pulsing bolt with a ripple, the battery percent and a glowing level line along the bottom edge that shimmers as it charges. Toggle: "Live charging pill while plugged in".
- Plugging in opens a rich charging island for a few seconds (animated liquid battery, power in watts, temperature, time left, energy flowing along the bar), then it shrinks into the pill.
- Swipe down (or tap) on the charging pill to open the full charging island again. Swipe up closes it. Power, temperature and time left refresh live while it is open.
- Up to 3 islands at once: for example timer + charging + music. The main pill sits left of the camera and the others sit to its right as small animated chips; tap or swipe down on a chip to open it. Island tab -> Preview -> "3 islands" shows it without needing all three.
- Wattage uses the phone's own current/voltage reading; a few phones do not report it and show a dash.

Charging alerts (Island tab)
- Charge limit alert: set a percent (Island tab -> sliders -> "Charge limit alert %", 0 = off). When charging reaches it, the island opens an alert and vibrates, so you can unplug at 80% and keep the battery healthy.
- Fully charged alert at 100%, and a "Phone is hot" alert if the battery passes 42 °C while charging.
- Unplug summary: when you pull the cable the island shows how much it charged and how long it took, for example "+34% in 52 min".
- All three can be switched off with "Charge limit, full & heat alerts". Preview: "Charge alert".

App lock (Premium tab -> App lock)
- A full premium lock screen in front of the apps you pick: animated aurora background, the app's icon in a glass ring with a breathing glow, a hand-drawn keypad whose keys stagger in, sink and glow under the finger and throw a ring of light on every tap, plus a pattern grid whose dots pop and trail a soft glow.
- First run registers you: the lock asks for a PIN (enter, then confirm) and offers a pattern instead. Nothing opens until that is done. The PIN and the pattern are stored as salted SHA-256 hashes in this app's private storage, never as plain text.
- Unlock with PIN, with a pattern (draw at least 4 dots), or with the phone's own fingerprint / face. The sensor screen is a separate opaque premium surface with a live scan animation, so the app behind is never visible while the sensor reads. Wrong tries shake the screen and buzz; five wrong tries lock the screen for 30 seconds.
- Back / Close at the top left leaves the locked app and closes it, so nothing is left open behind the lock.
- Settings: "Register a PIN", "Set a pattern", "Fingerprint & face" (toggles, plus a shortcut to the phone's biometric settings) and "Preview the lock screen", which shows the whole animation on the phone without locking anything.
- The preview page (assets/lock.html) also works on its own: open it in a browser and tap through registration, PIN, pattern and fingerprint.
- Migration: a PIN saved by an older build is still accepted, and is converted to a hash the first time it is used.
