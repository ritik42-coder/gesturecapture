Gesture Capture. Upload this zip as app.zip to GitHub; the workflow builds the APK.

Volume bar (Style tab -> Volume bar)
- 12 animated styles: Water, RGB Neon, Red Pill, Equalizer, Lava, Aurora Glass, Candy, Plasma Flow, Neon Dial, Liquid Orb, Activity Rings, Orbit.
- Show: Default (system panel), My bar (replaces it), Both.
- Customize: 8 quick looks, 6 palettes + RGB cycle + app accent + 2 custom colors, solid/gradient, position (left/right/center/top/bottom), distance from edge, size, stay time, speed, glow, roundness, opacity, dark/light panel, haptics, number label.
- Drag the bar on screen to change volume. Needs the Accessibility service enabled.

Dynamic Island (Island tab)
- Hybrid of a nav bar and a dynamic island. Idle pill shows time + battery around the camera. Tap or swipe down = quick dock (Back, Home, Recents, Notifications, Quick settings, Screenshot, Lock, Torch, Power menu, Hotspot, Bluetooth; pick up to 8). Swipe up closes it.
- Music: album art, title, artist, seek bar, prev / play-pause / next, animated equalizer, glow from the artwork. Swipe left/right on the compact pill to skip tracks. Needs Notification access (Island tab -> Access for new features).
- Hotspot: shows on/off and number of connected devices; tap for the list. Android does not give apps device names, so nickname each device in Island tab -> Hotspot devices. Needs Location / Nearby devices permission.
- Also: Bluetooth connect/disconnect, ringer mode (silent / vibrate / sound), low battery, plus the existing recording, call, message, charging and volume states.

Volume bar extras
- Tap the small arrow on the bar to expand it into all volume bars (Media, Ring, Alerts, System) with an animated open/close. Works with every style, including the dials.
- Holding a volume key keeps changing the volume (the service repeats the step itself; if Android repeats on its own, it stands down so nothing doubles).
