Gesture Capture. Upload this zip as app.zip to GitHub; the workflow builds the APK.

Volume bar (Style tab -> Volume bar)
- 12 animated styles: Water, RGB Neon, Red Pill, Equalizer, Lava, Aurora Glass, Candy, Plasma Flow, Neon Dial, Liquid Orb, Activity Rings, Orbit.
- Show: Default (system panel), My bar (replaces it), Both.
- Customize: 8 quick looks, 6 palettes + RGB cycle + app accent + 2 custom colors, solid/gradient, position (left/right/center/top/bottom), distance from edge, size, stay time, speed, glow, roundness, opacity, dark/light panel, haptics, number label.
- Drag the bar on screen to change volume. Needs the Accessibility service enabled.

Dynamic Island (Island tab)
- Hybrid of a nav bar and a dynamic island. Idle pill shows time + battery around the camera. Tap or swipe down = quick dock (Back, Home, Recents, Notifications, Quick settings, Screenshot, Lock, Torch, Power menu, Hotspot, Bluetooth; pick up to 8). Swipe up closes it.
- Music: album art, title, artist, seek bar, prev / play-pause / next, animated equalizer, glow from the artwork. Swipe left/right on the compact pill to skip tracks. Needs Notification access (Island tab -> Access for new features).
- Hotspot: shows on/off and number of connected devices; tap for the list. Android does not give apps device names, so nickname each device in Island tab -> Hotspot devices. Needs Location / Nearby devices permission.
- Also: Bluetooth connect/disconnect, ringer mode (silent / vibrate / sound), low battery, plus the existing recording, call, message, charging and volume states.

Volume bar extras
- Tap the small arrow on the bar to expand it into all volume bars (Media, Ring, Alerts, System) with an animated open/close. Works with every style, including the dials.
- Holding a volume key keeps changing the volume (the service repeats the step itself; if Android repeats on its own, it stands down so nothing doubles).

Gesture library: draw a letter (Gestures tab -> Draw pad)
- Draw one stroke on the pad and the letter's action runs: C opens the camera, W opens WhatsApp, O starts recording, an arrow goes back / skips track / changes volume. One tap on "Draw pack" in Quick setup sets those five for you.
- Letters: C O S W M V U N Z L. Arrows: left, right, up, down. Matching happens on the phone, so it works offline and nothing leaves the device.
- Always ready, no need to open this app: the blue pen button floats over every screen once the Accessibility service is on. Tap it to draw, drag it anywhere, long idle fades it back. The pad is also in the edge panel (Tools) and on any gesture set to "Draw pad".
- When a letter is recognised the pad lifts and fades out and the action runs, so the jump into the app feels like one move.

Edge panel (Edge tab)
- Premium blue by default. Pull the grip and the panel follows your finger; let go and it springs into place.
- Several panels in one, one by one, like Samsung: Apps, Actions, Compass and Tools. Swipe left / right inside the panel, dots at the bottom show where you are. Swipe down, tap outside or press X to close.
- Colour: 9 presets or any two colours of your own, plus panel opacity and corner radius.
- Animation: Slide, Spring, Elastic, Fade and Cover flow, with Fast / Normal / Slow timing, background darkening and optional background blur.
- Size: panel width, grip length, grip position, side (left or right).
- Apps panel: up to 8 shortcuts. Actions panel: torch, screenshot, timer, lock, home, back, alerts, recents, draw, settings. Compass panel: live heading from the phone's sensors. Tools panel: draw pad, timers, stopwatch, record, capture, clock and battery.
- The panel is built once and reused, and the drag only moves a layer, so opening it stays smooth.
