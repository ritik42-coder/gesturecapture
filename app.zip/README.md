Gesture Capture. Upload this zip as app.zip to GitHub; the workflow builds the APK.

Volume bar (Style tab -> Volume bar)
- 12 animated styles: Water, RGB Neon, Red Pill, Equalizer, Lava, Aurora Glass, Candy, Plasma Flow, Neon Dial, Liquid Orb, Activity Rings, Orbit.
- Show: Default (system panel), My bar (replaces it), Both.
- Customize: 8 quick looks, 6 palettes + RGB cycle + app accent + 2 custom colors, solid/gradient, position (left/right/center/top/bottom), distance from edge, size, stay time, speed, glow, roundness, opacity, dark/light panel, haptics, number label.
- Drag the bar on screen to change volume. Needs the Accessibility service enabled.

Dynamic Island (Island tab)
- Colour: 13 presets (Black, Midnight, Graphite, Glass, Accent, RGB, Aurora, Neon, Lava, Candy, Galaxy, Ice) or three colours of your own.
- Motion: Still, Flow (the gradient slides), RGB cycle (the whole palette rotates through the spectrum), Aurora drift, Pulse and Sweep — plus a coloured glow, a hairline border, breathing while idle, corner rounding (0 = full pill), opacity and motion speed.
- Hybrid of a nav bar and a dynamic island. Idle pill shows time + battery around the camera. Tap or swipe down = quick dock (Back, Home, Recents, Notifications, Quick settings, Screenshot, Lock, Torch, Power menu, Hotspot, Bluetooth; pick up to 8). Swipe up closes it.
- Music: album art, title, artist, seek bar, prev / play-pause / next, animated equalizer, glow from the artwork. Swipe left/right on the compact pill to skip tracks. Needs Notification access (Island tab -> Access for new features).
- Hotspot: shows on/off and number of connected devices; tap for the list. Android does not give apps device names, so nickname each device in Island tab -> Hotspot devices. Needs Location / Nearby devices permission.
- Also: Bluetooth connect/disconnect, ringer mode (silent / vibrate / sound), low battery, plus the existing recording, call, message, charging and volume states.

Volume bar extras
- Tap the small arrow on the bar to expand it into all volume bars (Media, Ring, Alerts, System) with an animated open/close. Works with every style, including the dials.
- Holding a volume key keeps changing the volume (the service repeats the step itself; if Android repeats on its own, it stands down so nothing doubles).

Gesture library: draw a letter (Gestures tab -> Draw pad)
- Draw one stroke on the pad and the letter's action runs: C opens the camera, W opens WhatsApp, O starts recording, an arrow goes back / skips track / changes volume. One tap on "Draw pack" in Quick setup sets those five for you.
- Letters: C O S W M V U N Z L. Arrows: left, right, up, down. Matching happens on the phone, so it works offline and nothing leaves the device.
- There is no floating button on screen any more. Drawing is opened by a gesture on the edge grip: slide the grip up or down and the Draw panel slides out, hold the grip for the full-screen pad, or set any gesture to "Draw pad". The pad is also in the edge panel (Tools).
- When a letter is recognised the pad lifts and fades out and the action runs, so the jump into the app feels like one move.

Edge panel (Edge tab)
- The grip sits flush on the screen edge, rounded on the inside only; a "Grip distance from edge" slider lifts it if you want. Pull it and the panel follows your finger; let go and it springs into place.
- Grip gestures: pull inwards = panel, slide up/down = the Draw panel slides out, hold = full-screen draw pad, tap = panel opens.
- New Draw panel: draw one letter or arrow straight on the panel; it is recognised on the phone and its action runs, then the panel closes.
- Several panels in one, one by one, like Samsung: Apps, Draw, Actions, Compass and Tools. Swipe left / right inside the panel, dots at the bottom show where you are. Swipe down, tap outside or press X to close.
- Colour: 9 presets or any two colours of your own, plus panel opacity and corner radius.
- Animation: Slide, Spring, Elastic, Fade and Cover flow, with Fast / Normal / Slow timing, background darkening and optional background blur.
- Size: panel width, grip length, grip position, side (left or right).
- Apps panel: up to 8 shortcuts. Actions panel: torch, screenshot, timer, lock, home, back, alerts, recents, draw, settings. Compass panel: live heading from the phone's sensors. Tools panel: draw pad, timers, stopwatch, record, capture, clock and battery.
- The panel is built once and reused, and the drag only moves a layer, so opening it stays smooth.
