Gesture Capture. Upload this zip as app.zip to GitHub; the workflow builds the APK.

Volume bar (Style tab -> Volume bar)
- 12 animated styles: Water, RGB Neon, Red Pill, Equalizer, Lava, Aurora Glass, Candy, Plasma Flow, Neon Dial, Liquid Orb, Activity Rings, Orbit.
- Show: Default (system panel), My bar (replaces it), Both.
- Customize: 8 quick looks, 6 palettes + RGB cycle + app accent + 2 custom colors, solid/gradient, position (left/right/center/top/bottom), distance from edge, size, stay time, speed, glow, roundness, opacity, dark/light panel, haptics, number label.
- Drag the bar on screen to change volume. Needs the Accessibility service enabled.
