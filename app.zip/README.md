Gesture Capture. Upload this zip as app.zip to GitHub; the workflow builds the APK.

Volume bar (Style tab -> Volume bar)
- 12 animated styles: Water, RGB Neon, Red Pill, Equalizer, Lava, Aurora Glass, Candy, Plasma Flow, Neon Dial, Liquid Orb, Activity Rings, Orbit.
- Show: Default (system panel), My bar (replaces it), Both.
- Customize: 8 quick looks, 6 palettes + RGB cycle + app accent + 2 custom colors, solid/gradient, position (left/right/center/top/bottom), distance from edge, size, stay time, speed, glow, roundness, opacity, dark/light panel, haptics, number label.
- Drag the bar on screen to change volume. Needs the Accessibility service enabled.

Dynamic Island (Island tab)
- Colour: 13 presets (Black, Midnight, Graphite, Glass, Accent, RGB, Aurora, Neon, Lava, Candy, Galaxy, Ice) or three colours of your own.
- Motion: Still, Flow (the gradient slides), RGB cycle (the whole palette rotates through the spectrum), Aurora drift, Pulse and Sweep — plus a coloured glow, a hairline border, breathing while idle, corner rounding (0 = full pill), opacity and motion speed.
- Hybrid of a nav bar and a dynamic island. Idle pill shows time + battery around the camera. Tap or swipe down = quick dock (Back, Home, Recents, Notifications, Quick settings, Screenshot, Lock, Torch, Power menu, Hotspot, Bluetooth; pick up to 8). Swipe up closes it.
- Music: album art, title, artist, seek bar, prev / play-pause / next, animated equalizer, glow from the artwork. Swipe left/right on the compact pill to skip tracks. Needs Notification access (Island tab -> Access for new features).
- Hotspot: shows on/off and number of connected devices; tap for the list. Android does not give apps device names, so nickname each device in Island tab -> Hotspot devices. Needs Location / Nearby devices permission.
- Also: Bluetooth connect/disconnect, ringer mode (silent / vibrate / sound), low battery, plus the existing recording, call, message, charging and volume states.

Volume bar extras
- Tap the small arrow on the bar to expand it into all volume bars (Media, Ring, Alerts, System) with an animated open/close. Works with every style, including the dials.
- Holding a volume key keeps changing the volume (the service repeats the step itself; if Android repeats on its own, it stands down so nothing doubles).

Gesture library: draw a letter (Gestures tab -> Draw pad)
- Draw one stroke on the pad and the letter's action runs: C opens the camera, W opens WhatsApp, O starts recording, an arrow goes back / skips track / changes volume. One tap on "Draw pack" in Quick setup sets those five for you.
- Letters: C O S W M V U N Z L. Arrows: left, right, up, down. Matching happens on the phone, so it works offline and nothing leaves the device.
- There is no floating button on screen any more. Drawing is opened by a gesture on the edge grip: slide the grip up or down and the Draw panel slides out, hold the grip for the full-screen pad, or set any gesture to "Draw pad". The pad is also in the edge panel (Tools).
- When a letter is recognised the pad lifts and fades out and the action runs, so the jump into the app feels like one move.

Premium extras (Premium tab)
- Edge lighting: when a notification arrives the rim of the screen comes alive and fades away by itself. Nine effects — Glow, Multicolour, Spotlight, Eclipse, Echo, Glitter, Bubbles, Hearts, Fireworks — with your own two colours, rim width, speed, stay time and optional vibration. Touch passes straight through, so nothing is blocked. There is a live preview in the settings page.
- Charging animation: plug the cable in and the screen lights up while your battery fills. Six looks — Ring, MagSafe (frosted ring, pulse waves, orbiting sparks), Cosmos (particle vortex into a glowing core), Water (liquid fills to your level with a sloshing surface and bubbles), Prism (glass shards and a laser sweep) and Aurora (polar ribbons with rising embers). Each one uses your two colours, speed and stay time, and there is a live preview.
- Glance: a dim clock, date and battery strip. It appears when you wake the screen while charging and when you plug in, then fades after a few seconds. Tap it to dismiss. Stay time, dimness and height on screen are adjustable.
- App lock: pick any apps and they ask for a PIN before they open. Leaving the app locks it again. The PIN is 4-8 digits, kept in this app's private storage on the phone, never sent anywhere. Default is 1234 until you set your own. Launchers, System UI, Settings and this app can never be locked, and there is always a "go home" escape.

Edge panel (Edge tab)
- The grip sits flush on the screen edge, rounded on the inside only; a "Grip distance from edge" slider lifts it if you want. Pull it and the panel follows your finger; let go and it springs into place.
- Grip gestures: pull inwards = panel, slide up/down = the Draw panel slides out, hold = full-screen draw pad, tap = panel opens.
- New Draw panel: draw one letter or arrow straight on the panel; it is recognised on the phone and its action runs, then the panel closes.
- Several panels in one, one by one, like Samsung: Apps, Draw, Actions, Compass and Tools. Swipe left / right inside the panel, dots at the bottom show where you are. Swipe down, tap outside or press X to close.
- Colour: 9 presets or any two colours of your own, plus panel opacity and corner radius.
- Animation: Slide, Spring, Elastic, Fade and Cover flow, with Fast / Normal / Slow timing, background darkening and optional background blur.
- Size: panel width, grip length, grip position, side (left or right).
- Apps panel: up to 8 shortcuts. Actions panel: torch, screenshot, timer, lock, home, back, alerts, recents, draw, settings. Compass panel: live heading from the phone's sensors. Tools panel: draw pad, timers, stopwatch, record, capture, clock and battery.
- The panel is built once and reused, and the drag only moves a layer, so opening it stays smooth.

Live charging island (Island tab)
- While the cable is in, the island keeps a small charging pill: pulsing bolt with a ripple, the battery percent and a glowing level line along the bottom edge that shimmers as it charges. Toggle: "Live charging pill while plugged in".
- Plugging in opens a rich charging island for a few seconds (animated liquid battery, power in watts, temperature, time left, energy flowing along the bar), then it shrinks into the pill.
- Swipe down (or tap) on the charging pill to open the full charging island again. Swipe up closes it. Power, temperature and time left refresh live while it is open.
- Up to 3 islands at once: for example timer + charging + music. The main pill sits left of the camera and the others sit to its right as small animated chips; tap or swipe down on a chip to open it. Island tab -> Preview -> "3 islands" shows it without needing all three.
- Wattage uses the phone's own current/voltage reading; a few phones do not report it and show a dash.

Charging alerts (Island tab)
- Charge limit alert: set a percent (Island tab -> sliders -> "Charge limit alert %", 0 = off). When charging reaches it, the island opens an alert and vibrates, so you can unplug at 80% and keep the battery healthy.
- Fully charged alert at 100%, and a "Phone is hot" alert if the battery passes 42 °C while charging.
- Unplug summary: when you pull the cable the island shows how much it charged and how long it took, for example "+34% in 52 min".
- All three can be switched off with "Charge limit, full & heat alerts". Preview: "Charge alert".

App lock (Premium tab -> App lock)
- A full premium lock screen in front of the apps you pick: animated aurora background, the app's icon in a glass ring with a breathing glow, a hand-drawn keypad whose keys stagger in, sink and glow under the finger and throw a ring of light on every tap, plus a pattern grid whose dots pop and trail a soft glow.
- One unlock method at a time: a 4-digit PIN or a pattern. Setting one removes the other, so the lock screen never asks which one you meant.
- Registration comes first: the first locked app asks for the PIN twice (or a pattern twice), then unlocks. Four digits, no Continue button — the fourth digit moves on by itself, and a correct PIN opens the app immediately.
- Fingerprint and face use the phone's own sensor. The sensor screen runs in its own task, so when it closes the phone goes back to the app that was locked, never to this app.
- Wrong tries shake the screen and buzz; five wrong tries lock the screen for 30 seconds with a live countdown.
- Back / Close at the top left leaves the locked app and closes it, so nothing is left open behind the lock.
- More options, all in the same card: Shuffle keypad (random digit order every unlock), Hide the app's identity (shows "Locked app"), Vibration, Re-lock after (Immediately / 5 s / 30 s / 1 min grace once you leave an app), six accent colours, "Lock everything now" and "Remove lock" (recovery, in case you forget the PIN or pattern).
- PIN and pattern are stored as salted SHA-256 hashes in this app's private storage, never as plain text.
- Preview page (assets/lock.html) shows the whole thing on the phone without locking anything; it also runs on its own in a browser.
- Build note: the sensor part uses androidx.biometric (added to app/build.gradle.kts, with android.useAndroidX=true), because the platform BiometricPrompt constructors are not public in the SDK.

New look (whole app UI)
- Dark-first premium interface: layered glass cards, hairline borders, soft depth, a gradient title bar that sticks to the top with the section name under it, and a floating nav bar with six crisp icons that slides its highlight between tabs.
- Every tab now opens with a section label, cards rise in one after another, chips and tiles answer with a ripple and a spring, and the header picks up a shadow as you scroll.
- Organised: related controls are grouped under headings (Recording, Quick tools, Start here, Draw pad, Fine-tune, All gestures, Live preview, Island, Timers, Layout, Look & motion, Appearance, On screen, Volume bar, Style, Content, Screen effects, Privacy).
- Long cards fold: tap a card's title to tuck it away and tap again to open it. The choice is remembered, and canvases re-measure when a card opens.
- Capture tab opens on a live dashboard: Accessibility, Recording, Island and App lock status, each tile tapping through to the thing it reports.
- More previews: a mini phone with the edge panel sliding in on the Edge tab, and a dim clock strip animating on the Glance card, next to the existing gesture, island, volume bar, edge lighting and charging previews.
- The app opens on the tab you last used, and light mode is still there (the moon button, or Style -> Theme).

Edge panel: paging fixed + new panels
- Paging now runs on a real scrolling container, so a swipe follows your finger instead of only showing the first panel. It snaps to the nearest page, carries momentum when you throw it, rubber-bands at the ends and buzzes on each page change.
- The footer names the panel and counts them ("CONTROLS · 2/5"), the dots track your finger live, and the first time you open it a hint says "swipe ‹ › for more panels".
- Swipe down anywhere inside the panel to close it, even on a tile or a slider.
- One-time repair: a single-page or empty panel setting from an older build is replaced by the full set, and your own choice is left alone from then on.
- Three new panels: Controls (media, ring and alarm volume sliders plus torch, mute, screenshot and record), Device (battery, power state, heat, free memory, free storage, uptime — live while open) and Timer (1/5/10/30 minute countdowns, stopwatch, stop all). They sit alongside Apps, Actions, Tools, Draw and Compass — pick any of the eight in Edge tab -> Panels.

Recent apps (Premium tab -> Recent apps, or bind any gesture to "My recents")
- Your own recents screen instead of the system one, which apps cannot replace. The accessibility service already sees every app that comes to the front, so it keeps an ordered list of what you really used — no permission asked, nothing sent anywhere.
- Full-screen surface with the same aurora background as the lock screen: app icon in a glass tile, name, and three layouts picked right inside it — Stack (a deck of overlapping cards), Grid (three across) and Carousel (large cards that lift and scale as they come to the middle).
- Cards spring in one after another, press down under the finger, open the app on tap, and swipe up to be forgotten. "Clear list" wipes the history.
- The list lives in this app's private storage, newest first, capped at 24 apps.

Fingerprint gestures (Gestures tab -> Fingerprint)
- Android reports swipes on the fingerprint sensor to an accessibility service, so a swipe up / down / left / right on the sensor can run any action you like — torch, recents, screenshot, back, anything in the action list.
- The card checks the phone first and says plainly whether the sensor reports gestures. In-screen sensors usually do not, so it shows "this sensor does not report gestures" rather than pretending to work.
- Bindings are stored per direction; each fires once per touch of the sensor with a haptic tick, and the accessibility service config now declares canRequestFingerprintGestures.

Charging show (Premium tab -> Charging show)
- When the screen goes off while the phone is charging, a full-screen show wakes the display: the clock and date, the percent, the charging status, and the time until the battery is full.
- Two modes. Brief wakes for a few seconds and then puts the screen back to sleep (5 / 8 / 12 / 20 / 30 / 60 s). Always on stays lit the whole time the cable is in: it holds the screen awake, dimmed to the level you choose, until you unplug it, double-tap it, or the battery reaches 100%.
- It also wakes when you plug the cable in with the screen already off, and it ignores the SCREEN_ON echo of its own wake-up, which used to cut the show down to a split second.
- Seven canvas styles: Port Flow (energy running up the cable into a battery with liquid waves and circuit traces), Bolt Core (a lightning bolt filling with waves, crackles and orbiting glows), Aurora Tide (layered aurora bands rising with the charge), Orbit Core (a liquid glass core with a comet progress ring, orbiting particles and inflow streaks), LED Bars (a segmented equaliser that climbs with the charge), Light Rain (a rain of light falling into a pool that rises with the charge) and Halo Pulse (rings breathing outward from a glass core that fills like a battery).
- Swipe left or right inside the show to change style; the pick is remembered. Double-tap closes it in Always-on, a single tap in Brief.
- Screen dimness in Always on goes from 2% to 60%. The burn-in guard nudges the clock and the percent a few pixels every 40 seconds, and Always on draws at about 30 fps (far less once the battery is full) so an all-night show stays cheap.
- The readout also carries the battery temperature and voltage, and names the source (AC / USB / Wireless).
- Time until full is measured from the charge rate the app has seen (level change over time); until there is enough history it falls back to a sane estimate.
- Off by default. A dismissal holds until the cable comes out, so it never fights you: 45 seconds of quiet after a Brief show, and it stops at once if the cable is pulled.

Samsung nav bar (Island tab -> Style)
- Two styles, one at a time: Dynamic Island (top, around the camera) or Samsung nav bar (bottom). Switching rebuilds the pill, so the two can never show together. The master On switch and every setting below the style (colour, motion, glow, haptics, features) are shared.
- The nav bar is the same island anchored to the bottom. Idle: Recents, Home and Back drawn in the Samsung style (three bars, a rounded pill, a chevron) with a press-down spring on each button. Order can be Recents-Home-Back or Back-Home-Recents.
- Tap a button to use it. Hold Home for the assistant, hold Recents for split screen. Recents can open the system screen or "My recents".
- Swipe up on the pill to open the quick dock (same buttons as the island dock), swipe down to close. Swipe left/right still runs the pill gestures; on music it skips tracks.
- Every activity morphs out of the pill and grows upward: music, call, message with reply, timer and stopwatch, recording, charging, hotspot, Bluetooth, ringer, volume and the charge alerts. While you type a reply the card moves to the top so the keyboard never covers it.
- Slim bar option: a thin light hint bar that opens into the dock on tap or swipe up.
- Size: bar width, height and distance from the bottom. The pill is always visible in this style. Works best with the system's Swipe gestures navigation; with 3-button navigation raise the distance from bottom.

Voice agent (home tab -> Voice agent, or the "Voice agent" gesture action)
- Say it (mic button) or type it. No AI model is needed: commands are matched to patterns (English and Hinglish) and run with the phone's own features.
- "open WhatsApp" / "WhatsApp kholo": opens the closest installed app, so "whats app", "insta" and similar spellings work.
- "send photo to Rahul on WhatsApp" / "Rahul ko photo bhejo": finds Rahul in contacts (asks which one if there are several), shows the newest photo and asks before sending. It opens the chat with the photo ready, then the accessibility service taps Send inside WhatsApp only. If that tap fails you just tap Send yourself. 10-digit numbers get +91.
- "rename last screenshot to notes": finds the newest photo, screenshot, video, audio or download, shows old name and new name, and Android asks you to allow the change. Android refuses some file types; rename those in Files.
- Quick actions: screenshot, torch, home, back, recents, lock, notifications, volume up/down, mute, next track, play/pause, camera.
- The accessibility service now has "retrieve window content" so it can find WhatsApp's Send button. After installing, switch the service off and on once if the phone doesn't pick it up.
- Not built yet: the AI screen-reading fallback for commands that don't match a pattern.

AI in the voice agent (uses the same Gemini setup as Score Checker: gemini-2.5-flash)
- Commands the patterns don't know are sent to Gemini, which works out what was meant (any language, including Hindi) and runs it with the same tools: open app, send photo, rename, quick actions.
- "ai ..." (for example "ai turn on dark mode", "ai set an alarm for 6 am") starts the screen agent: it reads the screen as a numbered list, asks Gemini for one action (tap, type, scroll, back, home, open app), does it, and repeats up to 14 steps. A small card at the top shows each step and a Stop button.
- Safety: it won't operate payment, banking or password apps and never types into password fields. Anything that sends, pays, buys, deletes, posts, installs or confirms needs your Allow tap (the AI flags it, and a word list double-checks). Text on screen is treated as data, never as instructions. It stops if it repeats itself.
- AI on/off and an optional own Gemini key are in the Voice agent card. The key from score-checker-pro-admin.html is built in as the default. It sits in AgentAi.kt, so restrict or rotate it in Google AI Studio if the repo or APK is shared.
- Needs internet for the AI parts. Patterns like "open WhatsApp" still work offline.
