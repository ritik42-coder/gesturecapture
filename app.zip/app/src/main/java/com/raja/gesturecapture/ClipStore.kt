package com.raja.gesturecapture

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

// ---------------------------------------------------------------------------------------------------
// Clipboard history for the edge panel: everything you copy, text and images, newest first, kept on
// the phone only. Nothing leaves the device.
//
// Android 10+ only lets the app that has input focus read the clipboard, so the panel asks for focus
// for a moment when it opens (see EdgePanel.peekClipboard) and reads it then. Copies made while the
// panel is open are picked up by the change listener straight away.
// ---------------------------------------------------------------------------------------------------
object ClipStore {
    const val AUTH = "com.raja.gesturecapture.files"
    private const val PREFS_KEY = "clip_hist"

    class Item(
        val id: String,
        val text: String,
        val img: String,
        val at: Long,
        val pin: Boolean
    ) {
        val isImage: Boolean get() = img.isNotEmpty()
        fun uri(): Uri = Uri.parse("content://" + AUTH + "/clip/" + img)
    }

    private val h = Handler(Looper.getMainLooper())
    private val list = ArrayList<Item>()
    private var ctx: Context? = null
    private var started = false
    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null

    var onChanged: (() -> Unit)? = null
    // true once Android has refused a read because we were in the background
    var blocked = false
        private set

    // ------------------------------------------------------------------------------------------
    fun start(c: Context) {
        ctx = c.applicationContext
        if (!started) {
            started = true
            load()
            val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            if (cm != null) {
                val l = ClipboardManager.OnPrimaryClipChangedListener {
                    h.postDelayed({ capture() }, 320)
                }
                listener = l
                try { cm.addPrimaryClipChangedListener(l) } catch (_: Exception) {}
            }
        }
    }

    fun items(): List<Item> = synchronized(list) { ArrayList(list) }
    fun size(): Int = synchronized(list) { list.size }

    private fun imgDir(c: Context): File {
        val d = File(c.filesDir, "clip")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun maxItems(): Int {
        val c = ctx ?: return 25
        return try {
            val cfg = JSONObject(Prefs.sp(c).getString("ep", "{}") ?: "{}")
            cfg.optInt("clipn", 25).coerceIn(5, 80)
        } catch (_: Exception) { 25 }
    }

    // ------------------------------------------------------------------------------------------
    // reading the clipboard
    // ------------------------------------------------------------------------------------------
    fun capture(): Boolean {
        val c = ctx ?: return false
        val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return false
        val clip: ClipData? = try {
            cm.primaryClip
        } catch (_: Throwable) {
            blocked = true
            return false
        }
        if (clip == null || clip.itemCount == 0) return false
        blocked = false
        val item = clip.getItemAt(0) ?: return false
        val desc = clip.description
        val mime = if (desc != null && desc.mimeTypeCount > 0) (desc.getMimeType(0) ?: "") else ""
        val uri = item.uri
        if (mime.startsWith("image") && uri != null) return addImage(c, uri, mime)
        val txt = try { item.coerceToText(c)?.toString() } catch (_: Exception) { null }
            ?: item.text?.toString() ?: ""
        if (txt.isBlank()) return false
        return addText(txt)
    }

    private fun addText(raw: String): Boolean {
        val t = raw.trim()
        if (t.isEmpty()) return false
        val keep = if (t.length > 4000) t.substring(0, 4000) else t
        synchronized(list) {
            val first = list.firstOrNull()
            if (first != null && !first.isImage && first.text == keep) {
                list[0] = Item(first.id, first.text, "", System.currentTimeMillis(), first.pin)
                save()
                notifyChange()
                return true
            }
            if (list.any { !it.isImage && it.text == keep }) return true
            list.add(0, Item(newId(), keep, "", System.currentTimeMillis(), false))
            trim()
            save()
        }
        notifyChange()
        return true
    }

    private fun addImage(c: Context, uri: Uri, mime: String): Boolean {
        val ext = when {
            mime.contains("png") -> "png"
            mime.contains("webp") -> "webp"
            mime.contains("gif") -> "gif"
            else -> "jpg"
        }
        val name = "c" + System.currentTimeMillis() + "." + ext
        val f = File(imgDir(c), name)
        val ok = try {
            c.contentResolver.openInputStream(uri)?.use { inp ->
                FileOutputStream(f).use { out -> inp.copyTo(out) }
            }
            f.exists() && f.length() > 0
        } catch (_: Throwable) {
            false
        }
        if (!ok) { f.delete(); return false }
        synchronized(list) {
            val firstImg = list.firstOrNull { it.isImage }
            if (firstImg != null) {
                val of = File(imgDir(c), firstImg.img)
                if (of.exists() && of.length() == f.length()) { f.delete(); return true }
            }
            list.add(0, Item(newId(), "", name, System.currentTimeMillis(), false))
            trim()
            save()
        }
        notifyChange()
        return true
    }

    private fun newId(): String = System.currentTimeMillis().toString() + "-" + (1000..9999).random()

    private fun trim() {
        val max = maxItems()
        var i = list.size - 1
        while (list.size > max && i >= 0) {
            if (!list[i].pin) {
                deleteFile(list[i])
                list.removeAt(i)
            }
            i--
        }
    }

    private fun notifyChange() {
        h.post { try { onChanged?.invoke() } catch (_: Exception) {} }
    }

    // ------------------------------------------------------------------------------------------
    // changing the list
    // ------------------------------------------------------------------------------------------
    fun pinToggle(id: String) {
        synchronized(list) {
            val i = list.indexOfFirst { it.id == id }
            if (i >= 0) {
                val it0 = list[i]
                list[i] = Item(it0.id, it0.text, it0.img, it0.at, !it0.pin)
                save()
            }
        }
        notifyChange()
    }

    fun remove(id: String) {
        synchronized(list) {
            val i = list.indexOfFirst { it.id == id }
            if (i >= 0) { deleteFile(list[i]); list.removeAt(i); save() }
        }
        notifyChange()
    }

    fun clearAll() {
        synchronized(list) {
            for (it in list) deleteFile(it)
            list.clear()
            save()
        }
        notifyChange()
    }

    private fun deleteFile(it: Item) {
        if (!it.isImage) return
        val c = ctx ?: return
        try { File(imgDir(c), it.img).delete() } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------------------------------
    // using an item
    // ------------------------------------------------------------------------------------------
    fun copy(it: Item): Boolean {
        val c = ctx ?: return false
        val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return false
        return try {
            if (it.isImage) cm.setPrimaryClip(ClipData.newUri(c.contentResolver, "Image", it.uri()))
            else cm.setPrimaryClip(ClipData.newPlainText("Edge panel", it.text))
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun share(it: Item): Intent? {
        if (ctx == null) return null
        return try {
            if (it.isImage) {
                Intent(Intent.ACTION_SEND).apply {
                    type = mimeOf(it.img)
                    putExtra(Intent.EXTRA_STREAM, it.uri())
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, it.text)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        } catch (_: Exception) { null }
    }

    fun mimeOf(name: String): String = when {
        name.endsWith(".png") -> "image/png"
        name.endsWith(".webp") -> "image/webp"
        name.endsWith(".gif") -> "image/gif"
        else -> "image/jpeg"
    }

    fun thumb(it: Item, req: Int): Bitmap? {
        val c = ctx ?: return null
        if (!it.isImage) return null
        val f = File(imgDir(c), it.img)
        if (!f.exists()) return null
        return try {
            val b = BitmapFactory.Options()
            b.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.path, b)
            var sc = 1
            while (b.outWidth / (sc * 2) >= req && b.outHeight / (sc * 2) >= req) sc *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sc
            BitmapFactory.decodeFile(f.path, o)
        } catch (_: Throwable) { null }
    }

    fun whenText(at: Long): String {
        val d = System.currentTimeMillis() - at
        return when {
            d < 60_000 -> "just now"
            d < 3_600_000 -> (d / 60_000).toString() + " min ago"
            d < 86_400_000 -> (d / 3_600_000).toString() + " h ago"
            else -> (d / 86_400_000).toString() + " d ago"
        }
    }

    // ------------------------------------------------------------------------------------------
    private fun save() {
        val c = ctx ?: return
        try {
            val arr = JSONArray()
            for (it in list) {
                val o = JSONObject()
                o.put("i", it.id); o.put("t", it.text); o.put("g", it.img)
                o.put("a", it.at); o.put("p", it.pin)
                arr.put(o)
            }
            Prefs.sp(c).edit().putString(PREFS_KEY, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun load() {
        val c = ctx ?: return
        synchronized(list) {
            list.clear()
            try {
                val raw = Prefs.sp(c).getString(PREFS_KEY, "[]") ?: "[]"
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val img = o.optString("g", "")
                    if (img.isNotEmpty() && !File(imgDir(c), img).exists()) continue
                    list.add(Item(o.optString("i", newId()), o.optString("t", ""), img,
                        o.optLong("a", 0L), o.optBoolean("p", false)))
                }
            } catch (_: Exception) {}
        }
    }
}
