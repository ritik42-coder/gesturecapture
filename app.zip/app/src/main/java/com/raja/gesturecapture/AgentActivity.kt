package com.raja.gesturecapture

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.util.Size
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import org.json.JSONObject

// The voice agent screen: a small card over whatever you were doing. It listens (or takes typed text), shows what it
// understood, and asks before anything that sends or changes a file.
class AgentActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var card: LinearLayout
    private var pend: (() -> Unit)? = null
    private var ren: Pair<Uri, String>? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); window.setDimAmount(.55f)
        val root = FrameLayout(this); root.setOnClickListener { finish() }
        card = LinearLayout(this); card.orientation = LinearLayout.VERTICAL; card.isClickable = true
        card.setPadding(dp(20), dp(18), dp(20), dp(18))
        card.background = GradientDrawable().apply { setColor(0xF2141A38.toInt()); cornerRadius = dp(28).toFloat(); setStroke(dp(1), 0x33FFFFFF) }
        val lp = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM); lp.setMargins(dp(12), 0, dp(12), dp(24))
        root.addView(card, lp); setContentView(root)
        val t = intent.getStringExtra("text")
        if (t.isNullOrBlank()) listen() else handle(t)
    }

    private fun tv(t: String, sp: Float, col: Int, bold: Boolean) = TextView(this).apply { text = t; textSize = sp; setTextColor(col); if (bold) typeface = Typeface.DEFAULT_BOLD }

    private fun show(title: String, sub: String = "", thumb: Bitmap? = null, vararg btns: Pair<String, () -> Unit>) {
        card.removeAllViews()
        card.addView(tv(title, 18f, Color.WHITE, true))
        if (sub.isNotEmpty()) card.addView(tv(sub, 13f, 0xFFA9B2D6.toInt(), false).apply { setPadding(0, dp(4), 0, 0) })
        if (thumb != null) {
            val iv = ImageView(this); iv.setImageBitmap(thumb); iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.clipToOutline = true; iv.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            iv.background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.DKGRAY) }
            card.addView(iv, LinearLayout.LayoutParams(dp(120), dp(120)).apply { topMargin = dp(12); gravity = Gravity.CENTER_HORIZONTAL })
        }
        if (btns.isNotEmpty()) {
            val row = LinearLayout(this); row.gravity = Gravity.END; row.setPadding(0, dp(14), 0, 0)
            btns.forEachIndexed { i, b ->
                val primary = i == 0 && btns.size > 1 && b.first != "OK"
                val v = TextView(this).apply {
                    text = b.first; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    setTextColor(if (primary) Color.BLACK else Color.WHITE); setPadding(dp(18), dp(11), dp(18), dp(11))
                    background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(if (primary) 0xFF67E8F9.toInt() else 0x26FFFFFF) }
                    setOnClickListener { b.second() }
                }
                row.addView(v, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
            }
            card.addView(row)
        }
    }

    private fun mediaPerms(): List<String> =
        if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun ensure(perms: List<String>, then: () -> Unit) {
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { then(); return }
        pend = then; requestPermissions(missing.toTypedArray(), 61)
    }

    override fun onRequestPermissionsResult(rq: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rq, p, r)
        if (rq != 61) return
        val go = pend; pend = null
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) go?.invoke()
        else show("Permission needed", "Allow it in Settings, Apps, Permissions, then try again.", null, "OK" to { finish() })
    }

    private fun listen() {
        show("Listening\u2026", "Say a command, like \u201copen WhatsApp\u201d")
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN").putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a command"), 60)
        } catch (_: Exception) { show("Voice input isn't available", "Type the command in the app instead.", null, "OK" to { finish() }) }
    }

    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq == 60) {
            val t = if (rc == RESULT_OK) d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() else null
            if (t.isNullOrBlank()) finish() else handle(t)
        } else if (rq == 62) {
            val r = ren; ren = null
            if (rc == RESULT_OK && r != null) {
                val ok = try { contentResolver.update(r.first, ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, r.second) }, null, null) > 0 } catch (_: Exception) { false }
                show(if (ok) "Renamed" else "Couldn't rename", r.second, null, "OK" to { finish() })
                if (ok) h.postDelayed({ finish() }, 1500)
            } else show("Cancelled", "", null, "OK" to { finish() })
        }
    }

    private val reAi = Regex("^(?:ai|agent|computer)[ ,:]+(.+)$", RegexOption.IGNORE_CASE)
    private val actIds = setOf("shot", "torch", "home", "back", "recents", "lock", "notif", "vol_up", "vol_down", "mute", "media_next", "media_play", "camera")

    private fun handle(t: String) {
        show("\u201c$t\u201d", "Working on it\u2026")
        val forced = reAi.find(t.trim())
        if (forced != null) { startScreen(forced.groupValues[1].trim()); return }
        when (val c = Agent.parse(t)) {
            is Cmd.Open -> openApp(c.q)
            is Cmd.Act -> runAct(c.id, c.say)
            is Cmd.SendPhoto -> sendPhoto(c)
            is Cmd.Rename -> rename(c)
            Cmd.Unknown -> if (AgentAi.on(this)) askAi(t) else show("I didn't catch that", "Try \u201copen WhatsApp\u201d, \u201csend photo to Rahul on WhatsApp\u201d or \u201crename last screenshot to notes\u201d.", null, "OK" to { finish() })
        }
    }

    private fun runAct(id: String, say: String) {
        val app = applicationContext
        show(say)
        h.postDelayed({
            finish()
            Handler(Looper.getMainLooper()).postDelayed({
                val s = GestureService.inst
                if (s != null) s.doAct(id, "agent") else Toast.makeText(app, "Turn on the Accessibility service first", Toast.LENGTH_LONG).show()
            }, 350)
        }, 500)
    }

    // the patterns didn't match, so ask Gemini what was meant (any language) and run it with the same tools
    private fun askAi(t: String) {
        show("Thinking\u2026", "Asking AI")
        Thread { val p = AgentAi.plan(this, t); runOnUiThread { applyPlan(p, t) } }.start()
    }

    private fun applyPlan(p: JSONObject?, t: String) {
        if (p == null) { show("AI isn't reachable", AgentAi.err, null, "OK" to { finish() }); return }
        when (p.optString("kind")) {
            "open" -> openApp(p.optString("app"))
            "send_photo" -> sendPhoto(Cmd.SendPhoto(p.optString("who"), p.optString("photo", "photo").lowercase()))
            "rename" -> rename(Cmd.Rename(p.optString("what", "file").lowercase(), p.optString("to")))
            "act" -> if (p.optString("id") in actIds) runAct(p.optString("id"), "Doing that") else startScreen(t)
            "screen" -> startScreen(p.optString("goal", t))
            else -> show("That doesn't look like a phone command", "Try \u201copen WhatsApp\u201d or \u201cai turn on dark mode\u201d.", null, "OK" to { finish() })
        }
    }

    // hands over to the screen agent in the accessibility service, which then works in the other apps
    private fun startScreen(goal: String) {
        val svc = GestureService.inst
        if (svc == null) { show("Turn on the Accessibility service first", "", null, "OK" to { finish() }); return }
        show("On it", goal)
        h.postDelayed({ finish(); svc.screenAgent.start(goal) }, 600)
    }

    private fun openApp(q: String) {
        val a = Agent.findApp(this, q)
        val i = if (a != null) packageManager.getLaunchIntentForPackage(a.first)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) else null
        if (a == null || i == null) { show("Couldn't find \u201c$q\u201d", "No installed app matches that name.", null, "OK" to { finish() }); return }
        show("Opening ${a.second}")
        h.postDelayed({ startActivity(i); finish() }, 250)
    }

    private fun sendPhoto(c: Cmd.SendPhoto) = ensure(listOf(Manifest.permission.READ_CONTACTS) + mediaPerms()) {
        val people = Agent.findPeople(this, c.who)
        when {
            people.isEmpty() -> show("No contact named \u201c${c.who}\u201d", "Check the spelling in your contacts.", null, "OK" to { finish() })
            people.size == 1 -> confirmSend(people[0], c.kind)
            else -> show("Which ${c.who}?", "", null, *people.map { p -> p.name to { confirmSend(p, c.kind) } }.toTypedArray())
        }
    }

    private fun confirmSend(p: Person, kind: String) {
        val pic = Agent.latest(this, kind)
        if (pic == null) { show("No $kind found", "I couldn't find a recent one.", null, "OK" to { finish() }); return }
        val th = try { contentResolver.loadThumbnail(pic.uri, Size(300, 300), null) } catch (_: Exception) { null }
        show("Send this to ${p.name}?", "WhatsApp \u00b7 ${pic.name}", th, "Send" to { doSend(p, pic) }, "Cancel" to { finish() })
    }

    // opens the chat with the photo ready, then the accessibility service taps Send inside WhatsApp
    private fun doSend(p: Person, pic: Pic) {
        val pk = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (pk == null) { show("WhatsApp isn't installed", "", null, "OK" to { finish() }); return }
        val i = Intent(Intent.ACTION_SEND).setType(pic.mime.ifBlank { "image/*" })
            .putExtra(Intent.EXTRA_STREAM, pic.uri).putExtra("jid", Agent.waNumber(p.number) + "@s.whatsapp.net")
            .setPackage(pk).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        val app = applicationContext; val svc = GestureService.inst
        try { startActivity(i) } catch (_: Exception) { show("Couldn't open WhatsApp", "", null, "OK" to { finish() }); return }
        if (svc != null) svc.tapInWhatsApp(listOf("send", "\u092d\u0947\u091c\u0947\u0902"), 16) { ok ->
            Toast.makeText(app, if (ok) "Sent to ${p.name}" else "The photo is ready in WhatsApp. Tap Send.", Toast.LENGTH_LONG).show()
        } else Toast.makeText(app, "The photo is ready in WhatsApp. Tap Send. (Turn on Accessibility to tap it for you.)", Toast.LENGTH_LONG).show()
        finish()
    }

    private fun rename(c: Cmd.Rename) = ensure(mediaPerms()) {
        val pic = Agent.latest(this, c.kind)
        if (pic == null) { show("No ${c.kind} found", "", null, "OK" to { finish() }); return@ensure }
        var n = c.to.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        val ext = pic.name.substringAfterLast('.', "")
        if (ext.isNotEmpty() && !n.endsWith(".$ext", true)) n += ".$ext"
        val nn = n
        show("Rename?", "${pic.name}  \u2192  $nn", null, "Rename" to { askWrite(pic.uri, nn) }, "Cancel" to { finish() })
    }

    // Android asks the person to allow the change, which doubles as the confirmation
    private fun askWrite(u: Uri, n: String) {
        ren = Pair(u, n)
        try { startIntentSenderForResult(MediaStore.createWriteRequest(contentResolver, listOf(u)).intentSender, 62, null, 0, 0, 0) }
        catch (_: Exception) { show("Android won't let apps rename that file", "Rename it in the Files app instead.", null, "OK" to { finish() }) }
    }
}
