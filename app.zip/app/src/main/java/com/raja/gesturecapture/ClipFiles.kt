package com.raja.gesturecapture

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

// ---------------------------------------------------------------------------------------------------
// A tiny read-only provider so clipboard images can be pasted into other apps and shared.
// content://com.raja.gesturecapture.files/clip/<file>
// ---------------------------------------------------------------------------------------------------
class ClipFiles : ContentProvider() {
    override fun onCreate(): Boolean = true

    private fun dir(): File = File(context?.filesDir ?: File("/"), "clip")

    override fun getType(uri: Uri): String = ClipStore.mimeOf(uri.lastPathSegment ?: "")

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val name = uri.lastPathSegment ?: throw FileNotFoundException("no file")
        if (name.contains("/") || name.contains("..")) throw FileNotFoundException("bad name")
        val f = File(dir(), name)
        if (!f.exists()) throw FileNotFoundException(name)
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?
    ): Cursor? {
        val name = uri.lastPathSegment ?: return null
        val f = File(dir(), name)
        if (!f.exists()) return null
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val c = MatrixCursor(cols, 1)
        val row = c.newRow()
        for (col in cols) {
            when (col) {
                OpenableColumns.DISPLAY_NAME -> row.add(name)
                OpenableColumns.SIZE -> row.add(f.length())
                else -> row.add(null)
            }
        }
        return c
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
