package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------------
// The island's skin. A rounded gradient that can stand still or move: flow (the gradient slides),
// rgb (the whole palette cycles through the spectrum), aurora (soft hue drift + slide),
// pulse (brightness breathes) and sweep (a highlight runs across). Optional coloured glow around
// the pill and a breathing idle. One animator drives a single phase value, so it stays cheap.
// ---------------------------------------------------------------------------------------------------
class IslandSkin : Drawable() {
    var style = "still"          // still | flow | rgb | aurora | pulse | sweep
    var vertical = false         // gradient runs top to bottom instead of left to right
    var c1 = Color.BLACK
    var c2 = Color.BLACK
    var c3 = Color.BLACK
    var cornerRadius = 0f
    var pct = 100            // 0..100
    var glow = 0f                // px of coloured glow outside the pill
    var borderAlpha = 40         // 0..255 hairline border
    var speed = 1f               // 0.2..3
    var breathe = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val haloBox = RectF()
    private var grad: LinearGradient? = null
    private var gradKey = ""
    private var cf: ColorFilter? = null
    private var cfKey = -999f
    private var phase = 0f
    private var vw = 0
    private var vh = 0
    private var runner: ValueAnimator? = null

    init {
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = 1.5f
        halo.style = Paint.Style.STROKE
    }

    fun colors(a: Int, b: Int, c: Int) {
        if (a != c1 || b != c2 || c != c3) { c1 = a; c2 = b; c3 = c; grad = null }
    }

    private fun moving() = style != "still" || breathe

    private var runKey = ""

    fun start() {
        val key = "$style|$speed|$breathe"
        if (runner != null && key == runKey) return
        stop()
        if (!moving()) { invalidateSelf(); return }
        runKey = key
        val ms = (9000f / speed.coerceIn(0.15f, 4f)).toLong().coerceAtLeast(900L)
        runner = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { a -> phase = a.animatedValue as Float; invalidateSelf() }
            start()
        }
    }

    fun stop() {
        runner?.cancel(); runner = null; runKey = ""
        phase = 0f
        invalidateSelf()
    }

    fun restart() { stop(); start() }

    fun copyTo(o: IslandSkin) {
        o.style = style; o.vertical = vertical; o.cornerRadius = cornerRadius
        o.pct = pct; o.glow = glow; o.borderAlpha = borderAlpha
        o.speed = speed; o.breathe = breathe
        o.colors(c1, c2, c3)
    }

    override fun onBoundsChange(bounds: android.graphics.Rect) {
        super.onBoundsChange(bounds)
        vw = bounds.width(); vh = bounds.height()
        grad = null
    }

    private fun filter(hue: Float): ColorFilter? {
        if (abs(hue) < 0.5f) return null
        if (cf != null && abs(hue - cfKey) < 3f) return cf
        val m = ColorMatrix()
        m.setRotate(0, hue); m.setRotate(1, hue); m.setRotate(2, hue)
        cf = ColorMatrixColorFilter(m); cfKey = hue
        return cf
    }

    private fun shader(w: Float, h: Float): Shader {
        val key = "$c1|$c2|$c3|$vertical|${w.toInt()}|${h.toInt()}"
        val g = grad
        if (g != null && key == gradKey) return g
        val len = (if (vertical) h else w) * 1.7f + 1f
        val cols = intArrayOf(c1, c2, c3, c1)
        val pos = floatArrayOf(0f, 0.33f, 0.66f, 1f)
        val ng = if (vertical) LinearGradient(0f, 0f, 0f, len, cols, pos, Shader.TileMode.REPEAT)
        else LinearGradient(0f, 0f, len, 0f, cols, pos, Shader.TileMode.REPEAT)
        grad = ng; gradKey = key
        return ng
    }

    override fun draw(canvas: Canvas) {
        val w = vw.toFloat(); val h = vh.toFloat()
        if (w <= 0f || h <= 0f) return
        val rad = min(cornerRadius, h / 2f)
        val t = phase
        val hue = when (style) {
            "rgb" -> t * 360f
            "aurora" -> 35f * sin(t * 6.2832f)
            "pulse" -> 18f * sin(t * 12.566f)
            else -> 0f
        }
        // one full cycle moves the gradient by exactly its own period, so the loop has no seam
        val period = (if (vertical) h else w) * 1.7f + 1f
        val shift = when (style) {
            "flow", "rgb", "aurora" -> t * period
            "sweep" -> t * period * 2f
            else -> 0f
        }
        val br = if (breathe) 0.5f + 0.5f * sin(t * 6.2832f) else 1f
        val f = filter(hue)
        val base = (pct.coerceIn(5, 100) * 255 / 100).toFloat()

        canvas.save()
        if (vertical) canvas.translate(0f, -shift) else canvas.translate(-shift, 0f)
        val ox = if (vertical) 0f else shift
        val oy = if (vertical) shift else 0f
        box.set(ox, oy, ox + w, oy + h)

        fill.shader = shader(w, h)
        fill.colorFilter = f
        fill.alpha = (base * (if (style == "pulse") 0.72f + 0.28f * br else 1f)).toInt().coerceIn(0, 255)

        // coloured glow: a few widening strokes just outside the pill
        if (glow > 0.5f) {
            halo.shader = fill.shader
            halo.colorFilter = f
            for (i in 0 until 5) {
                val g = 1f - i / 5f
                val sw = 1f + glow * g * 0.9f
                halo.strokeWidth = sw
                halo.alpha = (46f * g * g * br).toInt().coerceIn(0, 255)
                haloBox.set(box.left - sw / 2f, box.top - sw / 2f, box.right + sw / 2f, box.bottom + sw / 2f)
                canvas.drawRoundRect(haloBox, rad + sw / 2f, rad + sw / 2f, halo)
            }
        }
        canvas.drawRoundRect(box, rad, rad, fill)
        canvas.restore()

        // hairline border, drawn in place so it never slides
        if (borderAlpha > 0) {
            ring.color = Color.WHITE
            ring.shader = null
            ring.alpha = (borderAlpha * (0.55f + 0.45f * br)).toInt().coerceIn(0, 255)
            ring.strokeWidth = 1.5f
            box.set(0.75f, 0.75f, w - 0.75f, h - 0.75f)
            canvas.drawRoundRect(box, rad, rad, ring)
        }
    }

    override fun setAlpha(alpha: Int) { fill.alpha = alpha; invalidateSelf() }
    override fun setColorFilter(colorFilter: ColorFilter?) { fill.colorFilter = colorFilter; invalidateSelf() }
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
