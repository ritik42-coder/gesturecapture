package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------------------------------
// The living background of the lock screen: three soft colour fields drifting on their own paths over
// a deep night gradient, a quiet vignette and a handful of slow stars. One animator drives all of it,
// and it stops itself the moment the view leaves the window.
// ---------------------------------------------------------------------------------------------------
class LockBackdrop(c: Context) : View(c) {
    private class Blob(val color: Int, val alpha: Int, val rad: Float, val speed: Float, val phase: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        var shader: RadialGradient? = null
        var radius = 1f
    }

    private val base = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vign = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blobs = arrayOf(
        Blob(0xFF4C6BFF.toInt(), 118, 0.62f, 0.90f, 0.0f),
        Blob(0xFFA855F7.toInt(), 96, 0.52f, 1.15f, 2.2f),
        Blob(0xFF22D3EE.toInt(), 70, 0.46f, 0.75f, 4.4f)
    )
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val rnd = Random(7)
    private val stars = FloatArray(64)     // x, y, radius, phase

    init {
        for (i in 0 until 16) {
            stars[i * 4] = rnd.nextFloat()
            stars[i * 4 + 1] = rnd.nextFloat()
            stars[i * 4 + 2] = 0.7f + rnd.nextFloat() * 1.5f
            stars[i * 4 + 3] = rnd.nextFloat() * 6.28f
        }
        starPaint.color = Color.WHITE
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val big = max(w, h).toFloat()
        base.shader = LinearGradient(0f, 0f, w * 0.25f, h.toFloat(),
            intArrayOf(0xFF06080F.toInt(), 0xFF0A0F1E.toInt(), 0xFF07090F.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        blobs.forEach { b ->
            b.radius = big * b.rad
            b.shader = RadialGradient(0f, 0f, b.radius, b.color, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            b.paint.shader = b.shader
        }
        vign.shader = RadialGradient(w / 2f, h * 0.42f, big * 0.78f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, 0xC405070F.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 18000
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, base)

        val a = t * 6.2831855f
        blobs.forEachIndexed { i, b ->
            val sx = 0.5f + 0.34f * cos(a * b.speed + b.phase)
            val sy = 0.42f + 0.26f * sin(a * b.speed * 0.83f + b.phase * 1.7f)
            b.paint.alpha = (b.alpha * (0.75f + 0.25f * sin(a * 1.3f + i))).toInt().coerceIn(0, 255)
            canvas.save()
            canvas.translate(w * sx, h * sy)
            canvas.drawCircle(0f, 0f, b.radius, b.paint)
            canvas.restore()
        }

        // stars: tiny, slow, breathing
        for (i in 0 until 16) {
            val px = stars[i * 4] * w
            val py = (stars[i * 4 + 1] * h + t * 26f) % h
            val r = stars[i * 4 + 2]
            starPaint.alpha = (40 + 70 * (0.5f + 0.5f * sin(a * 0.6f + stars[i * 4 + 3]))).toInt()
            canvas.drawCircle(px, py, r, starPaint)
        }

        canvas.drawRect(0f, 0f, w, h, vign)
    }
}
