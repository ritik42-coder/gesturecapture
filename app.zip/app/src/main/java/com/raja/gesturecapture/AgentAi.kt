package com.raja.gesturecapture

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Gemini, the same model and key setup the Score Checker uses (gemini-2.5-flash). Always call off the main thread.
object AgentAi {
    private const val MODEL = "gemini-2.5-flash"
    private const val DEFAULT_KEY = "AIzaSyDYknwUf8i6-fIDUIfUZ2FYkYDWamog58A"
    @Volatile var err = ""

    private fun cfg(c: Context): JSONObject = try { JSONObject(Prefs.sp(c).getString("agcfg", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    fun on(c: Context) = cfg(c).optBoolean("on", true)
    fun key(c: Context): String { val k = cfg(c).optString("key", "").trim(); return if (k.isNotEmpty()) k else DEFAULT_KEY }

    private const val PLAN = """You turn a spoken phone command (any language, including Hindi and Hinglish) into ONE JSON object.
kinds:
- open: opens an app. {"kind":"open","app":"app name"}
- send_photo: sends the newest photo or screenshot to a contact on WhatsApp. {"kind":"send_photo","who":"contact name","photo":"photo" or "screenshot"}
- rename: renames the newest file. {"kind":"rename","what":"photo|screenshot|video|audio|file","to":"new name"}
- act: a quick phone action. {"kind":"act","id":"one of shot,torch,home,back,recents,lock,notif,vol_up,vol_down,mute,media_next,media_play,camera"}
- screen: anything else that needs operating apps on the screen. {"kind":"screen","goal":"clear one-sentence English instruction"}
- unknown: not a phone command. {"kind":"unknown"}
Reply with the JSON only."""

    fun plan(c: Context, text: String): JSONObject? {
        val r = call(c, PLAN, "Command: $text") ?: return null
        return try { JSONObject(r) } catch (_: Exception) { err = "unreadable reply"; null }
    }

    fun call(c: Context, system: String, user: String): String? {
        val key = key(c)
        if (key.isBlank()) { err = "no API key"; return null }
        return try {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))))
                .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.1)
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
            val cn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent").openConnection() as HttpURLConnection
            cn.requestMethod = "POST"; cn.connectTimeout = 15000; cn.readTimeout = 30000; cn.doOutput = true
            cn.setRequestProperty("Content-Type", "application/json"); cn.setRequestProperty("x-goog-api-key", key)
            cn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = cn.responseCode
            val txt = (if (code in 200..299) cn.inputStream else cn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) { err = if (code == 429) "AI is busy, try again in a moment" else "AI error $code"; return null }
            val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            var out = ""
            for (i in 0 until parts.length()) out += parts.getJSONObject(i).optString("text")
            out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        } catch (e: Exception) { err = e.message ?: "no internet"; null }
    }
}
