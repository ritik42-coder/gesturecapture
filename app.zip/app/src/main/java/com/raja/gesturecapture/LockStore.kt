package com.raja.gesturecapture

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------------
// Everything the app lock remembers: the PIN, the pattern, which unlock method to show first,
// whether fingerprint / face are allowed, and how many wrong tries happened.
// Credentials are stored as salted SHA-256 hashes, never as plain text, and never leave the phone.
// ---------------------------------------------------------------------------------------------------
object LockStore {
    private const val K = "al_"                       // key prefix inside the "gc" preferences
    private fun sp(c: Context) = Prefs.sp(c)

    // ---- hashing ----------------------------------------------------------------------------------
    private fun salt(c: Context): String {
        val cur = sp(c).getString(K + "salt", "") ?: ""
        if (cur.length == 32) return cur
        val b = ByteArray(16); SecureRandom().nextBytes(b)
        val n = b.joinToString("") { "%02x".format(it.toInt() and 0xFF) }
        sp(c).edit().putString(K + "salt", n).apply()
        return n
    }

    private fun hash(c: Context, kind: String, v: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest((salt(c) + "|" + kind + "|" + v).toByteArray())
        return d.joinToString("") { "%02x".format(it.toInt() and 0xFF) }
    }

    // compare without an early exit, so timing says nothing about how much of the secret matched
    private fun same(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var r = 0
        for (i in a.indices) r = r or (a[i].code xor b[i].code)
        return r == 0
    }

    // ---- PIN ---------------------------------------------------------------------------------------
    private fun pinHash(c: Context) = sp(c).getString(K + "pin", "") ?: ""

    // older builds kept the PIN as plain text; that value is migrated on the next successful unlock
    private fun legacyPin(c: Context) = sp(c).getString("al_pin", "") ?: ""

    // only a four-digit PIN counts; a longer PIN from an older build is treated as not set,
    // so the lock asks for a fresh four-digit one instead of locking the owner out
    fun hasPin(c: Context) = pinHash(c).isNotEmpty() || legacyPin(c).length == 4

    fun pinLen(c: Context): Int {
        val n = sp(c).getInt(K + "pinlen", 0)
        if (n in 4..8) return n
        val old = legacyPin(c).length          // a PIN saved by an older build
        return if (old in 4..8) old else 4
    }

    fun setPin(c: Context, pin: String): Boolean {
        val t = pin.filter { it.isDigit() }.take(4)
        if (t.length != 4) return false
        // one unlock method at a time: setting a PIN removes any pattern
        sp(c).edit().putString(K + "pin", hash(c, "pin", t)).putInt(K + "pinlen", 4)
            .putString(K + "method", "pin")
            .remove("al_pin").remove(K + "pat").remove(K + "patlen").apply()
        clearFails(c)
        return true
    }

    fun checkPin(c: Context, pin: String): Boolean {
        val t = pin.filter { it.isDigit() }
        if (pinHash(c).isNotEmpty()) return same(pinHash(c), hash(c, "pin", t))
        val old = legacyPin(c)
        if (old.length == 4 && old == t) { setPin(c, t); return true }   // migrate the old plain PIN
        return false
    }

    // ---- pattern -----------------------------------------------------------------------------------
    private fun patHash(c: Context) = sp(c).getString(K + "pat", "") ?: ""

    fun hasPattern(c: Context) = patHash(c).isNotEmpty()

    fun patLen(c: Context): Int = sp(c).getInt(K + "patlen", 4)

    fun setPattern(c: Context, seq: String): Boolean {
        val t = seq.trim()
        if (t.split("-").count { it.isNotEmpty() } < 4) return false
        // one unlock method at a time: setting a pattern removes any PIN
        sp(c).edit().putString(K + "pat", hash(c, "pat", t)).putInt(K + "patlen", t.split("-").size)
            .putString(K + "method", "pattern")
            .remove(K + "pin").remove(K + "pinlen").remove("al_pin").apply()
        clearFails(c)
        return true
    }

    fun checkPattern(c: Context, seq: String): Boolean {
        val h = patHash(c)
        return h.isNotEmpty() && same(h, hash(c, "pat", seq.trim()))
    }

    fun clearPattern(c: Context) {
        sp(c).edit().remove(K + "pat").remove(K + "patlen").apply()
        if (method(c) == "pattern") setMethod(c, "pin")
    }

    // ---- which screen to show ----------------------------------------------------------------------
    fun method(c: Context): String = sp(c).getString(K + "method", "pin") ?: "pin"
    fun setMethod(c: Context, m: String) { sp(c).edit().putString(K + "method", if (m == "pattern") "pattern" else "pin").apply() }

    // ---- biometrics --------------------------------------------------------------------------------
    fun bio(c: Context) = sp(c).getBoolean(K + "bio", true)
    fun setBio(c: Context, on: Boolean) = sp(c).edit().putBoolean(K + "bio", on).apply()
    fun bioAuto(c: Context) = sp(c).getBoolean(K + "auto", true)
    fun setBioAuto(c: Context, on: Boolean) = sp(c).edit().putBoolean(K + "auto", on).apply()
    fun haptics(c: Context) = sp(c).getBoolean(K + "hap", true)
    fun setHaptics(c: Context, on: Boolean) = sp(c).edit().putBoolean(K + "hap", on).apply()

    // shuffle the keypad so a shoulder surfer cannot read the pattern of taps
    fun shuffle(c: Context) = sp(c).getBoolean(K + "shuffle", false)
    fun setShuffle(c: Context, on: Boolean) = sp(c).edit().putBoolean(K + "shuffle", on).apply()

    // hide which app is being unlocked
    fun hideIcon(c: Context) = sp(c).getBoolean(K + "hideicon", false)
    fun setHideIcon(c: Context, on: Boolean) = sp(c).edit().putBoolean(K + "hideicon", on).apply()

    // accent colour of the lock screen, 0..5
    fun accent(c: Context) = sp(c).getInt(K + "accent", 0).coerceIn(0, 5)
    fun setAccent(c: Context, i: Int) = sp(c).edit().putInt(K + "accent", i.coerceIn(0, 5)).apply()

    // how long an unlocked app stays open after you leave it: 0, 5, 30 or 60 seconds
    fun relock(c: Context) = sp(c).getInt(K + "relock", 0)
    fun setRelock(c: Context, sec: Int) = sp(c).edit().putInt(K + "relock", sec.coerceIn(0, 3600)).apply()

    // ---- wrong tries -------------------------------------------------------------------------------
    private const val MAX_FAILS = 5
    private const val COOLDOWN = 30_000L

    fun fails(c: Context) = sp(c).getInt(K + "fails", 0)
    fun lockUntil(c: Context) = sp(c).getLong(K + "until", 0L)
    fun locked(c: Context) = lockUntil(c) > System.currentTimeMillis()

    fun fail(c: Context) {
        val n = fails(c) + 1
        val e = sp(c).edit().putInt(K + "fails", n)
        if (n >= MAX_FAILS) e.putLong(K + "until", System.currentTimeMillis() + COOLDOWN).putInt(K + "fails", 0)
        e.apply()
    }

    fun clearFails(c: Context) = sp(c).edit().remove(K + "fails").remove(K + "until").apply()

    fun cooldownLeft(c: Context): Long = (lockUntil(c) - System.currentTimeMillis()).coerceAtLeast(0L)

    // ---- summary for the settings screen -----------------------------------------------------------
    fun any(c: Context) = hasPin(c) || hasPattern(c)

    fun stateJson(c: Context): String {
        val o = JSONObject()
        o.put("pin", hasPin(c))
        o.put("pattern", hasPattern(c))
        o.put("method", method(c))
        o.put("bio", bio(c))
        o.put("auto", bioAuto(c))
        o.put("haptics", haptics(c))
        o.put("shuffle", shuffle(c))
        o.put("hideIcon", hideIcon(c))
        o.put("accent", accent(c))
        o.put("relock", relock(c))
        o.put("fingerprint", LockBio.hasFingerprint(c))
        o.put("face", LockBio.hasFace(c))
        o.put("enrolled", LockBio.enrolled(c))
        o.put("locked", locked(c))
        return o.toString()
    }

    fun reset(c: Context) {
        val e = sp(c).edit()
        listOf("pin", "pinlen", "pat", "patlen", "method", "fails", "until").forEach { e.remove(K + it) }
        // the look of the lock screen is a preference, not a credential: keep it
        e.remove("al_pin")
        e.apply()
    }
}
