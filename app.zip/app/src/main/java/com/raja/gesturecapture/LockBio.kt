package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Typeface
import android.view.animation.DecelerateInterpolator
import java.util.concurrent.Executor

// ---------------------------------------------------------------------------------------------------
// Fingerprint and face unlock. The system owns the sensor and the enrolled templates; this activity
// is only the surface it sits on: an opaque premium "verify it's you" screen with a live scan
// animation, so the locked app is never visible while the sensor is reading.
// ---------------------------------------------------------------------------------------------------
object LockBio {
    fun hasFingerprint(c: Context) = try {
        c.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
    } catch (_: Exception) { false }

    fun hasFace(c: Context) = try {
        c.packageManager.hasSystemFeature(PackageManager.FEATURE_FACE)
    } catch (_: Exception) { false }

    fun any(c: Context) = hasFingerprint(c) || hasFace(c)

    fun enrolled(c: Context): Boolean = try {
        BiometricManager.from(c).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS
    } catch (_: Exception) { false }
}

class LockBioActivity : Activity() {
    companion object {
        private var pending: ((Boolean) -> Unit)? = null
        private var busy = false

        fun launch(c: Context, label: String, face: Boolean, cb: (Boolean) -> Unit) {
            if (busy) { cb(false); return }
            pending = cb
            busy = true
            val i = Intent(c, LockBioActivity::class.java)
                .putExtra("label", label)
                .putExtra("face", face)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            try {
                c.startActivity(i)
            } catch (_: Exception) {
                pending = null; busy = false; cb(false)
            }
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var done = false
    private var label = ""
    private var face = false
    private var scan: LockScanView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        label = intent?.getStringExtra("label") ?: "App"
        face = intent?.getBooleanExtra("face", false) ?: false
        window.setBackgroundDrawable(ColorDrawable(0xFF06080F.toInt()))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = 0xFF06080F.toInt()
        window.navigationBarColor = 0xFF06080F.toInt()
        setContentView(build())
        if (!LockBio.enrolled(this)) { finishWith(false); return }
        h.postDelayed({ prompt() }, 260)
    }

    private fun dp(x: Int) = LockUi.dp(this, x)

    private fun build(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF06080F.toInt())
        root.addView(LockBackdrop(this), FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(28), dp(40), dp(28), dp(40))

        val title = TextView(this)
        title.text = if (face) "Face unlock" else "Fingerprint unlock"
        title.textSize = 15f
        title.setTextColor(0xB3FFFFFF.toInt())
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.gravity = Gravity.CENTER
        title.letterSpacing = 0.04f
        col.addView(title, LinearLayout.LayoutParams(-1, -2))

        val sv = LockScanView(this)
        sv.face = face
        scan = sv
        col.addView(sv, LinearLayout.LayoutParams(dp(220), dp(220)).apply { topMargin = dp(26) })

        val name = TextView(this)
        name.text = label
        name.textSize = 20f
        name.setTextColor(Color.WHITE)
        name.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        name.gravity = Gravity.CENTER
        name.maxLines = 1
        col.addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })

        val sub = TextView(this)
        sub.text = if (face) "Look at your phone to unlock" else "Touch the fingerprint sensor"
        sub.textSize = 12.5f
        sub.setTextColor(0x8AFFFFFF.toInt())
        sub.gravity = Gravity.CENTER
        col.addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val usePin = TextView(this)
        usePin.text = "Use PIN instead"
        usePin.textSize = 13f
        usePin.setTextColor(0xF2FFFFFF.toInt())
        usePin.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        usePin.gravity = Gravity.CENTER
        usePin.setPadding(dp(20), dp(13), dp(20), dp(13))
        usePin.background = LockUi.glass(LockUi.dpf(this, 24f), 0x14FFFFFF, 0x24FFFFFF, LockUi.dpf(this, 1f))
        usePin.setOnClickListener { finishWith(false) }
        col.addView(usePin, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(30) })

        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        return root
    }

    private fun prompt() {
        val ex = Executor { r -> runOnUiThread(r) }
        val bp = BiometricPrompt(this, ex, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                scan?.succeed()
                LockUi.buzz(this@LockBioActivity, 28, 160)
                h.postDelayed({ finishWith(true) }, 220)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                // 7 = locked out for a while, 9 = locked out until the device is unlocked with its own PIN
                if (errorCode == 7 || errorCode == 9) scan?.fail()
                finishWith(false)
            }

            override fun onAuthenticationFailed() {
                // a finger that did not match: the system keeps the sensor open, we just nudge the UI
                scan?.fail()
                LockUi.buzz(this@LockBioActivity, 45, 200)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(if (face) "Face unlock" else "Fingerprint unlock")
            .setSubtitle(label)
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .setConfirmationRequired(false)
            .build()
        try {
            bp.authenticate(info)
        } catch (_: Exception) {
            finishWith(false)
        }
    }

    private fun finishWith(ok: Boolean) {
        if (done) return
        done = true
        val cb = pending
        pending = null
        busy = false
        cb?.invoke(ok)
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { finishWith(false) }

    override fun onDestroy() {
        if (!done) {
            done = true
            val cb = pending
            pending = null
            busy = false
            cb?.invoke(false)
        }
        super.onDestroy()
    }
}

// Pulsing fingerprint (or face) with a scan line sweeping over it.
class LockScanView(c: Context) : View(c) {
    var face = false
    var accent = 0xFF6C8CFF.toInt()
    private var t = 0f
    private var state = 0                     // 0 scanning, 1 ok, 2 fail
    private var anim: ValueAnimator? = null
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private fun d(x: Float) = x * resources.displayMetrics.density

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2100
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = DecelerateInterpolator(0.7f)
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }

    fun succeed() { state = 1; accent = 0xFF34D399.toInt(); invalidate() }
    fun fail() { state = 2; invalidate(); postDelayed({ if (state == 2) { state = 0; accent = 0xFF6C8CFF.toInt(); invalidate() } }, 420) }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f
        val base = minOf(w, h) / 2f * 0.92f

        ring.strokeWidth = d(1.2f)
        ring.color = Color.argb(60, 255, 255, 255)
        canvas.drawCircle(cx, cy, base, ring)
        canvas.drawCircle(cx, cy, base * 0.72f, ring)

        // soft colour wash behind the icon
        core.shader = RadialGradient(cx, cy, base, intArrayOf(withA(accent, 90), withA(accent, 0)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        core.alpha = (150 + 80 * t).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, base, core)
        core.shader = null

        val c = if (state == 2) 0xFFFF5C7A.toInt() else accent
        arc.strokeWidth = d(2.6f)
        arc.color = withA(c, 235)
        val s = base * 0.52f
        path.reset()
        if (face) {
            // a simple face outline: eyes, nose bridge and a smile
            rect.set(cx - s, cy - s * 0.95f, cx + s, cy + s * 1.05f)
            path.addRoundRect(rect, s * 0.55f, s * 0.55f, Path.Direction.CW)
            canvas.drawPath(path, arc)
            canvas.drawCircle(cx - s * 0.34f, cy - s * 0.16f, d(3.4f), core.apply { color = withA(c, 235); shader = null })
            canvas.drawCircle(cx + s * 0.34f, cy - s * 0.16f, d(3.4f), core)
            path.reset()
            rect.set(cx - s * 0.36f, cy + s * 0.06f, cx + s * 0.36f, cy + s * 0.52f)
            path.addArc(rect, 20f, 140f)
            canvas.drawPath(path, arc)
        } else {
            for (i in 0..3) {
                val rr = s * (0.30f + 0.24f * i)
                rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
                path.addArc(rect, 148f, 244f)
            }
            canvas.drawPath(path, arc)
            canvas.drawLine(cx, cy - s * 0.08f, cx, cy + s * 0.55f, arc)
        }

        // the scan line sweeping up and down over the icon
        val sy = cy - s * 1.15f + t * s * 2.3f
        line.shader = LinearGradient(cx - s, sy, cx + s, sy,
            intArrayOf(withA(c, 0), withA(c, 210), withA(c, 0)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        line.strokeWidth = d(1.6f)
        canvas.drawLine(cx - s, sy, cx + s, sy, line)
    }

    private fun withA(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
}
