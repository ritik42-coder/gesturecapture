package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import kotlin.math.min

// ---------------------------------------------------------------------------------------------------
// Small shared pieces for the lock screen: density maths, glass surfaces, haptics, a green success
// burst with a check that draws itself, and a slow breathing glow used behind the app icon.
// ---------------------------------------------------------------------------------------------------
object LockUi {
    fun dp(c: Context, x: Int) = (x * c.resources.displayMetrics.density).toInt()
    fun dpf(c: Context, x: Float) = x * c.resources.displayMetrics.density

    fun glass(radius: Float, fill: Int = 0x14FFFFFF, stroke: Int = 0x1FFFFFFF, strokeW: Float = 1f): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(fill)
            if (strokeW > 0f) setStroke(strokeW.toInt().coerceAtLeast(1), stroke)
        }

    fun oval(fill: Int, stroke: Int = Color.TRANSPARENT, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            if (strokeW > 0) setStroke(strokeW, stroke)
        }

    fun buzz(c: Context, ms: Int, amp: Int = 90) {
        try {
            val v = c.getSystemService(Vibrator::class.java)
            if (!v.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms.toLong(), amp.coerceIn(1, 255)))
            else @Suppress("DEPRECATION") v.vibrate(ms.toLong())
        } catch (_: Exception) {}
    }

    fun tint(d: Drawable, color: Int): Drawable {
        d.mutate().colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
        return d
    }
}

// A soft ring of light behind the app icon, breathing slowly.
class LockGlow(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var pulse = 0f
    private var anim: ValueAnimator? = null
    private var accent = 0xFF6C8CFF.toInt()

    fun accent(color: Int) { accent = color; invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = min(w, h) / 2f
        p.shader = RadialGradient(r, r, r, intArrayOf(withAlpha(accent, 120), withAlpha(accent, 0)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        ring.color = withAlpha(accent, 90)
        ring.strokeWidth = LockUi.dpf(context, 1.2f)
    }

    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2600
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = DecelerateInterpolator(0.6f)
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val base = min(width, height) / 2f
        p.alpha = (110 + 90 * pulse).toInt()
        canvas.drawCircle(cx, cy, base * (0.82f + 0.05f * pulse), p)
        ring.alpha = (70 + 80 * pulse).toInt()
        canvas.drawCircle(cx, cy, base * (0.62f + 0.06f * pulse), ring)
    }
}

// Green burst + self-drawing check mark, played the moment the app unlocks.
class LockBurst(c: Context) : View(c) {
    var onDone: (() -> Unit)? = null
    private var prog = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 620
        interpolator = DecelerateInterpolator()
        addUpdateListener { prog = it.animatedValue as Float; invalidate() }
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val check = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF34D399.toInt() }
    private val path = Path()
    private val pm = PathMeasure()
    private val seg = Path()
    private val green = 0xFF34D399.toInt()

    init {
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(a: android.animation.Animator) { onDone?.invoke() }
        })
    }

    fun play() { prog = 0f; anim.cancel(); anim.start() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = min(w, h) * 0.30f
        glow.shader = RadialGradient(w / 2f, h / 2f, r * 1.5f,
            intArrayOf(Color.argb(150, 52, 211, 153), Color.argb(0, 52, 211, 153)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        ring.strokeWidth = LockUi.dpf(context, 2.4f)
        check.strokeWidth = LockUi.dpf(context, 4.2f)
        val cx = w / 2f; val cy = h / 2f
        val s = r * 0.62f
        path.reset()
        path.moveTo(cx - s * 0.85f, cy + s * 0.05f)
        path.lineTo(cx - s * 0.18f, cy + s * 0.72f)
        path.lineTo(cx + s * 0.92f, cy - s * 0.78f)
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = min(w, h) * 0.30f
        val e = prog
        // rings fly out
        for (i in 0..2) {
            val k = ((e - i * 0.12f) / 0.62f).coerceIn(0f, 1f)
            if (k <= 0f) continue
            ring.color = Color.argb(((1f - k) * 150).toInt(), 52, 211, 153)
            canvas.drawCircle(w / 2f, h / 2f, r * (0.35f + k * 1.5f), ring)
        }
        glow.alpha = ((1f - e * 0.55f) * 255).toInt().coerceIn(0, 255)
        canvas.drawCircle(w / 2f, h / 2f, r * 1.5f, glow)
        // solid disc pops in
        val pop = (e / 0.32f).coerceIn(0f, 1f)
        disc.alpha = (pop * 235).toInt()
        canvas.drawCircle(w / 2f, h / 2f, r * (0.55f + 0.45f * pop), disc)
        // the check draws itself after the disc lands
        val cp = ((e - 0.28f) / 0.42f).coerceIn(0f, 1f)
        if (cp > 0f) {
            pm.setPath(path, false)
            seg.reset()
            pm.getSegment(0f, pm.length * cp, seg, true)
            check.alpha = (cp * 255).toInt()
            canvas.drawPath(seg, check)
        }
        if (e < 1f) postInvalidateOnAnimation()
    }
}
