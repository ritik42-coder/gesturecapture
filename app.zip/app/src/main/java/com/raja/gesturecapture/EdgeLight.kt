package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import org.json.JSONObject
import kotlin.math.min

// ---------------------------------------------------------------------------------------------------
// Edge lighting. A notification arrives and the rim of the screen lights up in a coloured glow that
// fades away by itself. Three looks: aurora (two colours sliding round the frame), rainbow (a full
// spectrum sweeping round) and solid (one colour, soft breathing). Touch passes straight through.
// ---------------------------------------------------------------------------------------------------
class EdgeLight(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var v: EdgeView? = null
    private var anim: ValueAnimator? = null
    private var end: Runnable? = null

    private fun sec(): JSONObject = try {
        JSONObject(Prefs.sp(s).getString("fx", "{}") ?: "{}").optJSONObject("el") ?: JSONObject()
    } catch (_: Exception) { JSONObject() }

    private fun dp(x: Int) = (x * s.resources.displayMetrics.density).toInt()
    private fun col(k: String, d: String) = try { Color.parseColor(sec().optString(k, d)) } catch (_: Exception) { Color.parseColor(d) }
    fun on() = sec().optBoolean("on", false)

    fun sync() { if (!on()) hide() }
    fun destroy() { hide() }

    private fun hide() {
        end?.let { h.removeCallbacks(it) }; end = null
        anim?.cancel(); anim = null
        v?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        v = null
    }

    private fun buzz(ms: Long) {
        try { s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(ms, 180)) } catch (_: Exception) {}
    }

    fun flash(force: Boolean = false) { h.post {
        if (!force && !on()) return@post
        val c = sec()
        val e = EdgeView(s)
        e.thick = dp(c.optInt("thick", 12).coerceIn(4, 26)).toFloat()
        e.style = c.optString("style", "aurora")
        e.c1 = col("c1", "#2F7BFF")
        e.c2 = col("c2", "#B14CFF")
        e.radius = dp(c.optInt("rad", 34).coerceIn(0, 60)).toFloat()
        hide()
        val p = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(e, p) } catch (_: Exception) { return@post }
        v = e
        val ms = c.optInt("ms", 2600).coerceIn(900, 6000).toLong()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = LinearInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                e.phase = f
                e.alpha = env(f)
                e.invalidate()
            }
            start()
        }
        val r = Runnable { hide() }
        end = r
        h.postDelayed(r, ms + 40)
        if (c.optBoolean("haptic", false)) buzz(16)
    } }

    // quick rise, long hold, gentle fall
    private fun env(f: Float): Float {
        val up = 0.10f
        val down = 0.58f
        val x = when {
            f < up -> f / up
            f < down -> 1f
            else -> 1f - (f - down) / (1f - down)
        }
        return x.coerceIn(0f, 1f)
    }

    private class EdgeView(c: Context) : View(c) {
        var thick = 12f
        var radius = 34f
        var style = "aurora"
        var c1 = 0xFF2F7BFF.toInt()
        var c2 = 0xFFB14CFF.toInt()
        var phase = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val r = RectF()
        private val m = Matrix()
        private var sh: Shader? = null

        override fun onSizeChanged(w: Int, hh: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, hh, ow, oh)
            val wf = w.toFloat()
            sh = if (style == "rainbow")
                SweepGradient(wf / 2f, hh / 2f,
                    intArrayOf(0xFFFF2D55.toInt(), 0xFFFFB300.toInt(), 0xFF22C55E.toInt(), 0xFF00E0FF.toInt(), 0xFF8B5CF6.toInt(), 0xFFFF2D55.toInt()),
                    null)
            else LinearGradient(0f, 0f, wf * 2f, hh.toFloat() * 0.4f,
                    intArrayOf(c1, c2, c1), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.REPEAT)
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat(); val hh = height.toFloat()
            if (w <= 0f || hh <= 0f) return
            val shader = sh ?: return
            val in0 = thick / 2f + 1f
            r.set(in0, in0, w - in0, hh - in0)
            m.reset()
            if (style == "rainbow") m.setRotate(phase * 360f, w / 2f, hh / 2f)
            else m.setTranslate(-phase * w * 2f, 0f)
            shader.setLocalMatrix(m)
            p.shader = shader
            // soft glow under the bright rim
            for (i in 3 downTo 1) {
                p.strokeWidth = thick * (1f + i * 0.95f)
                p.alpha = 18 + 9 * (3 - i)
                canvas.drawRoundRect(r, radius, radius, p)
            }
            p.strokeWidth = thick
            p.alpha = 235
            canvas.drawRoundRect(r, radius, radius, p)
            // crisp inner hairline
            p.strokeWidth = 1.5f
            p.alpha = 130
            canvas.drawRoundRect(r, radius, radius, p)
            p.alpha = 255
        }
    }
}
