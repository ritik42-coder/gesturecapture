package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.SweepGradient
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------------
// Edge lighting, in the One UI sense: when a notification lands, the rim of the screen comes alive.
// Nine effects - glow, multicolour, spotlight, eclipse, echo, glitter, bubbles, hearts, fireworks -
// with your own colours, width, speed and stay time. Nothing is touchable, so it never blocks a tap.
// ---------------------------------------------------------------------------------------------------
class EdgeLight(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var v: EdgeView? = null
    private var anim: ValueAnimator? = null
    private var end: Runnable? = null

    private fun sec(): JSONObject = try {
        JSONObject(Prefs.sp(s).getString("fx", "{}") ?: "{}").optJSONObject("el") ?: JSONObject()
    } catch (_: Exception) { JSONObject() }

    private fun dp(x: Int) = (x * s.resources.displayMetrics.density).toInt()
    private fun col(k: String, d: String) = try { Color.parseColor(sec().optString(k, d)) } catch (_: Exception) { Color.parseColor(d) }
    fun on() = sec().optBoolean("on", false)

    fun sync() { if (!on()) hide() }
    fun destroy() { hide() }

    private fun hide() {
        end?.let { h.removeCallbacks(it) }; end = null
        anim?.cancel(); anim = null
        v?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        v = null
    }

    private fun buzz(ms: Long) {
        try { s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(ms, 180)) } catch (_: Exception) {}
    }

    fun flash(force: Boolean = false) { h.post {
        if (!force && !on()) return@post
        val c = sec()
        val e = EdgeView(s)
        e.thick = dp(c.optInt("thick", 12).coerceIn(3, 26)).toFloat()
        e.effect = c.optString("effect", c.optString("style", "glow"))
        e.c1 = col("c1", "#2F7BFF")
        e.c2 = col("c2", "#B14CFF")
        e.radius = dp(c.optInt("rad", 34).coerceIn(0, 60)).toFloat()
        e.speed = (c.optInt("spd", 100).coerceIn(20, 300)) / 100f
        hide()
        val p = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(e, p) } catch (_: Exception) { return@post }
        v = e
        val ms = c.optInt("ms", 2600).coerceIn(900, 8000).toLong()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = LinearInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                e.phase = f
                e.alpha = env(f)
                e.invalidate()
            }
            start()
        }
        val r = Runnable { hide() }
        end = r
        h.postDelayed(r, ms + 40)
        if (c.optBoolean("haptic", false)) buzz(16)
    } }

    // quick rise, long hold, gentle fall
    private fun env(f: Float): Float {
        val up = 0.09f
        val down = 0.60f
        val x = when {
            f < up -> f / up
            f < down -> 1f
            else -> 1f - (f - down) / (1f - down)
        }
        return x.coerceIn(0f, 1f)
    }

    private class Dot {
        var x = 0f; var y = 0f; var vx = 0f; var vy = 0f
        var r = 2f; var a = 1f; var ph = 0f
    }

    private class EdgeView(c: Context) : View(c) {
        var effect = "glow"
        var thick = 12f
        var radius = 34f
        var c1 = 0xFF2F7BFF.toInt()
        var c2 = 0xFFB14CFF.toInt()
        var speed = 1f
        var phase = 0f

        private val d = c.resources.displayMetrics.density
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()
        private val m = Matrix()
        private val path = Path()
        private val dots = ArrayList<Dot>()
        private var t = 0f
        private var lastN = 0L
        private var w = 0f
        private var hh = 0f

        private val rainbow = intArrayOf(
            0xFFFF2D55.toInt(), 0xFFFF9500.toInt(), 0xFFFFE100.toInt(),
            0xFF22C55E.toInt(), 0xFF00E0FF.toInt(), 0xFF6366F1.toInt(),
            0xFFB14CFF.toInt(), 0xFFFF2D55.toInt())

        override fun onSizeChanged(nw: Int, nh: Int, ow: Int, oh: Int) {
            super.onSizeChanged(nw, nh, ow, oh)
            w = nw.toFloat(); hh = nh.toFloat()
            seed()
        }

        private fun dot(): Dot = Dot().also { dots.add(it) }

        private fun seed() {
            dots.clear()
            if (w <= 0f || hh <= 0f) return
            when (effect) {
                "glitter" -> for (i in 0 until 64) {
                    val q = dot()
                    val horiz = Math.random() > 0.5
                    q.x = if (horiz) (Math.random() * w).toFloat() else (if (Math.random() > 0.5) 5f * d else w - 5f * d)
                    q.y = if (!horiz) (Math.random() * hh).toFloat() else (if (Math.random() > 0.5) 5f * d else hh - 5f * d)
                    q.r = (1 + Math.random() * 2.4).toFloat() * d
                    q.ph = (Math.random() * 6.28).toFloat()
                    q.a = (0.45 + Math.random() * 0.55).toFloat()
                }
                "bubble" -> for (i in 0 until 26) {
                    val q = dot()
                    q.x = (Math.random() * w).toFloat()
                    q.y = (Math.random() * hh).toFloat()
                    q.r = (3 + Math.random() * 7).toFloat() * d
                    q.vy = -(40 + Math.random() * 70).toFloat() * d
                    q.ph = (Math.random() * 6.28).toFloat()
                    q.a = (0.35 + Math.random() * 0.5).toFloat()
                }
                "heart" -> for (i in 0 until 18) {
                    val q = dot()
                    q.x = (Math.random() * w).toFloat()
                    q.y = (Math.random() * hh).toFloat()
                    q.r = (7 + Math.random() * 9).toFloat() * d
                    q.vy = -(35 + Math.random() * 55).toFloat() * d
                    q.ph = (Math.random() * 6.28).toFloat()
                    q.a = (0.4 + Math.random() * 0.55).toFloat()
                }
                "fireworks" -> for (i in 0 until 72) {
                    val q = dot()
                    q.x = w / 2f; q.y = hh * 0.16f
                    val ang = Math.random() * 6.2832
                    val sp = (140 + Math.random() * 420).toFloat() * d
                    q.vx = (Math.cos(ang) * sp).toFloat()
                    q.vy = (Math.sin(ang) * sp).toFloat()
                    q.r = (1.2 + Math.random() * 2.2).toFloat() * d
                    q.a = 1f
                }
            }
        }

        private fun rim(canvas: Canvas, k: Float, rainbowColors: Boolean) {
            val in0 = thick / 2f + 1f
            r.set(in0, in0, w - in0, hh - in0)
            val sh = if (rainbowColors) SweepGradient(w / 2f, hh / 2f, rainbow, null)
            else SweepGradient(w / 2f, hh / 2f, intArrayOf(c1, c2, c1), floatArrayOf(0f, 0.5f, 1f))
            m.reset(); m.setRotate((t * 70f * speed) % 360f, w / 2f, hh / 2f)
            sh.setLocalMatrix(m)
            p.shader = sh
            for (i in 3 downTo 1) {
                p.strokeWidth = thick * (1f + i * 0.95f)
                p.alpha = ((18 + 9 * (3 - i)) * k).toInt().coerceIn(0, 255)
                canvas.drawRoundRect(r, radius, radius, p)
            }
            p.strokeWidth = thick
            p.alpha = (235 * k).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(r, radius, radius, p)
            p.shader = null
            p.alpha = 255
        }

        private fun heart(canvas: Canvas, cx: Float, cy: Float, size: Float, paint: Paint) {
            path.reset()
            path.moveTo(cx, cy + size * 0.72f)
            path.cubicTo(cx - size * 1.35f, cy - size * 0.35f, cx - size * 0.55f, cy - size * 1.15f, cx, cy - size * 0.42f)
            path.cubicTo(cx + size * 0.55f, cy - size * 1.15f, cx + size * 1.35f, cy - size * 0.35f, cx, cy + size * 0.72f)
            path.close()
            canvas.drawPath(path, paint)
        }

        override fun onDraw(canvas: Canvas) {
            if (w <= 0f || hh <= 0f) return
            val now = System.nanoTime()
            val dt = if (lastN == 0L) 0f else ((now - lastN) / 1_000_000_000f).coerceIn(0f, 0.05f)
            lastN = now
            t += dt * speed
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND

            when (effect) {
                "multicolor" -> rim(canvas, 1f, true)
                "spotlight" -> {
                    val clear = Color.argb(0, Color.red(c1), Color.green(c1), Color.blue(c1))
                    val in0 = thick / 2f + 1f
                    r.set(in0, in0, w - in0, hh - in0)
                    val sh = SweepGradient(w / 2f, hh / 2f, intArrayOf(clear, c1, c2, clear), floatArrayOf(0f, 0.10f, 0.17f, 0.36f))
                    m.reset(); m.setRotate((t * 140f) % 360f, w / 2f, hh / 2f)
                    sh.setLocalMatrix(m)
                    p.shader = sh
                    for (i in 3 downTo 1) {
                        p.strokeWidth = thick * (1f + i * 1.1f)
                        p.alpha = 30 - i * 6
                        canvas.drawRoundRect(r, radius, radius, p)
                    }
                    p.strokeWidth = thick
                    p.alpha = 255
                    canvas.drawRoundRect(r, radius, radius, p)
                    p.shader = null
                    p.alpha = 255
                }
                "eclipse" -> {
                    val in0 = thick / 2f + 1f
                    r.set(in0, in0, w - in0, hh - in0)
                    val pulse = 0.5f + 0.5f * sin(t * 3.4f)
                    p.shader = null
                    p.color = c1
                    p.strokeWidth = thick * (1.6f + 0.9f * pulse)
                    p.alpha = (30 + 60 * pulse).toInt()
                    canvas.drawRoundRect(r, radius, radius, p)
                    p.color = c2
                    p.strokeWidth = thick
                    p.alpha = (110 + 90 * pulse).toInt()
                    canvas.drawRoundRect(r, radius, radius, p)
                    p.color = Color.WHITE
                    p.strokeWidth = 2.2f * d
                    p.alpha = (150 + 100 * pulse).toInt().coerceIn(0, 255)
                    canvas.drawRoundRect(r, radius, radius, p)
                }
                "echo" -> {
                    p.shader = null
                    val base = min(w, hh)
                    for (i in 0 until 3) {
                        val f = ((t * 0.42f) + i / 3f) % 1f
                        val inset = thick + f * base * 0.34f
                        if (w - 2 * inset <= 0f || hh - 2 * inset <= 0f) continue
                        r.set(inset, inset, w - inset, hh - inset)
                        p.color = if (i % 2 == 0) c1 else c2
                        p.strokeWidth = (2.4f - f) * d
                        p.alpha = ((1f - f) * 210).toInt().coerceIn(0, 255)
                        val rr = radius * (1f - f) + 10f * d
                        canvas.drawRoundRect(r, rr, rr, p)
                    }
                    p.alpha = 255
                }
                "glitter" -> {
                    rim(canvas, 0.32f, false)
                    p.style = Paint.Style.FILL
                    for (q in dots) {
                        q.ph += dt * 7f
                        val a = (0.25f + 0.75f * abs(sin(q.ph))) * q.a
                        p.color = if (q.a > 0.75f) c2 else c1
                        p.alpha = (a * 255).toInt().coerceIn(0, 255)
                        canvas.drawCircle(q.x, q.y, q.r, p)
                    }
                    p.alpha = 255
                }
                "bubble" -> {
                    rim(canvas, 0.28f, false)
                    for (q in dots) {
                        q.y += q.vy * dt
                        if (q.y < -20 * d) { q.y = hh + 20 * d; q.x = (Math.random() * w).toFloat() }
                        val x = q.x + sin(t * 1.6f + q.ph) * 8 * d
                        p.color = c1
                        p.strokeWidth = 1.4f * d
                        p.alpha = (q.a * 190).toInt()
                        canvas.drawCircle(x, q.y, q.r, p)
                        p.style = Paint.Style.FILL
                        p.alpha = (q.a * 55).toInt()
                        canvas.drawCircle(x - q.r * 0.3f, q.y - q.r * 0.3f, q.r * 0.28f, p)
                        p.style = Paint.Style.STROKE
                    }
                    p.alpha = 255
                }
                "heart" -> {
                    rim(canvas, 0.25f, false)
                    p.style = Paint.Style.FILL
                    for (q in dots) {
                        q.y += q.vy * dt
                        if (q.y < -30 * d) { q.y = hh + 30 * d; q.x = (Math.random() * w).toFloat() }
                        val x = q.x + sin(t * 1.2f + q.ph) * 10 * d
                        p.color = if (q.a > 0.7f) c2 else c1
                        p.alpha = (q.a * 225).toInt()
                        heart(canvas, x, q.y, q.r, p)
                    }
                    p.alpha = 255
                }
                "fireworks" -> {
                    rim(canvas, 0.22f, false)
                    p.style = Paint.Style.FILL
                    val g = 260f * d
                    for (q in dots) {
                        q.x += q.vx * dt
                        q.y += q.vy * dt
                        q.vy += g * dt
                        q.a -= dt * 0.55f
                        if (q.a <= 0f) {
                            q.x = w / 2f; q.y = hh * 0.16f
                            val ang = Math.random() * 6.2832
                            val sp = (140 + Math.random() * 420).toFloat() * d
                            q.vx = (Math.cos(ang) * sp).toFloat(); q.vy = (Math.sin(ang) * sp).toFloat()
                            q.a = 1f
                        }
                        p.color = if (q.r > 2.4f * d) c2 else c1
                        p.alpha = (q.a * 240).toInt().coerceIn(0, 255)
                        canvas.drawCircle(q.x, q.y, q.r, p)
                    }
                    p.alpha = 255
                }
                else -> rim(canvas, 1f, false)
            }
            p.style = Paint.Style.STROKE
        }
    }
}
