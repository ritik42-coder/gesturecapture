package com.raja.gesturecapture

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore

// Voice / typed commands -> direct tools. No AI model is needed for these: a command is matched against a few
// patterns (English and Hinglish), then run with the phone's own features. Anything it can't match is reported back.

sealed class Cmd {
    class Open(val q: String) : Cmd()
    class Act(val id: String, val say: String) : Cmd()
    class SendPhoto(val who: String, val kind: String) : Cmd()
    class Rename(val kind: String, val to: String) : Cmd()
    object Unknown : Cmd()
}

class Pic(val uri: Uri, val name: String, val mime: String)
class Person(val name: String, val number: String)

object Agent {
    private const val CC = "91"   // country code added to 10-digit numbers
    private val I = RegexOption.IGNORE_CASE
    private val reSend1 = Regex("""^(?:please\s+)?(?:send|share|forward)\s+(?:the\s+|my\s+|a\s+)?(?:(?:last|latest|recent|newest)\s+)?(photo|picture|pic|image|screenshot)\s+to\s+(.+?)(?:\s+(?:on|in|via|through|using)\s+(?:whats\s?app|wa))?$""", I)
    private val reSend2 = Regex("""^(.+?)\s+ko\s+(?:(?:last|latest|recent)\s+)?(photo|picture|pic|image|screenshot)\s+(?:bhej(?:o| do| de)?|send\s+kar(?:o| do))(?:\s+(?:on\s+)?whats\s?app(?:\s+pe)?)?$""", I)
    private val reRename = Regex("""^(?:please\s+)?rename\s+(?:the\s+|this\s+|my\s+|that\s+)?(?:(?:last|latest|recent|newest)\s+)?(photo|picture|pic|image|screenshot|video|file|download|document|pdf|audio)?\s*(?:file\s+)?(?:to|as)\s+(.+)$""", I)
    private val reOpen1 = Regex("""^(?:please\s+)?(?:open|launch|start|run)\s+(?:the\s+)?(.+?)(?:\s+app)?$""", I)
    private val reOpen2 = Regex("""^(.+?)\s+(?:kholo|khol do|khol|open karo|chalu karo|chalao|start karo)$""", I)

    private val acts = listOf(
        Regex("(screenshot|screen shot)", I) to Pair("shot", "Taking a screenshot"),
        Regex("(torch|flash ?light)", I) to Pair("torch", "Toggling the torch"),
        Regex("\\b(go )?home\\b", I) to Pair("home", "Going home"),
        Regex("\\b(go )?back\\b", I) to Pair("back", "Going back"),
        Regex("\\brecents?\\b", I) to Pair("recents", "Opening recents"),
        Regex("\\block\\b", I) to Pair("lock", "Locking the screen"),
        Regex("\\bnotifications?\\b", I) to Pair("notif", "Opening notifications"),
        Regex("(volume up|louder|increase volume)", I) to Pair("vol_up", "Volume up"),
        Regex("(volume down|quieter|lower volume|decrease volume)", I) to Pair("vol_down", "Volume down"),
        Regex("\\b(mute|silent)\\b", I) to Pair("mute", "Toggling sound"),
        Regex("\\b(next (song|track)|skip)\\b", I) to Pair("media_next", "Next track"),
        Regex("\\b(play|pause|resume)( the)? (music|song|video)\\b", I) to Pair("media_play", "Play / pause"),
        Regex("\\bcamera\\b", I) to Pair("camera", "Opening the camera")
    )

    fun parse(raw: String): Cmd {
        val t = raw.trim().trimEnd('.', '!', '?').replace(Regex("\\s+"), " ")
        reSend1.find(t)?.let { return Cmd.SendPhoto(it.groupValues[2].trim(), it.groupValues[1].lowercase()) }
        reSend2.find(t)?.let { return Cmd.SendPhoto(it.groupValues[1].trim(), it.groupValues[2].lowercase()) }
        reRename.find(t)?.let { return Cmd.Rename(it.groupValues[1].lowercase().ifBlank { "file" }, it.groupValues[2].trim().trim('"', '\'', '\u201c', '\u201d')) }
        reOpen1.find(t)?.let { return Cmd.Open(it.groupValues[1].trim()) }
        reOpen2.find(t)?.let { return Cmd.Open(it.groupValues[1].trim()) }
        for ((r, a) in acts) if (r.containsMatchIn(t)) return Cmd.Act(a.first, a.second)
        return Cmd.Unknown
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9\\u0900-\\u097f ]"), "").trim()

    private fun dist(a: String, b: String): Int {
        var p = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val c = IntArray(b.length + 1); c[0] = i
            for (j in 1..b.length) c[j] = minOf(p[j] + 1, c[j - 1] + 1, p[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            p = c
        }
        return p[b.length]
    }

    // best installed app for a spoken name ("whats app", "insta", "youtub")
    fun findApp(c: Context, q: String): Pair<String, String>? {
        val pm = c.packageManager
        val want = norm(q); val w2 = want.replace(" ", "")
        if (want.isEmpty()) return null
        var best: Pair<String, String>? = null; var bs = 0
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
            val pk = ri.activityInfo.packageName
            if (!seen.add(pk)) continue
            val label = ri.loadLabel(pm).toString()
            val l = norm(label); val l2 = l.replace(" ", "")
            val s = when {
                l == want || l2 == w2 -> 100
                l2.startsWith(w2) -> 85
                w2.length >= 3 && l2.contains(w2) -> 65
                l.split(" ").any { it == want } -> 60
                w2.length >= 4 && dist(l2.take(w2.length + 1), w2) <= 1 + w2.length / 6 -> 45
                else -> 0
            }
            if (s > bs) { bs = s; best = Pair(pk, label) }
        }
        return if (bs >= 45) best else null
    }

    // contacts whose name matches, best first (a person with several numbers appears once, preferring a mobile number)
    fun findPeople(c: Context, who: String): List<Person> {
        val q = who.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        val P = ContactsContract.CommonDataKinds.Phone
        val byName = LinkedHashMap<String, Pair<String, Boolean>>()   // name -> (number, isMobile)
        try {
            c.contentResolver.query(P.CONTENT_URI, arrayOf(P.DISPLAY_NAME, P.NUMBER, P.TYPE), "${P.DISPLAY_NAME} LIKE ?", arrayOf("%$who%"), null)?.use { cu ->
                while (cu.moveToNext()) {
                    val n = cu.getString(0) ?: continue; val num = cu.getString(1) ?: continue
                    val mob = cu.getInt(2) == P.TYPE_MOBILE
                    val old = byName[n]
                    if (old == null || (!old.second && mob)) byName[n] = Pair(num, mob)
                }
            }
        } catch (_: Exception) {}
        fun score(n: String): Int { val l = n.lowercase(); return if (l == q) 100 else if (l.startsWith(q)) 80 else if (l.split(" ").any { it == q }) 70 else 50 }
        return byName.entries.sortedByDescending { score(it.key) }.take(4).map { Person(it.key, it.value.first) }
    }

    // WhatsApp wants digits only, with the country code
    fun waNumber(n: String): String {
        var d = n.filter { it.isDigit() }
        if (n.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.drop(2)
        if (d.startsWith("0")) d = d.drop(1)
        return if (d.length == 10) CC + d else d
    }

    // the newest photo / screenshot / video / audio / download
    fun latest(c: Context, kind: String): Pic? {
        val R = MediaStore.MediaColumns.RELATIVE_PATH
        val uri: Uri; val sel: String
        when (kind.lowercase()) {
            "screenshot" -> { uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI; sel = "$R LIKE '%Screenshot%'" }
            "photo", "picture", "pic", "image" -> { uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI; sel = "$R NOT LIKE '%Screenshot%'" }
            "video" -> { uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI; sel = "1=1" }
            "audio" -> { uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI; sel = "1=1" }
            else -> { uri = MediaStore.Files.getContentUri("external"); sel = "$R LIKE 'Download/%'" }
        }
        val q = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.MediaColumns.DATE_ADDED))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, 1)
        }
        return try {
            c.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.MIME_TYPE), q, null)?.use { cu ->
                if (cu.moveToFirst()) Pic(ContentUris.withAppendedId(uri, cu.getLong(0)), cu.getString(1) ?: "file", cu.getString(2) ?: "") else null
            }
        } catch (_: Exception) { null }
    }
}
