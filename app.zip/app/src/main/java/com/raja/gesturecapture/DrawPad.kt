package com.raja.gesturecapture

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------------------------------------------
// Single-stroke shape recogniser: resample the finger path, scale it, compare with letter templates.
// Orientation is kept on purpose, so "left arrow" and "right arrow" are different gestures.
// ---------------------------------------------------------------------------------------------------
object Glyphs {
    private const val N = 48
    private const val LIMIT = 0.185f        // average point distance we accept
    private const val CLEAR = 0.05f        // best must beat the runner-up by this much

    private val names = ArrayList<String>()
    private val templates = ArrayList<FloatArray>()

    private fun arc(cx: Float, cy: Float, r: Float, a0: Float, a1: Float, n: Int = 18): FloatArray {
        val out = FloatArray((n + 1) * 2)
        for (i in 0..n) {
            val a = Math.toRadians((a0 + (a1 - a0) * i / n).toDouble())
            out[i * 2] = cx + r * cos(a).toFloat()
            out[i * 2 + 1] = cy + r * sin(a).toFloat()
        }
        return out
    }

    private fun add(name: String, vararg strokes: FloatArray) {
        for (st in strokes) {
            val p = ArrayList<PointF>()
            var i = 0
            while (i + 1 < st.size) { p.add(PointF(st[i], st[i + 1])); i += 2 }
            if (p.size < 2) continue
            templates.add(normalize(p)); names.add(name)
        }
    }

    init {
        // letters (screen coordinates: x right, y down)
        add("C", arc(0.5f, 0.5f, 0.45f, -55f, -305f))
        add("O", arc(0.5f, 0.5f, 0.45f, -90f, 270f, 22))
        add("S", floatArrayOf(0.78f, 0.16f, 0.62f, 0.09f, 0.42f, 0.11f, 0.28f, 0.22f, 0.26f, 0.34f,
            0.38f, 0.45f, 0.60f, 0.55f, 0.72f, 0.65f, 0.70f, 0.78f, 0.56f, 0.88f, 0.38f, 0.90f, 0.22f, 0.84f))
        add("W", floatArrayOf(0.15f, 0.15f, 0.32f, 0.85f, 0.50f, 0.35f, 0.68f, 0.85f, 0.85f, 0.15f))
        add("M", floatArrayOf(0.15f, 0.85f, 0.15f, 0.15f, 0.50f, 0.60f, 0.85f, 0.15f, 0.85f, 0.85f))
        add("V", floatArrayOf(0.15f, 0.15f, 0.50f, 0.85f, 0.85f, 0.15f))
        add("U", floatArrayOf(0.15f, 0.15f, 0.15f, 0.58f, 0.22f, 0.78f, 0.38f, 0.88f, 0.62f, 0.88f, 0.78f, 0.78f, 0.85f, 0.58f, 0.85f, 0.15f))
        add("N", floatArrayOf(0.15f, 0.85f, 0.15f, 0.15f, 0.85f, 0.85f, 0.85f, 0.15f))
        add("Z", floatArrayOf(0.15f, 0.15f, 0.85f, 0.15f, 0.15f, 0.85f, 0.85f, 0.85f))
        add("L", floatArrayOf(0.20f, 0.15f, 0.20f, 0.85f, 0.85f, 0.85f))
        // arrows, drawn plain and with a head
        add("left", floatArrayOf(0.85f, 0.50f, 0.15f, 0.50f),
            floatArrayOf(0.85f, 0.50f, 0.15f, 0.50f, 0.38f, 0.28f),
            floatArrayOf(0.85f, 0.50f, 0.15f, 0.50f, 0.38f, 0.72f))
        add("right", floatArrayOf(0.15f, 0.50f, 0.85f, 0.50f),
            floatArrayOf(0.15f, 0.50f, 0.85f, 0.50f, 0.62f, 0.28f),
            floatArrayOf(0.15f, 0.50f, 0.85f, 0.50f, 0.62f, 0.72f))
        add("up", floatArrayOf(0.50f, 0.85f, 0.50f, 0.15f),
            floatArrayOf(0.50f, 0.85f, 0.50f, 0.15f, 0.28f, 0.38f),
            floatArrayOf(0.50f, 0.85f, 0.50f, 0.15f, 0.72f, 0.38f))
        add("down", floatArrayOf(0.50f, 0.15f, 0.50f, 0.85f),
            floatArrayOf(0.50f, 0.15f, 0.50f, 0.85f, 0.28f, 0.62f),
            floatArrayOf(0.50f, 0.15f, 0.50f, 0.85f, 0.72f, 0.62f))
    }

    fun keys() = listOf("C", "O", "S", "W", "M", "V", "U", "N", "Z", "L", "left", "right", "up", "down")

    fun glyph(k: String) = when (k) { "left" -> "←"; "right" -> "→"; "up" -> "↑"; "down" -> "↓"; else -> k }

    fun label(k: String) = when (k) {
        "left" -> "Left arrow"; "right" -> "Right arrow"; "up" -> "Up arrow"; "down" -> "Down arrow"
        else -> "Letter $k"
    }

    private fun dist(a: PointF, b: PointF): Float { val dx = a.x - b.x; val dy = a.y - b.y; return sqrt(dx * dx + dy * dy) }

    private fun resample(p: List<PointF>, n: Int): List<PointF> {
        var total = 0.0
        for (i in 1 until p.size) total += dist(p[i - 1], p[i])
        if (total < 0.0001) return List(n) { PointF(p[0].x, p[0].y) }
        val iv = total / (n - 1)
        val out = ArrayList<PointF>(n); out.add(PointF(p[0].x, p[0].y))
        var prev = PointF(p[0].x, p[0].y); var d = 0.0; var i = 1
        while (i < p.size) {
            val step = dist(prev, p[i])
            if (d + step >= iv) {
                val t = ((iv - d) / step).toFloat()
                val q = PointF(prev.x + t * (p[i].x - prev.x), prev.y + t * (p[i].y - prev.y))
                out.add(q); prev = q; d = 0.0
            } else { d += step; prev = p[i]; i++ }
        }
        while (out.size < n) out.add(PointF(p[p.size - 1].x, p[p.size - 1].y))
        return out
    }

    // resample, scale to unit size (aspect kept) and centre on the origin
    private fun normalize(p: List<PointF>): FloatArray {
        val r = resample(p, N)
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (q in r) { minX = min(minX, q.x); maxX = max(maxX, q.x); minY = min(minY, q.y); maxY = max(maxY, q.y) }
        val span = max(maxX - minX, maxY - minY)
        val k = if (span < 0.0001f) 1f else 1f / span
        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f
        val out = FloatArray(N * 2)
        for (i in 0 until N) { out[i * 2] = (r[i].x - cx) * k; out[i * 2 + 1] = (r[i].y - cy) * k }
        return out
    }

    // returns the matched key, or null when the drawing is not close to anything
    fun match(points: List<PointF>): String? {
        if (points.size < 6) return null
        val q = normalize(points)
        var best = 0f; var bestI = -1; var second = Float.MAX_VALUE
        for (t in templates.indices) {
            val tpl = templates[t]
            var sum = 0f
            var i = 0
            while (i < N) {
                val dx = q[i * 2] - tpl[i * 2]; val dy = q[i * 2 + 1] - tpl[i * 2 + 1]
                sum += sqrt(dx * dx + dy * dy); i++
            }
            val sc = sum / N
            if (sc < best || bestI < 0) { if (bestI >= 0) second = best; best = sc; bestI = t }
            else if (sc < second) second = sc
        }
        if (bestI < 0 || best > LIMIT) return null
        if (second < Float.MAX_VALUE && second - best < CLEAR && best > LIMIT * 0.45f) return null
        return names[bestI]
    }
}

// ---------------------------------------------------------------------------------------------------
// Draw pad: a full-screen layer where you draw a letter; the recognised letter fires its own action.
// Also an optional floating pen button that opens the pad.
// ---------------------------------------------------------------------------------------------------
class DrawPad(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var pen: View? = null
    private var hint: TextView? = null
    private var path = Path()
    private val pts = ArrayList<PointF>()
    private var wait: Runnable? = null
    private var closeR: Runnable? = null

    private fun dp(v: Int) = (v * s.resources.displayMetrics.density).toInt()
    private fun cfg(): JSONObject = try { JSONObject(Prefs.sp(s).getString("dpad", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun buzz(ms: Long = 35) { try { s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(ms, 255)) } catch (_: Exception) {} }
    private fun lp(w: Int, ht: Int, f: Int = 0) = WindowManager.LayoutParams(w, ht, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or f, PixelFormat.TRANSLUCENT)

    fun sync() { h.post { if (cfg().optBoolean("handle", false)) showPen() else hidePen() } }
    fun destroy() { h.post { hidePen(); close() } }

    fun isOpen() = root != null

    // ---- the pad ----
    fun open() { h.post {
        if (root != null) return@post
        hidePen()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = dp(7).toFloat(); strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND; color = Color.WHITE
        }
        val sheet = object : View(s) {
            override fun onDraw(c: Canvas) {
                c.drawColor(0xAA05070F.toInt())
                paint.setShadowLayer(dp(6).toFloat(), 0f, 0f, 0x99000000.toInt())
                c.drawPath(path, paint)
            }
        }
        val bar = LinearLayout(s); bar.gravity = Gravity.CENTER_VERTICAL
        val g = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0xF0151A2E.toInt()); setStroke(dp(1), 0x22FFFFFF) }
        bar.background = g; bar.setPadding(dp(16), dp(8), dp(8), dp(8))
        val t = TextView(s); t.text = "Draw a letter · C W M O S V U N Z L · or an arrow"
        t.setTextColor(0xFFFFFFFF.toInt()); t.textSize = 13f; hint = t
        bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val x = TextView(s); x.text = "✕"; x.textSize = 18f; x.setTextColor(0xFFFFFFFF.toInt()); x.setPadding(dp(14), dp(4), dp(14), dp(4))
        x.setOnClickListener { close() }; bar.addView(x)

        val f = FrameLayout(s)
        f.addView(sheet, FrameLayout.LayoutParams(-1, -1))
        f.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(70) })

        sheet.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    path = Path(); pts.clear()
                    path.moveTo(ev.x, ev.y); pts.add(PointF(ev.x, ev.y))
                    hint?.text = "…"
                    wait?.let { h.removeCallbacks(it) }
                    sheet.invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    path.lineTo(ev.x, ev.y); pts.add(PointF(ev.x, ev.y)); sheet.invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val k = Glyphs.match(pts)
                    if (k == null) {
                        hint?.text = "Not sure — try again"
                        path = Path(); pts.clear(); buzz(18); sheet.invalidate()
                    } else {
                        hint?.text = "✓  " + Glyphs.glyph(k)
                        buzz(45); sheet.invalidate()
                        val r = Runnable { close(); s.drawGesture(k) }
                        wait = r; h.postDelayed(r, 260)
                    }
                }
            }
            true
        }
        val p = lp(-1, -1, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        try { wm.addView(f, p) } catch (_: Exception) { return@post }
        root = f
        val to = Runnable { close() }; closeR = to; h.postDelayed(to, 9000)
    } }

    fun close() { h.post {
        closeR?.let { h.removeCallbacks(it) }; closeR = null
        wait?.let { h.removeCallbacks(it) }; wait = null
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; hint = null; path = Path(); pts.clear()
        sync()
    } }

    // ---- optional floating pen button ----
    private fun showPen() {
        if (pen != null) return
        val v = TextView(s)
        v.text = "✎"; v.textSize = 19f; v.setTextColor(Color.WHITE); v.gravity = Gravity.CENTER
        v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99222842.toInt()); setStroke(dp(2), 0x66FFFFFF) }
        val dm = s.resources.displayMetrics
        val p = lp(dp(42), dp(42)); p.gravity = Gravity.TOP or Gravity.START
        p.x = dm.widthPixels - dp(50); p.y = (dm.heightPixels * 0.58).toInt()
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var drag = false
        v.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = p.x; oy = p.y; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt(); val dy = (ev.rawY - sy).toInt()
                    if (abs(dx) + abs(dy) > dp(12)) drag = true
                    if (drag) { p.x = ox + dx; p.y = oy + dy; try { wm.updateViewLayout(v, p) } catch (_: Exception) {} }
                }
                MotionEvent.ACTION_UP -> if (!drag) { buzz(); open() }
            }
            true
        }
        try { wm.addView(v, p) } catch (_: Exception) { return }
        pen = v
    }

    private fun hidePen() {
        pen?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        pen = null
    }
}
