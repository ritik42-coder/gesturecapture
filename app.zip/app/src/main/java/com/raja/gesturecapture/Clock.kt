package com.raja.gesturecapture

import android.os.SystemClock

// Built-in countdown timer + stopwatch shown by the island (survives as long as the accessibility service runs).
class ClockWatcher {
    var kind = ""   // "timer", "sw" or "" (nothing running)
        private set
    var running = false
        private set
    private var endAt = 0L
    private var leftMs = 0L
    private var startAt = 0L
    private var accMs = 0L

    private fun now() = SystemClock.elapsedRealtime()
    fun active() = kind != ""

    fun startTimer(sec: Int) { kind = "timer"; leftMs = sec * 1000L; endAt = now() + leftMs; running = true }
    fun startSw() { kind = "sw"; accMs = 0; startAt = now(); running = true }
    fun pause() {
        if (!running) return
        if (kind == "timer") leftMs = maxOf(endAt - now(), 0) else accMs += now() - startAt
        running = false
    }
    fun resume() {
        if (running || kind == "") return
        if (kind == "timer") endAt = now() + leftMs else startAt = now()
        running = true
    }
    fun toggle() { if (running) pause() else resume() }
    fun addMin() { if (kind != "timer") return; if (running) endAt += 60000 else leftMs += 60000 }
    fun reset() { kind = ""; running = false; leftMs = 0; accMs = 0 }

    fun ms(): Long = when (kind) {
        "timer" -> if (running) maxOf(endAt - now(), 0) else leftMs
        "sw" -> if (running) accMs + now() - startAt else accMs
        else -> 0L
    }
    fun done() = kind == "timer" && running && endAt <= now()

    fun text(): String {
        val t = if (kind == "timer") (ms() + 999) / 1000 else ms() / 1000
        val h = t / 3600; val m = t % 3600 / 60; val s = t % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
    }
}
