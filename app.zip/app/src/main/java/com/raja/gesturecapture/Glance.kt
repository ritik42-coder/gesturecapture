package com.raja.gesturecapture

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import org.json.JSONObject
import java.util.Date
import kotlin.math.min

// ---------------------------------------------------------------------------------------------------
// Always-on style glance. While the phone is charging, waking the screen (or plugging in) brings up
// a dim clock + battery strip for a few seconds, then it fades away. Tap it to dismiss at once.
// ---------------------------------------------------------------------------------------------------
class Glance(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var v: View? = null
    private var end: Runnable? = null

    private fun sec(): JSONObject = try {
        JSONObject(Prefs.sp(s).getString("fx", "{}") ?: "{}").optJSONObject("gl") ?: JSONObject()
    } catch (_: Exception) { JSONObject() }

    private fun dp(x: Int) = (x * s.resources.displayMetrics.density).toInt()
    fun on() = sec().optBoolean("on", false)

    fun sync() { if (!on()) hide() }
    fun destroy() { hide() }

    fun hide() { h.post {
        end?.let { h.removeCallbacks(it) }; end = null
        v?.let { it.animate().alpha(0f).setDuration(260).withEndAction {
            try { wm.removeView(it) } catch (_: Exception) {}
        }.start() }
        v = null
    } }

    private fun plugged(): Boolean {
        val b = s.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun pct(): Int {
        val b = s.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / maxOf(b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100, 1)
    }

    fun show(force: Boolean = false, secs: Int = 0) { h.post {
        if (!force && !on()) return@post
        if (!force && !plugged()) return@post
        if (v != null) return@post
        val c = sec()
        val dm = s.resources.displayMetrics
        val cw = min((dm.widthPixels * 0.82f).toInt(), dp(330))
        val ch = dp(78)
        val g = GlanceView(s)
        g.dim = c.optInt("dim", 62).coerceIn(20, 100) / 100f
        g.c1 = try { Color.parseColor(c.optString("c1", "#22D3EE")) } catch (_: Exception) { 0xFF22D3EE.toInt() }
        g.pct = pct()
        val p = WindowManager.LayoutParams(cw, ch, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = (dm.heightPixels * (c.optInt("y", 62).coerceIn(20, 85)) / 100)
        try { wm.addView(g, p) } catch (_: Exception) { return@post }
        v = g
        g.alpha = 0f; g.translationY = dp(18).toFloat()
        g.animate().alpha(1f).translationY(0f).setDuration(300).start()
        g.setOnClickListener { hide() }
        val ms = (if (secs > 0) secs else c.optInt("secs", 7).coerceIn(3, 20)) * 1000L
        val r = Runnable { hide() }
        end = r
        h.postDelayed(r, ms)
    } }

    private class GlanceView(c: Context) : View(c) {
        var pct = 0
        var dim = 0.62f
        var c1 = 0xFF22D3EE.toInt()
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
        private val box = RectF()

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat(); val hh = height.toFloat()
            if (w <= 0f || hh <= 0f) return
            val d = resources.displayMetrics.density
            val r = hh / 2f
            fill.shader = LinearGradient(0f, 0f, w, hh, intArrayOf(0xF20B1120.toInt(), 0xF2050810.toInt()), null, Shader.TileMode.CLAMP)
            box.set(0f, 0f, w, hh)
            canvas.drawRoundRect(box, r, r, fill)
            fill.shader = null
            line.style = Paint.Style.STROKE
            line.strokeWidth = 1f * d
            line.color = 0x1FFFFFFF
            canvas.drawRoundRect(box, r, r, line)

            txt.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            txt.color = Color.WHITE
            txt.textAlign = Paint.Align.LEFT
            txt.textSize = 30f * d
            val t = DateFormat.format(if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm", Date()).toString()
            canvas.drawText(t, 22f * d, hh * 0.56f, txt)

            txt.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            txt.textSize = 10.5f * d
            txt.color = 0x99FFFFFF.toInt()
            val day = DateFormat.format("EEE, d MMM", Date()).toString()
            canvas.drawText(day, 23f * d, hh * 0.80f, txt)

            // battery, right side
            val bw = 40f * d
            val bh = 15f * d
            val bx = w - bw - 26f * d
            val by = hh / 2f - bh / 2f + 2f * d
            line.strokeWidth = 1.6f * d
            line.color = 0x99FFFFFF.toInt()
            box.set(bx, by, bx + bw, by + bh)
            canvas.drawRoundRect(box, 4f * d, 4f * d, line)
            box.set(bx + bw + 1.5f * d, by + bh * 0.32f, bx + bw + 4f * d, by + bh * 0.68f)
            line.style = Paint.Style.FILL
            canvas.drawRoundRect(box, 1.5f * d, 1.5f * d, line)
            line.color = c1
            box.set(bx + 2.5f * d, by + 2.5f * d, bx + 2.5f * d + (bw - 5f * d) * (pct / 100f), by + bh - 2.5f * d)
            canvas.drawRoundRect(box, 2.5f * d, 2.5f * d, line)

            txt.textAlign = Paint.Align.RIGHT
            txt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            txt.textSize = 13f * d
            txt.color = 0xE6FFFFFF.toInt()
            canvas.drawText("$pct%", w - 26f * d, by - 6f * d, txt)

            // a small bolt above the bar
            val px = bx + bw / 2f
            val py = by - 26f * d
            val pth = Path()
            pth.moveTo(px + 1.5f * d, py - 7f * d)
            pth.lineTo(px - 3.5f * d, py + 1f * d)
            pth.lineTo(px - 0.5f * d, py + 1f * d)
            pth.lineTo(px - 2f * d, py + 8f * d)
            pth.lineTo(px + 4f * d, py - 1.5f * d)
            pth.lineTo(px + 1f * d, py - 1.5f * d)
            pth.close()
            line.color = c1
            canvas.drawPath(pth, line)

            // overall dimness: a black veil over the card, so the fade-in animation still works
            line.style = Paint.Style.FILL
            line.color = Color.argb((255 * (1f - dim) * 0.85f).toInt().coerceIn(0, 255), 0, 0, 0)
            box.set(0f, 0f, w, hh)
            canvas.drawRoundRect(box, r, r, line)
        }
    }
}
