package com.raja.gesturecapture

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import kotlin.math.max
import kotlin.math.min

// Empty listener: enabling "Notification access" for this service is what allows reading the active music sessions.
class MediaListener : NotificationListenerService()

// Watches the currently active media session (Spotify, YouTube Music, local players...) and exposes track info + controls.
class MusicWatcher(private val ctx: Context, private val h: Handler, private val changed: () -> Unit) {
    private val msm = ctx.getSystemService(MediaSessionManager::class.java)
    private val cn = ComponentName(ctx, MediaListener::class.java)
    private var ctrl: MediaController? = null
    private var started = false
    private var demo = false

    var allowed = false

        private set
    var title = ""
        private set
    var artist = ""
        private set
    var art: Bitmap? = null
        private set
    var tint = 0
        private set
    var pkg = ""
        private set
    var playing = false
        private set
    var dur = 0L
        private set
    private var pos0 = 0L
    private var t0 = 0L
    private var speed = 1f
    private var lastPlay = 0L

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { load(); changed() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { load(); changed() }
        override fun onSessionDestroyed() { pick(null); changed() }
    }
    private val lis = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list); changed() }

    fun start() {
        if (started) return
        try {
            msm.addOnActiveSessionsChangedListener(lis, cn, h)
            started = true; allowed = true
            pick(null); changed()
        } catch (_: SecurityException) { allowed = false } catch (_: Exception) { allowed = false }
    }

    fun stop() {
        try { msm.removeOnActiveSessionsChangedListener(lis) } catch (_: Exception) {}
        try { ctrl?.unregisterCallback(cb) } catch (_: Exception) {}
        ctrl = null; started = false
    }

    private fun pick(list: List<MediaController>?) {
        val l = list ?: try { msm.getActiveSessions(cn) } catch (_: Exception) { emptyList<MediaController>() }
        val best = l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
        if (best?.sessionToken != ctrl?.sessionToken) {
            try { ctrl?.unregisterCallback(cb) } catch (_: Exception) {}
            ctrl = best
            try { best?.registerCallback(cb, h) } catch (_: Exception) {}
        }
        load()
    }

    private fun load() {
        if (demo) return
        val c = ctrl
        if (c == null) { playing = false; title = ""; artist = ""; art = null; pkg = ""; return }
        val m = c.metadata
        val st = c.playbackState
        title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: m?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        dur = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val bm = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bm !== art) { art = bm; tint = tintOf(bm) }
        pkg = c.packageName ?: ""
        val was = playing
        playing = st?.state == PlaybackState.STATE_PLAYING || st?.state == PlaybackState.STATE_BUFFERING
        pos0 = max(st?.position ?: 0L, 0L)
        t0 = st?.lastPositionUpdateTime ?: 0L
        speed = st?.playbackSpeed ?: 1f
        if (playing || was) lastPlay = SystemClock.elapsedRealtime()
    }

    // dark version of the artwork's average colour, used as the island glow
    private fun tintOf(b: Bitmap?): Int {
        if (b == null) return 0
        return try {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = min(1f, hsv[1] * 1.1f); hsv[2] = min(hsv[2], 0.4f).coerceAtLeast(0.22f)
            Color.HSVToColor(hsv)
        } catch (_: Exception) { 0 }
    }

    // a session worth showing: playing now, or paused less than 45 s ago
    fun active(): Boolean = demo || (ctrl != null && title.isNotEmpty() && (playing || SystemClock.elapsedRealtime() - lastPlay < 45000))

    fun position(): Long {
        val p = if (playing) pos0 + ((SystemClock.elapsedRealtime() - t0) * speed).toLong() else pos0
        return if (dur > 0) p.coerceIn(0L, dur) else max(p, 0L)
    }

    fun toggle() { if (demo) return; try { if (playing) ctrl?.transportControls?.pause() else ctrl?.transportControls?.play() } catch (_: Exception) {} }
    fun next() { if (!demo) try { ctrl?.transportControls?.skipToNext() } catch (_: Exception) {} }
    fun prev() { if (!demo) try { ctrl?.transportControls?.skipToPrevious() } catch (_: Exception) {} }
    fun seek(f: Float) { if (!demo && dur > 0) try { ctrl?.transportControls?.seekTo((dur * f).toLong()) } catch (_: Exception) {} }

    fun open() {
        if (demo) return
        try {
            val pi: PendingIntent? = ctrl?.sessionActivity
            if (pi != null) { pi.send(); return }
        } catch (_: Exception) {}
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun appName(): String = try { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { "Music" }

    // fake track so the island can be previewed without any player running
    fun startDemo() {
        demo = true; title = "Midnight Drive"; artist = "Neon Waves"; art = null; tint = 0xFF3B1D6B.toInt(); pkg = ""
        playing = true; dur = 214000L; pos0 = 63000L; t0 = SystemClock.elapsedRealtime(); speed = 1f
        changed()
        h.postDelayed({ demo = false; load(); changed() }, 7000)
    }
}
