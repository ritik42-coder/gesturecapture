package com.raja.gesturecapture

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------------
// Charging show. When the screen goes off while the phone is charging, this wakes the display for a
// few seconds with the full animation: clock, percent and the time until the battery is full, over
// five canvas styles. Tapping it, or the timer running out, puts the screen back to sleep.
// ---------------------------------------------------------------------------------------------------
object ChargeShow {
    private const val COOLDOWN = 45_000L
    @Volatile private var lastAt = 0L
    @Volatile private var open = false

    private fun sp() = AppCtx.get()?.let { Prefs.sp(it) }
    fun on(): Boolean = sp()?.getBoolean("cs_on", false) ?: false
    fun secs(): Int = sp()?.getInt("cs_secs", 8) ?: 8
    fun style(): Int = sp()?.getInt("cs_style", 0) ?: 0
    fun setOn(v: Boolean) { sp()?.edit()?.putBoolean("cs_on", v)?.apply() }
    fun setSecs(v: Int) { sp()?.edit()?.putInt("cs_secs", v.coerceIn(4, 30))?.apply() }
    fun setStyle(v: Int) { sp()?.edit()?.putInt("cs_style", v.coerceIn(0, 4))?.apply() }

    fun isOpen() = open

    // called from the service when the screen turns off
    fun maybeShow(c: Context): Boolean {
        if (!on()) return false
        if (open) return false
        val now = System.currentTimeMillis()
        if (now - lastAt < COOLDOWN) return false
        lastAt = now
        return show(c)
    }

    fun show(c: Context): Boolean {
        if (open) return false
        open = true
        val i = Intent(c, ChargeShowActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or
                Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        return try {
            c.startActivity(i)
            true
        } catch (_: Exception) {
            open = false
            false
        }
    }

    fun closed() { open = false }

    fun dismiss() {
        ChargeShowActivity.current?.finishQuietly()
    }

    fun preview(c: Context) { lastAt = System.currentTimeMillis(); show(c) }
}

// a tiny holder so the service can reach the app context without plumbing
object AppCtx {
    var ctx: Context? = null
    fun get(): Context? = ctx
}

class ChargeShowActivity : Activity() {
    companion object {
        @Volatile var current: ChargeShowActivity? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var view: ChargeView? = null
    private var clock: TextView? = null
    private var date: TextView? = null
    private var pct: TextView? = null
    private var status: TextView? = null
    private var eta: TextView? = null
    private var dots: LinearLayout? = null
    private var nameTag: TextView? = null
    private var dismissAt = 0L
    private var lockedByUs = false
    private var rec: BroadcastReceiver? = null

    private var level = 0
    private var charging = true
    private var full = false
    private var etaMin = -1
    private var target = 0f

    private fun dp(x: Int) = LockUi.dp(this, x)
    private fun dpf(x: Float) = LockUi.dpf(this, x)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        current = this
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = 0xFF02030A.toInt()
        window.navigationBarColor = 0xFF02030A.toInt()
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        setContentView(build())
        readBattery()
        startClock()
        h.postDelayed({ readBattery() }, 900)

        val secs = ChargeShow.secs()
        dismissAt = System.currentTimeMillis() + secs * 1000L
        h.postDelayed({ close(true) }, secs * 1000L + 60)
    }

    override fun onDestroy() {
        ChargeShow.closed()
        current = null
        h.removeCallbacksAndMessages(null)
        try { rec?.let { unregisterReceiver(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    // ---------------------------------------------------------------- ui
    private fun build(): View {
        val dm = resources.displayMetrics
        val hgt = dm.heightPixels
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF02030A.toInt())

        val v = ChargeView(this)
        v.style = ChargeShow.style()
        view = v
        root.addView(v, FrameLayout.LayoutParams(-1, -1))

        val vig = View(this)
        vig.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            orientation = android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM
            colors = intArrayOf(Color.TRANSPARENT, 0x66000000)
        }
        root.addView(vig, FrameLayout.LayoutParams(-1, -1))

        // clock
        val cbox = LinearLayout(this)
        cbox.orientation = LinearLayout.VERTICAL
        cbox.gravity = Gravity.CENTER_HORIZONTAL
        val c1 = TextView(this)
        c1.text = "--:--"
        c1.setTextColor(Color.WHITE)
        c1.textSize = 46f
        c1.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        c1.letterSpacing = 0.02f
        c1.gravity = Gravity.CENTER
        clock = c1
        cbox.addView(c1)
        val c2 = TextView(this)
        c2.setTextColor(0x8CFFFFFF.toInt())
        c2.textSize = 14f
        c2.gravity = Gravity.CENTER
        date = c2
        cbox.addView(c2, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        root.addView(cbox, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { topMargin = (hgt * 0.06f).toInt() })

        // percent
        val pbox = LinearLayout(this)
        pbox.orientation = LinearLayout.HORIZONTAL
        pbox.gravity = Gravity.CENTER
        val p1 = TextView(this)
        p1.text = "0"
        p1.setTextColor(Color.WHITE)
        p1.textSize = 86f
        p1.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        p1.letterSpacing = -0.03f
        pct = p1
        pbox.addView(p1)
        val p2 = TextView(this)
        p2.text = "%"
        p2.setTextColor(0xBFFFFFFF.toInt())
        p2.textSize = 30f
        p2.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        pbox.addView(p2, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12); leftMargin = dp(3) })
        root.addView(pbox, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))

        // status + eta
        val ibox = LinearLayout(this)
        ibox.orientation = LinearLayout.VERTICAL
        ibox.gravity = Gravity.CENTER_HORIZONTAL
        val s1 = TextView(this)
        s1.setTextColor(Color.WHITE)
        s1.textSize = 19f
        s1.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        s1.gravity = Gravity.CENTER
        status = s1
        ibox.addView(s1)
        val s2 = TextView(this)
        s2.setTextColor(0x8CFFFFFF.toInt())
        s2.textSize = 14f
        s2.gravity = Gravity.CENTER
        eta = s2
        ibox.addView(s2, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        root.addView(ibox, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = (hgt * 0.13f).toInt() })

        // theme name toast
        val nm = TextView(this)
        nm.setTextColor(0x66FFFFFF.toInt())
        nm.textSize = 12f
        nm.gravity = Gravity.CENTER
        nm.alpha = 0f
        nameTag = nm
        root.addView(nm, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = (hgt * 0.075f).toInt() })

        // dots
        val drow = LinearLayout(this)
        drow.gravity = Gravity.CENTER
        dots = drow
        for (i in 0 until 5) {
            val b = View(this)
            b.setOnClickListener { pick(i) }
            drow.addView(b, LinearLayout.LayoutParams(dp(8), dp(8)).apply { setMargins(dp(5), 0, dp(5), 0) })
        }
        root.addView(drow, FrameLayout.LayoutParams(-1, dp(20), Gravity.BOTTOM).apply { bottomMargin = (hgt * 0.045f).toInt() })
        paintDots()
        showName(ChargeView.NAMES[ChargeShow.style()])

        // swipe between styles, tap to close
        var x0 = 0f; var y0 = 0f
        root.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { x0 = ev.rawX; y0 = ev.rawY }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.rawX - x0
                    val dy = ev.rawY - y0
                    if (abs(dx) > dpf(52f) && abs(dx) > abs(dy)) pick((view?.style ?: 0) + if (dx < 0) 1 else -1)
                    else if (abs(dx) < dpf(12f) && abs(dy) < dpf(12f)) close(true)
                }
            }
            true
        }
        return root
    }

    private fun paintDots() {
        val row = dots ?: return
        val cur = view?.style ?: 0
        for (i in 0 until row.childCount) {
            val b = row.getChildAt(i)
            val on = i == cur
            val g = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = dpf(8f)
                setColor(if (on) Color.WHITE else 0x47FFFFFF)
            }
            b.background = g
            val lp = b.layoutParams as LinearLayout.LayoutParams
            lp.width = dp(if (on) 24 else 8)
            lp.height = dp(8)
            b.layoutParams = lp
        }
    }

    private fun pick(i: Int) {
        val n = ((i % 5) + 5) % 5
        val v = view ?: return
        if (v.style == n) return
        v.style = n
        v.fade = 0f
        ChargeShow.setStyle(n)
        paintDots()
        showName(ChargeView.NAMES[n])
        LockUi.buzz(this, 14, 110)
    }

    private fun showName(t: String) {
        val nm = nameTag ?: return
        nm.text = t
        nm.animate().cancel()
        nm.animate().alpha(1f).setDuration(220).withEndAction {
            nm.animate().alpha(0f).setDuration(500).setStartDelay(1300).start()
        }.start()
    }

    // ---------------------------------------------------------------- data
    private fun readBattery() {
        val b = try { registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) } catch (_: Exception) { null }
        val scale = max(b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100, 1)
        level = (b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 / scale
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        full = st == BatteryManager.BATTERY_STATUS_FULL || level >= 100
        if (!charging) { close(false); return }
        etaMin = estimateMinutes(level)
        val v = view ?: return
        if (v.target == 0f && v.level == 0f) v.level = level.toFloat()   // first reading: no jump
        v.target = level.toFloat()
        v.charging = charging
        paintText()
    }

    // minutes until full: measured rate first, then a sane fallback
    private fun estimateMinutes(lvl: Int): Int {
        if (lvl >= 100) return 0
        val sp = Prefs.sp(this)
        val now = System.currentTimeMillis()
        val l0 = sp.getInt("cs_lvl", -1)
        val t0 = sp.getLong("cs_ts", 0L)
        var rate = 0f                              // percent per minute
        if (l0 in 1..100 && t0 > 0L && now > t0 && lvl > l0) {
            val mins = (now - t0) / 60000f
            if (mins > 1.5f) rate = (lvl - l0) / mins
        }
        if (l0 < 0 || lvl < l0 || t0 == 0L) sp.edit().putInt("cs_lvl", lvl).putLong("cs_ts", now).apply()
        return if (rate > 0.05f) ((100 - lvl) / rate).toInt().coerceIn(1, 400)
        else ((100 - lvl) * 0.55f).toInt().coerceIn(1, 400)
    }

    private fun paintText() {
        pct?.text = (view?.level ?: level.toFloat()).toInt().toString()
        status?.text = when {
            !charging -> "Not charging"
            full -> "Fully charged"
            (view?.level ?: 0f) < 80f -> "Fast charging"
            else -> "Charging slowly"
        }
        eta?.text = when {
            !charging -> "Plug in to charge"
            full -> "Battery is at 100%"
            else -> if (etaMin >= 60) "${etaMin / 60} h ${etaMin % 60} min until full" else "$etaMin min until full"
        }
    }

    private fun startClock() {
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dfm = SimpleDateFormat("EEEE d MMMM", Locale.getDefault())
        val r = object : Runnable {
            override fun run() {
                val d = Date()
                clock?.text = fmt.format(d)
                date?.text = dfm.format(d)
                readBattery()          // keeps the percent, the status and the estimate live
                h.postDelayed(this, 1000)
            }
        }
        h.post(r)
    }

    // ---------------------------------------------------------------- close
    private fun close(sleep: Boolean) {
        if (isFinishing) return
        ChargeShow.closed()
        if (sleep && !lockedByUs) {
            lockedByUs = true
            try {
                GestureService.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            } catch (_: Exception) {}
        }
        finishQuietly()
    }

    fun finishQuietly() {
        try { finish() } catch (_: Exception) {}
        @Suppress("DEPRECATION")
        try { overridePendingTransition(0, 0) } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { close(true) }
}

// ---------------------------------------------------------------------------------------------------
// The canvas. Five styles ported one to one: Port Flow, Bolt Core, Aurora Tide, Orbit Core, LED Bars.
// ---------------------------------------------------------------------------------------------------
class ChargeView(c: Context) : View(c) {
    companion object {
        val NAMES = arrayOf("Port Flow", "Bolt Core", "Aurora Tide", "Orbit Core", "LED Bars")
    }

    var style = 0
        set(v) { field = v.coerceIn(0, 4); invalidate() }
    var level = 0f          // displayed percent
    var target = 0f         // real percent
    var charging = true
    var fade = 1f

    private val den = resources.displayMetrics.density
    private fun d(x: Float) = x * den

    private var t = 0f
    private var last = 0L
    private var hue = 8f
    private var W = 0f
    private var H = 0f
    private var cx = 0f
    private var cy = 0f
    private lateinit var cv: Canvas

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val tmp = Path()
    private val rect = RectF()

    private var sprite: Bitmap? = null
    private var spriteHue = -99f

    private val dust = ArrayList<FloatArray>()
    private val parts = ArrayList<FloatArray>()
    private val streaks = ArrayList<FloatArray>()
    private val orbit = ArrayList<FloatArray>()
    private val arcs = ArrayList<FloatArray>()
    private var arcT = 0f
    private var pk = FloatArray(0)

    init {
        for (i in 0 until 36) dust.add(floatArrayOf(Math.random().toFloat(), Math.random().toFloat(), 0.01f + Math.random().toFloat() * 0.03f, 0.6f + Math.random().toFloat() * 1.4f))
        for (i in 0 until 50) parts.add(floatArrayOf(Math.random().toFloat(), Math.random().toFloat(), 0.05f + Math.random().toFloat() * 0.12f, 1f + Math.random().toFloat() * 2.5f))
        for (i in 0 until 70) orbit.add(floatArrayOf((Math.random() * 6.2832).toFloat(), 1.12f + Math.random().toFloat() * 0.7f,
            (0.25f + Math.random().toFloat() * 0.6f) * (if (i and 1 == 1) -1 else 1), 0.7f + Math.random().toFloat() * 1.5f))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        W = w.toFloat(); H = h.toFloat(); cx = W / 2f; cy = H * 0.47f
        pk = FloatArray(max(10, (W / d(34f)).toInt()))
    }

    private fun hsl(h0: Float, s: Float, l: Float, a: Int = 255): Int {
        val hh = (((h0 % 360f) + 360f) % 360f) / 360f
        val q = if (l < 0.5f) l * (1 + s) else l + s - l * s
        val p = 2 * l - q
        fun ch(tt: Float): Float {
            var x = tt
            if (x < 0f) x += 1f
            if (x > 1f) x -= 1f
            return when {
                x < 1f / 6f -> p + (q - p) * 6f * x
                x < 0.5f -> q
                x < 2f / 3f -> p + (q - p) * (2f / 3f - x) * 6f
                else -> p
            }
        }
        return Color.argb(a,
            (ch(hh + 1f / 3f) * 255f).toInt().coerceIn(0, 255),
            (ch(hh) * 255f).toInt().coerceIn(0, 255),
            (ch(hh - 1f / 3f) * 255f).toInt().coerceIn(0, 255))
    }

    private fun mkSprite() {
        if (abs(hue - spriteHue) < 3f && sprite != null) return
        spriteHue = hue
        val b = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val c2 = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(32f, 32f, 32f,
            intArrayOf(hsl(hue, 1f, 0.88f), hsl(hue, 1f, 0.62f, 140), hsl(hue, 1f, 0.5f, 0)),
            floatArrayOf(0f, 0.25f, 1f), Shader.TileMode.CLAMP)
        c2.drawCircle(32f, 32f, 32f, p)
        sprite = b
    }

    private fun glow(x: Float, y: Float, r: Float, a: Float) {
        val s = sprite ?: return
        if (r <= 0f || a <= 0f) return
        glowP.alpha = (a * 255f).toInt().coerceIn(0, 255)
        glowP.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
        rect.set(x - r, y - r, x + r, y + r)
        cv.drawBitmap(s, null, rect, glowP)
        glowP.xfermode = null
    }

    private fun additive(on: Boolean) {
        fill.xfermode = if (on) PorterDuffXfermode(PorterDuff.Mode.ADD) else null
        stroke.xfermode = if (on) PorterDuffXfermode(PorterDuff.Mode.ADD) else null
    }

    private fun rrect(x: Float, y: Float, w: Float, h: Float, r: Float) {
        path.reset()
        path.addRoundRect(x, y, x + w, y + h, r, r, Path.Direction.CW)
    }

    private fun fillWave(x0: Float, x1: Float, y0: Float, bot: Float, amp: Float, ph: Float, fr: Float, step: Float) {
        path.reset()
        path.moveTo(x0, bot)
        var p = x0
        while (p <= x1 + step) {
            val q = min(p, x1)
            path.lineTo(q, y0 + sin((q - x0) / (x1 - x0) * fr + ph) * amp)
            p += step
        }
        path.lineTo(x1, bot)
        path.close()
        cv.drawPath(path, fill)
    }

    private fun dash(on: Float, off: Float, phase: Float) {
        stroke.pathEffect = DashPathEffect(floatArrayOf(max(on, 1f), max(off, 1f)), phase)
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1e9).coerceIn(0.0, 0.04).toFloat()
        last = now
        t += dt
        cv = canvas

        level += (target - level) * (1f - Math.exp((-dt * 2f).toDouble())).toFloat()
        hue = min(150f, 8f + level * 1.45f)
        val lv = (level / 100f).coerceIn(0f, 1f)
        val spd = if (charging && level < 99.4f) 1f else 0.3f
        mkSprite()

        canvas.drawColor(0xFF02030A.toInt())

        for (i in 0 until dust.size) {
            val dd = dust[i]
            dd[1] -= dd[2] * dt * spd
            if (dd[1] < 0f) dd[1] = 1f
            glow(dd[0] * W + sin(t * 0.5f + i) * d(8f), dd[1] * H, dd[3] * d(4f), 0.22f)
        }

        when (style) {
            0 -> portFlow(dt, lv, spd)
            1 -> boltCore(dt, lv, spd)
            2 -> auroraTide(dt, lv, spd)
            3 -> orbitCore(dt, lv, spd)
            else -> ledBars(dt, lv, spd)
        }

        if (fade < 1f) {
            fade = min(1f, fade + dt * 2.2f)
            fill.xfermode = null
            fill.color = hsl(0f, 0f, 0.008f, ((1f - fade) * 255).toInt())
            canvas.drawRect(0f, 0f, W, H, fill)
        }
        postInvalidateOnAnimation()
    }

    // ---- 1. Port Flow -----------------------------------------------------------------------------
    private fun portFlow(dt: Float, lv: Float, spd: Float) {
        val pw = min(W * 0.46f, H * 0.26f)
        val ph = pw * 2.05f
        val px = cx - pw / 2f
        val py = cy - ph / 2f
        val pad = pw * 0.05f
        val sw = pw - pad * 2f
        val sh = ph - pad * 2f
        val sx0 = px + pad
        val sy0 = py + pad
        val sb = sy0 + sh
        val pb = py + ph
        val cab = H * 0.8f

        glow(cx, cy + ph * 0.25f, ph * 0.85f, 0.16f)

        // cable
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeWidth = d(7f)
        stroke.pathEffect = null
        stroke.shader = LinearGradient(0f, cab, 0f, pb,
            intArrayOf(Color.TRANSPARENT, 0x33FFFFFF), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        path.reset(); path.moveTo(cx, cab); path.lineTo(cx, pb + pw * 0.1f)
        cv.drawPath(path, stroke)
        stroke.shader = null

        // energy running up the cable
        additive(true)
        dash(pw * 0.14f, pw * 0.5f, -t * pw * 1.1f * spd)
        stroke.color = hsl(hue, 1f, 0.6f, 72); stroke.strokeWidth = d(12f)
        cv.drawPath(path, stroke)
        stroke.color = hsl(hue, 1f, 0.78f); stroke.strokeWidth = d(3.5f)
        cv.drawPath(path, stroke)
        stroke.pathEffect = null
        additive(false)

        // battery shell
        rrect(px, py, pw, ph, pw * 0.14f)
        fill.color = 0xFF0A0E18.toInt(); cv.drawPath(path, fill)
        stroke.color = 0x38FFFFFF; stroke.strokeWidth = d(2f); cv.drawPath(path, stroke)

        // inside
        rrect(sx0, sy0, sw, sh, pw * 0.1f)
        cv.save()
        cv.clipPath(path)
        fill.color = 0xFF05070D.toInt(); cv.drawRect(px, py, px + pw, py + ph, fill)

        val amp = sw * 0.014f * min(1f, (1f - lv) * 5f + 0.2f)
        val top = sb + amp - (sh + 2 * amp) * lv
        fill.shader = LinearGradient(0f, top, 0f, sb,
            hsl(hue, 1f, 0.58f, 235), hsl(hue + 25f, 0.9f, 0.28f, 245), Shader.TileMode.CLAMP)
        fillWave(sx0, sx0 + sw, top, sb + 2f, amp, t * 1.6f, 9f, sw / 24f)
        fill.shader = null

        // sheen
        val bx = sx0 + (((t * 0.3f * spd) % 1.5f) - 0.4f) * sw
        fill.shader = LinearGradient(bx, 0f, bx + sw * 0.4f, 0f,
            intArrayOf(Color.TRANSPARENT, 0x24FFFFFF, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        cv.drawRect(sx0, top, sx0 + sw, sb, fill)
        fill.shader = null

        // circuit traces
        path.reset()
        for (o in floatArrayOf(-0.3f, 0f, 0.3f)) {
            val ox = cx + o * sw
            path.moveTo(cx, sb)
            path.lineTo(cx, sb - sh * 0.04f)
            path.lineTo(ox, sb - sh * 0.04f - abs(o) * sw * 0.5f)
            path.lineTo(ox, sy0 + sh * 0.08f)
        }
        stroke.color = 0x1FFFFFFF; stroke.strokeWidth = d(1.5f); stroke.strokeJoin = Paint.Join.ROUND
        cv.drawPath(path, stroke)
        additive(true)
        dash(sh * 0.07f, sh * 0.26f, -t * sh * 0.5f * spd)
        stroke.color = hsl(hue, 1f, 0.82f); stroke.strokeWidth = d(2.5f)
        cv.drawPath(path, stroke)
        stroke.pathEffect = null
        additive(false)

        // glass corner
        path.reset()
        path.moveTo(sx0, sy0); path.lineTo(sx0 + sw * 0.7f, sy0); path.lineTo(sx0, sy0 + sh * 0.45f)
        path.close()
        fill.color = 0x0AFFFFFF; cv.drawPath(path, fill)
        cv.restore()

        // notch + connector
        rrect(cx - pw * 0.11f, sy0 + pw * 0.03f, pw * 0.22f, pw * 0.05f, pw * 0.025f)
        fill.color = Color.BLACK; cv.drawPath(path, fill)
        rrect(cx - pw * 0.1f, pb - d(3f), pw * 0.2f, pw * 0.15f, d(4f))
        fill.color = 0xFF141A28.toInt(); cv.drawPath(path, fill)
        stroke.color = 0x47FFFFFF; stroke.strokeWidth = d(1.5f); cv.drawPath(path, stroke)

        // rim light
        rrect(px, py, pw, ph, pw * 0.14f)
        stroke.shader = LinearGradient(px, py, px + pw, py + ph,
            intArrayOf(0x80FFFFFF.toInt(), 0x0DFFFFFF, 0x33FFFFFF), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        stroke.strokeWidth = d(2f)
        cv.drawPath(path, stroke)
        stroke.shader = null

        glow(cx, pb, pw * 0.55f, if (spd > 0.5f) 0.45f + 0.35f * sin(t * 5f) else 0.25f)
    }

    // ---- 2. Bolt Core -----------------------------------------------------------------------------
    private val bp = arrayOf(
        floatArrayOf(0.58f, 0f), floatArrayOf(0.12f, 0.55f), floatArrayOf(0.44f, 0.55f),
        floatArrayOf(0.34f, 1f), floatArrayOf(0.88f, 0.4f), floatArrayOf(0.56f, 0.4f), floatArrayOf(0.76f, 0f)
    )

    private fun boltCore(dt: Float, lv: Float, spd: Float) {
        val bh = min(H * 0.5f, W * 1.05f)
        val bw = bh * 0.75f
        val ox = cx - bw / 2f
        val oy = cy - bh / 2f

        fun boltPath() {
            path.reset()
            for (k in bp.indices) {
                val x = ox + bp[k][0] * bw
                val y = oy + bp[k][1] * bh
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
        }

        glow(cx, cy, bh * 0.85f, 0.28f)

        arcT -= dt
        if (arcT <= 0f) {
            arcT = 0.07f
            arcs.clear()
            for (a in 0 until 5) {
                val v = bp[(Math.random() * 7).toInt()]
                var ax = ox + v[0] * bw
                var ay = oy + v[1] * bh
                var an = (Math.random() * 6.2832).toFloat()
                val pts = ArrayList<Float>()
                for (s2 in 0 until 5) {
                    an += (Math.random() - 0.5).toFloat() * 1.4f
                    ax += cos(an) * bh * 0.045f
                    ay += sin(an) * bh * 0.045f
                    pts.add(ax); pts.add(ay)
                }
                arcs.add(floatArrayOf(ox + v[0] * bw, oy + v[1] * bh, an) + pts.toFloatArray())
            }
        }

        boltPath()
        fill.color = 0xFF0A0E18.toInt(); cv.drawPath(path, fill)

        cv.save()
        boltPath(); cv.clipPath(path)
        val amp = bw * 0.02f * min(1f, (1f - lv) * 5f + 0.2f)
        val top = oy + bh + amp - (bh + 2 * amp) * lv
        for (k in 0 until 2) {
            fill.shader = LinearGradient(0f, top, 0f, oy + bh,
                hsl(hue, 1f, if (k == 1) 0.6f else 0.52f, if (k == 1) 242 else 102),
                hsl(hue + 25f, 0.9f, 0.28f, if (k == 1) 242 else 102), Shader.TileMode.CLAMP)
            fillWave(ox, ox + bw, top - (if (k == 1) 0f else amp), oy + bh + 2f, amp,
                t * 2f * (if (k == 1) 1f else -0.8f) + k, 9f, bw / 20f)
        }
        fill.shader = null
        cv.restore()

        boltPath()
        stroke.strokeJoin = Paint.Join.ROUND
        additive(true)
        stroke.color = hsl(hue, 1f, 0.6f, 31); stroke.strokeWidth = d(16f); cv.drawPath(path, stroke)
        stroke.color = hsl(hue, 1f, 0.65f, 77); stroke.strokeWidth = d(7f); cv.drawPath(path, stroke)
        stroke.color = hsl(hue, 1f, 0.78f); stroke.strokeWidth = d(2.5f); cv.drawPath(path, stroke)

        if (spd > 0.5f) {
            stroke.color = hsl(hue, 1f, 0.86f); stroke.strokeWidth = d(1.5f); stroke.strokeCap = Paint.Cap.ROUND
            for (ar in arcs) {
                path.reset()
                path.moveTo(ar[0], ar[1])
                var j = 3
                while (j + 1 < ar.size) { path.lineTo(ar[j], ar[j + 1]); j += 2 }
                stroke.alpha = (0.5f + Math.random().toFloat() * 0.5f).times(255).toInt().coerceIn(0, 255)
                cv.drawPath(path, stroke)
            }
            stroke.alpha = 255
        }
        additive(false)

        for (m in 0 until 6) {
            val an = t * (0.6f + m * 0.13f) + m
            glow(cx + cos(an) * bw * 0.55f * (0.8f + 0.2f * sin(t + m)),
                cy + sin(an * 1.3f) * bh * 0.5f, d(10f), 0.7f)
        }
    }

    // ---- 3. Aurora Tide ---------------------------------------------------------------------------
    private fun auroraTide(dt: Float, lv: Float, spd: Float) {
        val base = H * (1f - lv * 0.94f) + H * 0.03f
        val step = d(12f)
        additive(true)
        for (k in 0 until 4) {
            val ph = t * (0.5f + k * 0.22f) * (if (k and 1 == 1) -1f else 1f) + k * 1.7f
            val am = H * (0.018f + k * 0.006f)
            val y = base + k * H * 0.012f
            fill.shader = LinearGradient(0f, y - am, 0f, H,
                hsl(hue + k * 16f, 1f, 0.58f, 140), hsl(hue + k * 16f + 20f, 0.9f, 0.35f, 76),
                Shader.TileMode.CLAMP)
            path.reset()
            path.moveTo(0f, H)
            var p = 0f
            while (p <= W + step) {
                path.lineTo(p, y + sin(p / W * (3f + k) * Math.PI.toFloat() + ph) * am +
                    sin(p / W * 7f + ph * 1.7f) * am * 0.35f)
                p += step
            }
            path.lineTo(W, H)
            path.close()
            cv.drawPath(path, fill)
            fill.shader = null
            if (k == 3) {
                stroke.color = hsl(hue, 1f, 0.8f, 178); stroke.strokeWidth = d(2f)
                cv.drawPath(path, stroke)
            }
        }
        additive(false)
        for (s in parts) {
            s[1] -= s[2] * dt * spd
            if (s[1] * H < base) s[1] = 1f
            glow(s[0] * W + sin(t + s[3]) * d(10f), s[1] * H, s[3] * d(5f), 0.8f)
        }
    }

    // ---- 4. Orbit Core ----------------------------------------------------------------------------
    private fun orbitCore(dt: Float, lv: Float, spd: Float) {
        val R = min(min(W * 0.36f, H * 0.22f), d(190f))
        val r = R * 0.8f
        val amp = r * 0.05f * min(1f, (1f - lv) * 5f + 0.15f)
        val top = cy + r + amp - (2 * r + 2 * amp) * lv
        val start = -Math.PI.toFloat() / 2f
        val end = start + 6.2832f * lv
        val step = d(8f)

        glow(cx, cy, R * 2.2f, 0.2f + 0.05f * sin(t * 1.6f))

        // inflow streaks
        val n = 42
        while (streaks.size < n) streaks.add(floatArrayOf((Math.random() * 6.2832).toFloat(),
            R * (1.4f + Math.random().toFloat() * 4), 0.4f + Math.random().toFloat() * 0.8f,
            0.05f + Math.random().toFloat() * 0.08f, 0.7f + Math.random().toFloat() * 1.3f))
        val far = hypot(W.toDouble(), H.toDouble()).toFloat() * 0.55f
        additive(true)
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.color = hsl(hue + 18f, 1f, 0.72f)
        for (s in streaks) {
            s[1] -= (R * 0.5f + s[1] * 0.8f) * s[2] * dt * 0.8f * spd
            if (s[1] < R * 1.3f) { s[1] = far * (0.7f + Math.random().toFloat() * 0.3f); s[0] = (Math.random() * 6.2832).toFloat() }
            val al = min(1f, (s[1] - R * 1.3f) / (R * 1.1f)).coerceAtLeast(0f)
            val c = cos(s[0]); val sn = sin(s[0])
            stroke.alpha = (al * 0.8f * 255f).toInt().coerceIn(0, 255)
            stroke.strokeWidth = s[4] * den
            path.reset()
            path.moveTo(cx + c * s[1], cy + sn * s[1])
            path.lineTo(cx + c * s[1] * (1 + s[3]), cy + sn * s[1] * (1 + s[3]))
            cv.drawPath(path, stroke)
        }
        stroke.alpha = 255
        additive(false)
        stroke.strokeCap = Paint.Cap.BUTT

        // dashed rings
        dash(d(1.6f), 6.2832f * R * 1.24f / 120f - d(1.6f), -t * 6f * den * spd)
        stroke.color = 0x4DFFFFFF; stroke.strokeWidth = d(7f)
        cv.drawCircle(cx, cy, R * 1.24f, stroke)
        stroke.pathEffect = null

        dash(R * 0.45f, R * 0.18f, t * 50f * den * spd)
        stroke.color = hsl(hue + 40f, 1f, 0.68f, 128); stroke.strokeWidth = d(2.5f)
        cv.drawCircle(cx, cy, R * 1.14f, stroke)
        stroke.pathEffect = null

        dash(R * 0.1f, R * 0.22f, -t * 30f * den * spd)
        stroke.color = 0x38FFFFFF; stroke.strokeWidth = d(1.5f)
        cv.drawCircle(cx, cy, R * 1.06f, stroke)
        stroke.pathEffect = null

        // orbiting particles
        for (p in orbit) {
            p[0] += p[2] * dt * spd * 0.45f / p[1]
            glow(cx + cos(p[0]) * R * p[1], cy + sin(p[0]) * R * p[1], p[3] * d(5f), 0.75f)
        }

        // the core
        path.reset()
        path.addCircle(cx, cy, r, Path.Direction.CW)
        cv.save()
        cv.clipPath(path)
        fill.color = hsl(hue, 0.45f, 0.08f); cv.drawRect(cx - r, cy - r, cx + r, cy + r, fill)
        for (k in 0 until 3) {
            val ph = t * (1f + k * 0.45f) * (if (k and 1 == 1) -1f else 1f) + k * 2f
            val a2 = floatArrayOf(0.3f, 0.45f, 1f)[k]
            val o = floatArrayOf(-0.06f, -0.02f, 0f)[k] * r
            fill.shader = LinearGradient(0f, top, 0f, cy + r,
                hsl(hue + 8f, 1f, if (k == 2) 0.6f else 0.52f, (a2 * 255).toInt()),
                hsl(hue + 28f, 0.9f, 0.26f, (a2 * 255).toInt()), Shader.TileMode.CLAMP)
            path.reset()
            path.moveTo(cx - r, cy + r + 2f)
            var px2 = cx - r
            while (px2 <= cx + r + step) {
                path.lineTo(px2, top + o + sin((px2 - cx) / r * (3.2f + k * 0.6f) + ph) * amp * (if (k == 1) 0.7f else 1f))
                px2 += step
            }
            path.lineTo(cx + r, cy + r + 2f)
            path.close()
            cv.drawPath(path, fill)
        }
        fill.shader = null
        fill.shader = LinearGradient(cx - r, cy - r, cx + r * 0.3f, cy + r * 0.3f,
            intArrayOf(0x3DFFFFFF, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        cv.drawRect(cx - r, cy - r, cx + r, cy + r, fill)
        fill.shader = null
        cv.restore()

        stroke.color = 0x29FFFFFF; stroke.strokeWidth = d(1.5f)
        cv.drawCircle(cx, cy, r, stroke)
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.color = 0x1AFFFFFF; stroke.strokeWidth = d(7f)
        cv.drawCircle(cx, cy, R, stroke)

        // progress arc with a comet head
        if (lv > 0.003f) {
            rect.set(cx - R, cy - R, cx + R, cy + R)
            additive(true)
            stroke.color = hsl(hue, 1f, 0.6f, 41); stroke.strokeWidth = d(28f)
            cv.drawArc(rect, -90f, 360f * lv, false, stroke)
            stroke.color = hsl(hue, 1f, 0.62f, 89); stroke.strokeWidth = d(14f)
            cv.drawArc(rect, -90f, 360f * lv, false, stroke)

            val sweep = SweepGradient(cx, cy,
                intArrayOf(hsl(hue + 45f, 1f, 0.62f), hsl(hue, 1f, 0.72f), hsl(hue, 1f, 0.72f)),
                floatArrayOf(0f, max(0.02f, lv), 1f))
            val m = Matrix(); m.postRotate(-90f, cx, cy); sweep.setLocalMatrix(m)
            stroke.shader = sweep
            stroke.strokeWidth = d(7f)
            cv.drawArc(rect, -90f, 360f * lv, false, stroke)
            stroke.shader = null
            additive(false)

            for (k in 0 until 7) {
                val ea = end - k * 0.055f
                glow(cx + cos(ea) * R, cy + sin(ea) * R, (34 - k * 3.4f) * den, 1f - k / 7f)
            }
        }
    }

    // ---- 5. LED Bars ------------------------------------------------------------------------------
    private fun ledBars(dt: Float, lv: Float, spd: Float) {
        val n = max(10, (W / d(34f)).toInt())
        val gap = W / n
        val bw = gap * 0.62f
        val sh = max(d(10f), H / 38f)
        val g2 = sh * 0.22f
        val rows = Math.ceil((H / sh).toDouble()).toInt()
        if (pk.size != n) pk = FloatArray(n)

        fill.color = 0x0BFFFFFF
        path.reset()
        for (k in 0 until n) for (j in 0 until rows)
            path.addRect(k * gap + (gap - bw) / 2f, H - (j + 1) * sh + g2, k * gap + (gap + bw) / 2f, H - j * sh, Path.Direction.CW)
        cv.drawPath(path, fill)

        val tops = FloatArray(n * 2)
        fill.shader = LinearGradient(0f, H, 0f, H * 0.1f,
            hsl(hue + 30f, 0.9f, 0.45f), hsl(hue, 1f, 0.66f), Shader.TileMode.CLAMP)
        path.reset()
        for (k in 0 until n) {
            val wv = 0.82f + 0.18f * sin(t * 2.6f * spd + k * 0.7f) + 0.07f * sin(t * 5.1f * spd + k * 1.9f)
            val bh = min(H * 0.96f, H * (0.06f + 0.86f * lv) * wv)
            val c = (bh / sh).toInt()
            pk[k] = max((pk[k] - dt * 5f * spd), c.toFloat())
            for (j in 0 until c)
                path.addRect(k * gap + (gap - bw) / 2f, H - (j + 1) * sh + g2, k * gap + (gap + bw) / 2f, H - j * sh, Path.Direction.CW)
            tops[k * 2] = k * gap + gap / 2f
            tops[k * 2 + 1] = H - c * sh
        }
        cv.drawPath(path, fill)
        fill.shader = null

        for (k in 0 until tops.size step 2) glow(tops[k], tops[k + 1], bw * 1.1f, 0.7f)

        fill.color = hsl(hue, 1f, 0.86f)
        path.reset()
        for (k in 0 until n)
            path.addRect(k * gap + (gap - bw) / 2f, H - (pk[k] + 1) * sh + g2, k * gap + (gap + bw) / 2f, H - pk[k] * sh + g2 + sh * 0.35f, Path.Direction.CW)
        cv.drawPath(path, fill)
    }
}
