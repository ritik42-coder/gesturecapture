package com.raja.gesturecapture

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

// ---------------------------------------------------------------------------------------------------
// Pattern unlock: three by three dots, dragged. Each dot pops as the finger reaches it, the trail
// carries a soft glow, a wrong pattern flashes red and shakes, a right one blooms green.
// ---------------------------------------------------------------------------------------------------
class LockPattern(c: Context) : View(c) {
    var onComplete: ((String) -> Unit)? = null
    var inputEnabled = true
        set(v) { field = v; if (!v) reset(); invalidate() }

    var accent = 0xFF7AA2FF.toInt()
        set(v) { field = v; buildGlow(); invalidate() }

    private val den = resources.displayMetrics.density
    private fun d(x: Float) = x * den

    private val seq = ArrayList<Int>()
    private val when_ = LongArray(9)          // when each dot was picked up
    private var drawing = false
    private var fx = 0f
    private var fy = 0f
    private var state = 0                      // 0 idle, 1 error, 2 success
    private var stateAt = 0L

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trail = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private var glowShader: RadialGradient? = null

    private var cell = 0f
    private var nodeR = 0f
    private var touchR = 0f

    private val errorColor = 0xFFFF5C7A.toInt()
    private val okColor = 0xFF34D399.toInt()

    fun reset() {
        seq.clear(); drawing = false; state = 0; stateAt = 0L
        invalidate()
    }

    fun flashError() { state = 1; stateAt = SystemClock.uptimeMillis(); invalidate() }

    fun flashOk() { state = 2; stateAt = SystemClock.uptimeMillis(); invalidate() }

    private fun buildGlow() {
        if (nodeR <= 0f) return
        glowShader = RadialGradient(0f, 0f, nodeR * 3.4f, intArrayOf(withA(accent, 150), withA(accent, 0)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        glow.shader = glowShader
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = min(w, h).toFloat()
        cell = s / 3f
        nodeR = cell * 0.115f
        touchR = cell * 0.40f
        ring.strokeWidth = d(1.4f)
        trail.strokeWidth = d(3.4f)
        buildGlow()
    }

    private fun withA(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun cx(i: Int) = cell * (i % 3 + 0.5f)
    private fun cy(i: Int) = cell * (i / 3 + 0.5f)

    private fun hit(x: Float, y: Float): Int {
        for (i in 0 until 9) {
            if (hypot((x - cx(i)).toDouble(), (y - cy(i)).toDouble()) < touchR) return i
        }
        return -1
    }

    private fun pick(i: Int) {
        if (seq.contains(i)) return
        seq.add(i)
        when_[i] = SystemClock.uptimeMillis()
        if (LockStore.haptics(context)) LockUi.buzz(context, 9, 70)
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!inputEnabled) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                seq.clear(); state = 0; drawing = true
                for (i in 0 until 9) when_[i] = 0L
                fx = e.x; fy = e.y
                val i = hit(e.x, e.y)
                if (i >= 0) pick(i)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!drawing) return true
                fx = e.x; fy = e.y
                val i = hit(e.x, e.y)
                if (i >= 0) pick(i)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!drawing) return true
                drawing = false
                fx = e.x; fy = e.y
                val s = seq.joinToString("-")
                if (seq.size >= 4) {
                    onComplete?.invoke(s)
                } else {
                    flashError()
                }
                invalidate()
            }
        }
        return true
    }

    private fun colorNow(): Int = when (state) {
        1 -> errorColor
        2 -> okColor
        else -> accent
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        var alive = drawing
        val c = colorNow()
        val fade = when (state) {
            1, 2 -> {
                val k = ((now - stateAt) / 620f).coerceIn(0f, 1f)
                if (k < 1f) alive = true
                1f - k * 0.85f
            }
            else -> 1f
        }

        // dots
        for (i in 0 until 9) {
            val x = cx(i); val y = cy(i)
            val on = seq.contains(i)
            var pop = 1f
            if (on) {
                val p = ((now - when_[i]) / 190f).coerceIn(0f, 1f)
                if (p < 1f) alive = true
                pop = 0.7f + 0.5f * p
            }
            if (on) {
                canvas.save()
                canvas.translate(x, y)
                glow.alpha = (150 * fade).toInt().coerceIn(0, 255)
                canvas.drawCircle(0f, 0f, nodeR * 3.4f, glow)
                canvas.restore()
            }
            ring.color = if (on) withA(c, (210 * fade).toInt()) else Color.argb((110 * fade).toInt(), 255, 255, 255)
            canvas.drawCircle(x, y, nodeR * (if (on) pop else 1f) * 1.75f, ring)
            core.color = if (on) withA(c, (235 * fade).toInt()) else Color.argb((120 * fade).toInt(), 255, 255, 255)
            canvas.drawCircle(x, y, nodeR * (if (on) pop * 0.82f else 0.62f), core)
        }

        if (seq.isEmpty()) return

        // trail
        trail.color = withA(c, (200 * fade).toInt())
        trail.strokeWidth = d(3.4f)
        var px = cx(seq[0]); var py = cy(seq[0])
        for (k in 1 until seq.size) {
            canvas.drawLine(px, py, cx(seq[k]), cy(seq[k]), trail)
            px = cx(seq[k]); py = cy(seq[k])
        }
        if (drawing) canvas.drawLine(px, py, fx, fy, trail)

        if (alive) postInvalidateOnAnimation()
    }
}
