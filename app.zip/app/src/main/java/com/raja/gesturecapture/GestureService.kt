package com.raja.gesturecapture

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.*
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import kotlin.math.sqrt

class GestureService : AccessibilityService(), SensorEventListener {
    companion object { var inst: GestureService? = null }
    private var lastFire = 0L; private var lastShake = 0L; private var lastDown = 0L
    private var up = false; private var down = false

    override fun onServiceConnected() {
        inst = this
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_UI)
    }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt((e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble()) / 9.81
        val t = System.currentTimeMillis()
        if (g > 2.7 && t - lastShake > 1500) { lastShake = t; fire("shake") }
    }

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        val d = ev.action == KeyEvent.ACTION_DOWN
        when (ev.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> up = d
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                down = d
                if (d && ev.repeatCount == 0) { if (ev.eventTime - lastDown < 350 && !up) fire("vol_double"); lastDown = ev.eventTime }
            }
            else -> return false
        }
        if (up && down && d) { fire("vol_both"); return true }
        return false
    }

    private fun fire(id: String) {
        val now = System.currentTimeMillis()
        val sp = Prefs.sp(this); val a = sp.getString("g_$id", "none")
        if (a == "none" || now - lastFire < 1200) return
        lastFire = now
        getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(40, 255))
        if (a == "shot") screenshot()
        else if (RecorderService.running) startService(Intent(this, RecorderService::class.java).setAction("stop"))
        else startActivity(Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("start", sp.getString("mode", "video_mic")))
    }

    fun screenshot() {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val bmp = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                r.hardwareBuffer.close()
                if (bmp == null) return
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "shot_${System.currentTimeMillis()}.png")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GestureCapture")
                }
                contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)?.let { u ->
                    contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
                Toast.makeText(this@GestureService, "Screenshot saved", Toast.LENGTH_SHORT).show()
            }
            override fun onFailure(c: Int) { Toast.makeText(this@GestureService, "Screenshot blocked ($c)", Toast.LENGTH_SHORT).show() }
        })
    }
}
