package com.raja.gesturecapture

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.PendingIntent
import android.content.ContentValues
import android.telecom.TelecomManager
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.*
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import kotlin.math.abs
import kotlin.math.sqrt

class GestureService : AccessibilityService(), SensorEventListener {
    companion object { var inst: GestureService? = null }
    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var lastFire = 0L; private var lastShake = 0L; private var lastDown = 0L; private var nearT = 0L; private var cornerT = 0L
    private var up = false; private var down = false; private var flipped = false
    private var folder = "Other"
    val island by lazy { Island(this, wm) }
    val vbar by lazy { VolBar(this, wm) }
    private var lastUp = 0L; private var lastTwist = 0L; private var torchOn = false; private var gyroOn = false
    private var bar: View? = null; private var tick: Runnable? = null
    private var ringUntil = 0L; private var activeUntil = 0L; private var lastY = 0f
    private var answerPI: PendingIntent? = null; private var hangPI: PendingIntent? = null
    private var bubble: View? = null; private var draw: View? = null; private var corner: View? = null; private var edge: View? = null; private var dot: View? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun bg(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun lp(w: Int, ht: Int, f: Int = 0) = WindowManager.LayoutParams(w, ht, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or f, PixelFormat.TRANSLUCENT)

    override fun onServiceConnected() {
        inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_UI)
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_PROXIMITY), SensorManager.SENSOR_DELAY_NORMAL)
        getSystemService(CameraManager::class.java).registerTorchCallback(object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(id: String, en: Boolean) { torchOn = en }
        }, h)
        refresh(); island.sync()
    }
    override fun onDestroy() { try { island.destroy(); vbar.reset() } catch (_: Exception) {}; inst = null; super.onDestroy() }
    fun islandRefresh() { h.post { island.sync() } }
    fun islandDemo(k: String) { island.demo(k) }
    override fun onInterrupt() {}
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    // remember which app is on screen -> screenshots are filed in a folder per app
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        if (e.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) { 
            (e.parcelableData as? Notification)?.let { n ->
                if (n.category == Notification.CATEGORY_CALL) callNotif(n)
                else if (island.feat("notif") && (n.flags and Notification.FLAG_ONGOING_EVENT) == 0 && (n.flags and Notification.FLAG_GROUP_SUMMARY) == 0) {
                    val pk = e.packageName?.toString() ?: ""
                    val t = n.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                    if (pk != packageName && t.isNotBlank()) island.notif(pk, t, n.extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "")
                }
            }
            return
        }
        val p = e.packageName?.toString() ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && p != "android" && !p.contains("systemui") && p != packageName)
            folder = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString() } catch (_: Exception) { p }
    }

    fun refresh() { h.post {
        val sp = Prefs.sp(this)
        fun on(vararg ids: String) = ids.any { sp.getString("g_$it", "none") != "none" }
        val gy = on("twist")
        if (gy != gyroOn) {
            gyroOn = gy
            val sm = getSystemService(SENSOR_SERVICE) as SensorManager; val gs = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            if (gy) sm.registerListener(this, gs, SensorManager.SENSOR_DELAY_UI) else sm.unregisterListener(this, gs)
        }
        corner = sync(corner, on("corner")) { cornerView() }
        edge = sync(edge, on("edge_up", "edge_down", "edge_hold", "edge_dbl")) { edgeView() }
        dot = sync(dot, on("dot_dbl", "dot_up", "dot_down", "dot_left", "dot_right")) { dotView() }
    } }

    private fun sync(cur: View?, want: Boolean, make: () -> View): View? {
        if (want && cur == null) return make()
        if (!want && cur != null) { try { wm.removeView(cur) } catch (_: Exception) {}; return null }
        return cur
    }

    // top-left corner double-tap
    private fun cornerView(): View {
        val v = View(this)
        v.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN) { if (ev.eventTime - cornerT < 350) fire("corner"); cornerT = ev.eventTime }
            true
        }
        val p = lp(dp(56), dp(40)); p.gravity = Gravity.TOP or Gravity.START
        wm.addView(v, p); return v
    }

    // thin strip on the right edge (middle of screen): swipe up / swipe down / long-press
    private fun edgeView(): View {
        val v = View(this); var sy = 0f; var done = false; var et = 0L
        val hold = Runnable { done = true; fire("edge_hold") }
        v.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { if (ev.eventTime - et < 350) fire("edge_dbl"); et = ev.eventTime; sy = ev.rawY; done = false; h.postDelayed(hold, 600) }
                MotionEvent.ACTION_MOVE -> {
                    val dy = ev.rawY - sy
                    if (abs(dy) > dp(20)) h.removeCallbacks(hold)
                    if (!done && abs(dy) > dp(60)) { done = true; fire(if (dy < 0) "edge_up" else "edge_down") }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> h.removeCallbacks(hold)
            }
            true
        }
        val dm = resources.displayMetrics
        val p = lp(dp(14), (dm.heightPixels * 0.35).toInt()); p.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        wm.addView(v, p); return v
    }

    // small touch dot: double-tap / swipe 4 ways. Long-press then drag to move it.
    private fun dotView(): View {
        val v = View(this)
        v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99A855F7.toInt()); setStroke(dp(2), 0x88FFFFFF.toInt()) }
        val dm = resources.displayMetrics
        val p = lp(dp(40), dp(40)); p.gravity = Gravity.TOP or Gravity.START
        p.x = dm.widthPixels - dp(46); p.y = (dm.heightPixels * 0.75).toInt()
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var drag = false; var tapT = 0L
        val arm = Runnable { drag = true; getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(30, 200)) }
        v.setOnTouchListener { _, ev ->
            val dx = ev.rawX - sx; val dy = ev.rawY - sy
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = p.x; oy = p.y; drag = false; h.postDelayed(arm, 500) }
                MotionEvent.ACTION_MOVE -> {
                    if (drag) { p.x = ox + dx.toInt(); p.y = oy + dy.toInt(); wm.updateViewLayout(v, p) }
                    else if (abs(dx) + abs(dy) > dp(12)) h.removeCallbacks(arm)
                }
                MotionEvent.ACTION_CANCEL -> h.removeCallbacks(arm)
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(arm)
                    if (!drag) {
                        if (abs(dx) + abs(dy) < dp(12)) { if (ev.eventTime - tapT < 350) fire("dot_dbl"); tapT = ev.eventTime }
                        else if (maxOf(abs(dx), abs(dy)) > dp(28))
                            fire(if (abs(dx) > abs(dy)) (if (dx > 0) "dot_right" else "dot_left") else (if (dy > 0) "dot_down" else "dot_up"))
                    }
                }
            }
            true
        }
        wm.addView(v, p); return v
    }

    override fun onSensorChanged(e: SensorEvent) {
        val t = System.currentTimeMillis()
        if (e.sensor.type == Sensor.TYPE_PROXIMITY) {
            val near = e.values[0] < e.sensor.maximumRange
            if (near) { nearT = t; if (ringing() && abs(lastY) > 4.5f) fireCall("call_ear") }
            else { val d = t - nearT; if (d < 1000) { fire("wave"); fireCall("call_wave") } else if (d < 4000) fire("cover") }
            return
        }
        if (e.sensor.type == Sensor.TYPE_GYROSCOPE) {
            if (abs(e.values[1]) > 6f) { if (t - lastTwist in 150L..900L) { lastTwist = 0; fire("twist") } else lastTwist = t }
            return
        }
        val g = sqrt((e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble()) / 9.81
        lastY = e.values[1]
        if (g > 2.7 && t - lastShake > 1500) { lastShake = t; fire("shake"); fireCall("call_shake") }
        if (e.values[2] < -8.5f && !flipped) { flipped = true; fire("flip"); fireCall("call_flip") } else if (e.values[2] > 0f) flipped = false
    }

    // ---- hold a volume key = keep changing the volume ----
    // With key filtering on, Android drops the key auto-repeat, so the service repeats the step itself.
    // If the system does repeat on its own (volume keeps changing without us), we stand down so it never doubles up.
    private var holdDir = 0
    private var holdStart = 0L
    private var holdBase = -1
    private var holdSys = false
    private fun volSig(): Int { var t = 0; for (i in 0..5) t += am().getStreamVolume(i); return t }
    private fun islandVol() {
        if (vbar.mode() == "default" && island.feat("vol")) { val st = if (inCall()) 0 else 3; island.volume(am().getStreamVolume(st), am().getStreamMaxVolume(st)) }
    }
    private fun stopHold() { holdDir = 0; holdBase = -1; holdSys = false; h.removeCallbacks(holdR) }
    private fun startHold(dir: Int) { stopHold(); holdDir = dir; holdStart = android.os.SystemClock.uptimeMillis(); h.postDelayed(holdR, 450) }
    private val holdR = object : Runnable {
        override fun run() {
            if (holdDir == 0) return
            if (android.os.SystemClock.uptimeMillis() - holdStart > 15000 || !getSystemService(PowerManager::class.java).isInteractive) { stopHold(); return }
            val mode = vbar.mode()
            if (mode == "mine") { vbar.adjust(holdDir, false); h.postDelayed(this, 85); return }
            val sig = volSig()
            if (holdBase < 0) { holdBase = sig; h.postDelayed(this, 110); return }   // first look: remember where we are
            if (sig != holdBase) { holdSys = true; return }                           // the system is repeating by itself
            try { am().adjustSuggestedStreamVolume(holdDir, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI) } catch (_: Exception) {}
            holdBase = volSig()
            if (mode == "both") vbar.refresh()
            islandVol()
            h.postDelayed(this, 90)
        }
    }

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        val d = ev.action == KeyEvent.ACTION_DOWN
        when (ev.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                up = d
                if (d && ev.repeatCount == 0) { if (ev.eventTime - lastUp < 350 && !down) fire("vol_up_double"); lastUp = ev.eventTime }
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                down = d
                if (d && ev.repeatCount == 0) { if (ev.eventTime - lastDown < 350 && !up) fire("vol_double"); lastDown = ev.eventTime }
            }
            else -> return false
        }
        val mode = vbar.mode()
        val dir = if (ev.keyCode == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        if (up && down && d) { stopHold(); fire("vol_both"); return true }
        if (!d) { if (holdDir == dir) stopHold(); return mode == "mine" }
        if (ev.repeatCount == 0) {
            if (mode == "default") h.postDelayed({ islandVol() }, 130)
            else if (mode == "both") h.postDelayed({ vbar.refresh() }, 120)
            if (mode == "mine") vbar.adjust(dir, true)
            if (getSystemService(PowerManager::class.java).isInteractive && (mode == "mine" || !ringing())) startHold(dir)
        }
        return mode == "mine"   // in "mine" mode the key is taken over so Samsung's panel stays hidden
    }

    private fun fire(id: String) {
        val now = System.currentTimeMillis()
        val a = Prefs.sp(this).getString("g_$id", "none")
        if (a == "none" || now - lastFire < 1200 || !getSystemService(PowerManager::class.java).isInteractive) return
        if (ringing() && a != "answer" && a != "answer_spk" && a != "reject") return  // keep other gestures quiet while a call rings
        lastFire = now
        getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(40, 255))
        doAct(a, id)
    }

    fun doAct(a: String?, id: String) {
        when (a) {
            "shot" -> screenshot()
            "long" -> longShot()
            "bubble" -> showBubble(true)
            "draw" -> startDraw()
            "answer" -> answerCall(false)
            "answer_spk" -> answerCall(true)
            "reject" -> endCall()
            "torch" -> torch()
            "mute" -> try {
                val am = getSystemService(AudioManager::class.java)
                am.ringerMode = if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
                toast(if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) "Sound on" else "Vibrate mode")
            } catch (_: Exception) { toast("Not allowed on this phone") }
            "lock" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "power" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            "wifi" -> startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "bt" -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "app" -> packageManager.getLaunchIntentForPackage(Prefs.sp(this).getString("app_$id", "") ?: "")?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            else -> if (RecorderService.running) startService(Intent(this, RecorderService::class.java).setAction("stop"))
                else startActivity(Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("start", Prefs.sp(this).getString("mode", "video_mic")))
        }
    }

    // ---------- calls: normal phone calls + WhatsApp/Telegram/etc. (via the call notification buttons) ----------
    private fun am() = getSystemService(AudioManager::class.java)
    private fun ringing() = am().mode == AudioManager.MODE_RINGTONE || System.currentTimeMillis() < ringUntil
    private fun inCall() = am().mode == AudioManager.MODE_IN_CALL || am().mode == AudioManager.MODE_IN_COMMUNICATION || System.currentTimeMillis() < activeUntil

    val torchIsOn: Boolean get() = torchOn
    fun isRinging() = ringing()
    fun isInCall() = inCall()

    private fun callNotif(n: Notification) {
        if (n.category != Notification.CATEGORY_CALL) return
        var ans: PendingIntent? = null; var end: PendingIntent? = null
        for (a in n.actions ?: return) {
            val t = a.title?.toString()?.lowercase() ?: continue
            if (Regex("answer|accept|pick up|pickup").containsMatchIn(t)) ans = a.actionIntent
            else if (Regex("decline|reject|hang ?up|end call|disconnect").containsMatchIn(t)) end = a.actionIntent
        }
        val now = System.currentTimeMillis()
        if (ans != null) { answerPI = ans; ringUntil = now + 45000 }
        if (end != null) { hangPI = end; if (ans == null) { ringUntil = 0; activeUntil = now + 600000 } }
        h.post {
            if (ans != null) { island.setCaller(n.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Incoming call"); island.base() }
            else if (end != null) island.base()
        }
    }

    private fun fireCall(id: String) {
        val a = Prefs.sp(this).getString("g_$id", "none") ?: "none"
        val now = System.currentTimeMillis()
        val ok = if (id == "call_flip") ringing() || inCall() else ringing()
        if (a == "none" || !ok || now - lastFire < 1200) return
        lastFire = now
        getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(40, 255))
        doAct(a, id)
    }

    private fun answerCall(speaker: Boolean) {
        try { getSystemService(TelecomManager::class.java).acceptRingingCall() } catch (_: Exception) {}
        if (System.currentTimeMillis() < ringUntil) answerPI?.let { try { it.send() } catch (_: Exception) {} }
        if (speaker) h.postDelayed({ try { am().isSpeakerphoneOn = true } catch (_: Exception) {} }, 1200)
        ringUntil = 0; h.postDelayed({ island.base() }, 700)
    }

    private fun endCall() {
        var ok = false
        try { ok = getSystemService(TelecomManager::class.java).endCall() } catch (_: Exception) {}
        if (!ok) hangPI?.let { try { it.send() } catch (_: Exception) {} }
        ringUntil = 0; activeUntil = 0; h.postDelayed({ island.base() }, 700)
    }

    private fun torch() {
        val cm = getSystemService(CameraManager::class.java)
        try {
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            cm.setTorchMode(id, !torchOn)
        } catch (_: Exception) { toast("No flashlight found") }
    }

    fun recUi(on: Boolean) { showBubble(on); if (island.feat("rec")) island.recording(on) else showBar(on) }

    // recording bar: live timer (frozen while paused), pause/resume, stop
    fun showBar(on: Boolean) { h.post {
        tick?.let { h.removeCallbacks(it) }; tick = null
        bar?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bar = null
        if (!on || !Prefs.sp(this).getBoolean("bar", true)) return@post
        val root = LinearLayout(this); root.gravity = Gravity.CENTER_VERTICAL
        root.background = bg(0xEE151A2E.toInt(), 30); root.setPadding(dp(16), dp(4), dp(6), dp(4))
        val dotV = View(this); dotV.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFF43F5E.toInt()) }
        val time = TextView(this); time.setTextColor(Color.WHITE); time.textSize = 17f
        time.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); time.setPadding(dp(10), 0, dp(8), 0)
        fun btn(t: String, a: () -> Unit) = TextView(this).apply { text = t; textSize = 19f; setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { a() } }
        val pause = btn("⏸") { startService(Intent(this, RecorderService::class.java).setAction("pause")) }
        root.addView(dotV, LinearLayout.LayoutParams(dp(10), dp(10))); root.addView(time); root.addView(pause)
        root.addView(btn("⏹") { startService(Intent(this, RecorderService::class.java).setAction("stop")) })
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; p.y = dp(34)
        var sec = -1
        val r = object : Runnable {
            override fun run() {
                val ps = RecorderService.paused
                if (!ps) sec++ else if (sec < 0) sec = 0
                time.text = String.format("%02d:%02d", sec / 60, sec % 60)
                pause.text = if (ps) "▶" else "⏸"
                dotV.alpha = if (ps) 0.3f else if (sec % 2 == 0) 1f else 0.45f
                h.postDelayed(this, 1000)
            }
        }
        tick = r; wm.addView(root, p); bar = root; r.run()
    } }

    // ---------- floating bubble: pause / stop / draw / screenshot / long screenshot ----------
    fun showBubble(on: Boolean) { h.post {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        if (!on) return@post
        val root = LinearLayout(this); root.gravity = Gravity.CENTER_VERTICAL
        val menu = LinearLayout(this); menu.visibility = View.GONE
        menu.background = bg(0xF2222842.toInt(), 28); menu.setPadding(dp(8), dp(4), dp(8), dp(4))
        fun item(t: String, a: () -> Unit) {
            menu.addView(TextView(this).apply { text = t; textSize = 20f; setPadding(dp(9), dp(8), dp(9), dp(8)); setOnClickListener { menu.visibility = View.GONE; a() } })
        }
        item("⏯") { startService(Intent(this, RecorderService::class.java).setAction("pause")) }
        item("⏹") { startService(Intent(this, RecorderService::class.java).setAction("stop")); showBubble(false) }
        item("✏️") { startDraw() }
        item("📸") { screenshot() }
        item("📜") { longShot() }
        item("✕") { showBubble(false) }
        val handle = TextView(this); handle.text = "●"; handle.gravity = Gravity.CENTER; handle.textSize = 20f; handle.setTextColor(Color.WHITE)
        handle.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF6366F1.toInt(), 0xFFEC4899.toInt())).apply { shape = GradientDrawable.OVAL }
        root.addView(handle, LinearLayout.LayoutParams(dp(48), dp(48))); root.addView(menu)
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        p.gravity = Gravity.TOP or Gravity.START; p.x = 0; p.y = dp(200)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt(); val dy = (ev.rawY - sy).toInt()
                    if (abs(dx) + abs(dy) > 12) moved = true
                    p.x = ox + dx; p.y = oy + dy; wm.updateViewLayout(root, p)
                }
                MotionEvent.ACTION_UP -> if (!moved) menu.visibility = if (menu.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
            true
        }
        wm.addView(root, p); bubble = root
    } }

    // ---------- draw on screen (shows up in recordings and screenshots) ----------
    fun startDraw() { h.post {
        if (draw != null) return@post
        val strokes = ArrayList<Pair<Path, Int>>(); var col = Color.RED
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(5).toFloat(); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        val cv = object : View(this@GestureService) {
            override fun onDraw(c: Canvas) { for ((p, k) in strokes) { paint.color = k; c.drawPath(p, paint) } }
            override fun onTouchEvent(ev: MotionEvent): Boolean {
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> strokes.add(Pair(Path().apply { moveTo(ev.x, ev.y) }, col))
                    MotionEvent.ACTION_MOVE -> strokes.lastOrNull()?.first?.lineTo(ev.x, ev.y)
                }
                invalidate(); return true
            }
        }
        val bar = LinearLayout(this); bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = bg(0xF2222842.toInt(), 28); bar.setPadding(dp(10), dp(6), dp(10), dp(6))
        for (k in intArrayOf(Color.RED, 0xFFFACC15.toInt(), 0xFF22C55E.toInt(), 0xFF38BDF8.toInt(), Color.WHITE)) {
            val dot = View(this); dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(k) }
            dot.setOnClickListener { col = k }
            bar.addView(dot, LinearLayout.LayoutParams(dp(30), dp(30)).apply { setMargins(dp(5), 0, dp(5), 0) })
        }
        fun tb(t: String, a: () -> Unit) { bar.addView(TextView(this).apply { text = t; textSize = 20f; setPadding(dp(8), 0, dp(8), 0); setOnClickListener { a() } }) }
        tb("↶") { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1); cv.invalidate() }
        tb("🗑") { strokes.clear(); cv.invalidate() }
        tb("✓") { try { wm.removeView(draw) } catch (_: Exception) {}; draw = null }
        val root = FrameLayout(this); root.addView(cv, FrameLayout.LayoutParams(-1, -1))
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(40) })
        wm.addView(root, lp(-1, -1, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)); draw = root
    } }

    // ---------- screenshots (saved in Pictures/GestureCapture/<app name>) ----------
    private fun cap(cb: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val b = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                r.hardwareBuffer.close(); cb(b)
            }
            override fun onFailure(c: Int) { cb(null) }
        })
    }

    private fun save(b: Bitmap, pre: String) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "${pre}_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GestureCapture/" + folder.replace(Regex("[^A-Za-z0-9 ._-]"), "_"))
        }
        contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)?.let { u ->
            contentResolver.openOutputStream(u)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
    }

    fun screenshot() { h.post {
        bubble?.visibility = View.INVISIBLE
        h.postDelayed({
            cap { b ->
                bubble?.visibility = View.VISIBLE
                if (b == null) toast("Screenshot blocked here") else { save(b, "shot"); toast("Saved in $folder") }
            }
        }, 250)
    } }

    // long screenshot: swipe-scroll, capture, stitch using the overlapping rows
    fun longShot() { h.post {
        bubble?.visibility = View.INVISIBLE
        val parts = ArrayList<Bitmap>(); var prev: Bitmap? = null
        val dm = resources.displayMetrics
        fun finish() {
            bubble?.visibility = View.VISIBLE
            if (parts.isEmpty()) { toast("Screenshot blocked here"); return }
            if (parts.size == 1) { save(parts[0], "shot"); toast("Page is not scrollable, saved normal screenshot"); return }
            val res = Bitmap.createBitmap(parts[0].width, parts.sumOf { it.height }, Bitmap.Config.ARGB_8888)
            val c = Canvas(res); var y = 0f
            for (p in parts) { c.drawBitmap(p, 0f, y, null); y += p.height }
            save(res, "long"); toast("Long screenshot saved in $folder")
        }
        fun step(i: Int) {
            cap { b ->
                if (b == null) { finish(); return@cap }
                val bot = (b.height * 0.93).toInt(); val p = prev
                if (p == null) parts.add(Bitmap.createBitmap(b, 0, 0, b.width, bot))
                else {
                    val s = overlap(p, b, bot)
                    if (s < 0 || s >= bot - 10) { finish(); return@cap }
                    parts.add(Bitmap.createBitmap(b, 0, s, b.width, bot - s))
                }
                prev = b
                if (i >= 11) { finish(); return@cap }
                val path = Path().apply { moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.72f); lineTo(dm.widthPixels / 2f, dm.heightPixels * 0.40f) }
                dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build(), null, null)
                h.postDelayed({ step(i + 1) }, 1000)
            }
        }
        h.postDelayed({ step(0) }, 300)
    } }

    // returns the row of b where new (not yet captured) content starts, or -1
    private fun overlap(p: Bitmap, b: Bitmap, bot: Int): Int {
        val w = p.width; val pr = IntArray(w); val br = IntArray(w)
        var py = bot - 40
        while (py > bot - 420) {
            p.getPixels(pr, 0, w, 0, py, w, 1)
            if (pr.count { it != pr[0] } > w / 8) {
                for (y in 0 until bot) { b.getPixels(br, 0, w, 0, y, w, 1); if (pr.contentEquals(br)) return y + (bot - py) }
            }
            py -= 25
        }
        return -1
    }
}
