package com.raja.gesturecapture

import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.Toast
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class RecorderService : Service() {
    companion object { @Volatile var running = false; @Volatile var paused = false }
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var mr: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var th: Thread? = null
    @Volatile private var audioOn = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "pause") { if (running) { paused = !paused; try { if (paused) mr?.pause() else mr?.resume() } catch (_: Exception) {} }; return START_NOT_STICKY }
        if (i?.action == "stop") { stopAll(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        val mode = i?.getStringExtra("mode") ?: "video_mic"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Recording", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, RecorderService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "rec").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Recording…").addAction(android.R.drawable.ic_media_pause, "Stop", stop).build()
        val mic = mode == "video_mic" || mode == "audio_mic" || mode == "audio_both"
        val type = (if (mode != "audio_mic") ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0) or
                (if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
        startForeground(1, n, type)
        try {
            if (mode != "audio_mic") {
                proj = getSystemService(MediaProjectionManager::class.java)
                    .getMediaProjection(i!!.getIntExtra("code", 0), i.getParcelableExtra("data")!!)
                proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopAll() } }, null)
            }
            running = true; paused = false; GestureService.inst?.showBubble(true)
            when (mode) {
                "video", "video_mic" -> startVideo(mode == "video_mic")
                "audio_mic" -> startM4a()
                else -> startWav(mode == "audio_both")
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Failed: ${e.message}", Toast.LENGTH_LONG).show(); stopAll()
        }
        return START_NOT_STICKY
    }

    private fun out(coll: Uri, name: String, mime: String, dir: String): ParcelFileDescriptor {
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/GestureCapture")
        }
        pfd = contentResolver.openFileDescriptor(contentResolver.insert(coll, v)!!, "w")
        return pfd!!
    }

    @Suppress("DEPRECATION")
    private fun startVideo(mic: Boolean) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels and 1.inv(); val h = dm.heightPixels and 1.inv()
        val fd = out(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "rec_${System.currentTimeMillis()}.mp4", "video/mp4", "Movies")
        mr = MediaRecorder().apply {
            if (mic) setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (mic) { setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioEncodingBitRate(128000); setAudioSamplingRate(44100) }
            setVideoSize(w, h); setVideoFrameRate(30); setVideoEncodingBitRate(8_000_000)
            setOutputFile(fd.fileDescriptor); prepare()
        }
        vd = proj!!.createVirtualDisplay("rec", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mr!!.surface, null, null)
        mr!!.start()
    }

    @Suppress("DEPRECATION")
    private fun startM4a() {
        val fd = out(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "voice_${System.currentTimeMillis()}.m4a", "audio/mp4", "Music")
        mr = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioEncodingBitRate(128000); setAudioSamplingRate(44100)
            setOutputFile(fd.fileDescriptor); prepare(); start()
        }
    }

    private fun hdr(total: Long): ByteBuffer = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
        put("RIFF".toByteArray()); putInt((36 + total).toInt()); put("WAVEfmt ".toByteArray()); putInt(16)
        putShort(1); putShort(1); putInt(44100); putInt(88200); putShort(2); putShort(16)
        put("data".toByteArray()); putInt(total.toInt()); flip()
    }

    // internal (phone) sound via AudioPlaybackCapture, optionally mixed with mic -> WAV
    private fun startWav(withMic: Boolean) {
        val fd = out(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio_${System.currentTimeMillis()}.wav", "audio/wav", "Music")
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
        val sys = AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg).build()
        val mic = if (withMic) AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, 8192) else null
        val ch = FileOutputStream(fd.fileDescriptor).channel
        audioOn = true
        th = Thread {
            sys.startRecording(); mic?.startRecording(); ch.write(hdr(0))
            val a = ShortArray(2048); val b = ShortArray(2048); val bb = ByteBuffer.allocate(4096).order(ByteOrder.LITTLE_ENDIAN)
            var total = 0L
            while (audioOn) {
                val n1 = maxOf(0, sys.read(a, 0, 2048)); val n2 = if (mic != null) maxOf(0, mic.read(b, 0, 2048)) else 0
                val n = maxOf(n1, n2); if (paused) continue; bb.clear()
                for (k in 0 until n) bb.putShort(((if (k < n1) a[k].toInt() else 0) + (if (k < n2) b[k].toInt() else 0)).coerceIn(-32768, 32767).toShort())
                bb.flip(); ch.write(bb); total += n * 2
            }
            sys.stop(); sys.release(); mic?.stop(); mic?.release()
            ch.position(0); ch.write(hdr(total)); ch.close()
        }.also { it.start() }
    }

    private fun stopAll() {
        if (!running) return
        running = false; audioOn = false; paused = false; GestureService.inst?.showBubble(false)
        try { th?.join(1500) } catch (_: Exception) {}
        try { mr?.stop() } catch (_: Exception) {}
        mr?.release(); vd?.release(); proj?.stop(); pfd?.close()
        Toast.makeText(this, "Saved to GestureCapture folder", Toast.LENGTH_SHORT).show()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
}
