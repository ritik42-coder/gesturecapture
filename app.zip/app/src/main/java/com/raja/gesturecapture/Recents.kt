package com.raja.gesturecapture

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------------
// Recent apps, our own way. The accessibility service already sees every app that comes to the
// front, so this keeps a small ordered list of what you actually used — no permission needed.
// It opens as a full-screen surface with three layouts (stack, grid, carousel), springs the cards
// in, launches on tap and removes on swipe-up.
// ---------------------------------------------------------------------------------------------------
class Recents(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var body: FrameLayout? = null
    private var cards = ArrayList<View>()
    private var chipRow: LinearLayout? = null
    private var counter: TextView? = null
    private var scroller: HorizontalScrollView? = null

    private fun dp(x: Int) = LockUi.dp(s, x)
    private fun dpf(x: Float) = LockUi.dpf(s, x)
    private fun sp() = Prefs.sp(s)

    private val accent = 0xFF6C8CFF.toInt()

    fun isShown() = root != null

    // ---- the list -------------------------------------------------------------------------------
    fun track(pkg: String) {
        if (pkg.isEmpty() || pkg == s.packageName) return
        if (pkg == "android" || pkg.contains("systemui") || pkg.contains("inputmethod")) return
        h.post {
            val l = load()
            if (l.firstOrNull() == pkg) return@post
            if (!launchable(pkg)) return@post
            l.remove(pkg)
            l.add(0, pkg)
            while (l.size > 24) l.removeAt(l.size - 1)
            save(l)
        }
    }

    private fun launchable(pkg: String): Boolean = try {
        s.packageManager.getLaunchIntentForPackage(pkg) != null
    } catch (_: Exception) { false }

    private fun load(): MutableList<String> = try {
        val a = JSONArray(sp().getString("rc_list", "[]") ?: "[]")
        val l = ArrayList<String>()
        for (i in 0 until a.length()) {
            val p = a.optString(i)
            if (p.isNotEmpty()) l.add(p)
        }
        l
    } catch (_: Exception) { ArrayList() }

    private fun save(l: List<String>) {
        val a = JSONArray()
        l.forEach { a.put(it) }
        sp().edit().putString("rc_list", a.toString()).apply()
    }

    fun clear() { save(emptyList()) }

    fun layout(): String = sp().getString("rc_layout", "stack") ?: "stack"
    fun setLayout(v: String) { sp().edit().putString("rc_layout", v).apply() }

    fun count(): Int = load().size

    // ---- window ---------------------------------------------------------------------------------
    fun show() { h.post { if (root == null) build() } }
    fun hide() { h.post { removeNow() } }

    private fun removeNow() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; body = null; cards.clear(); chipRow = null; counter = null; scroller = null
    }

    private fun label(pkg: String): String = try {
        s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    // ---- build ----------------------------------------------------------------------------------
    private fun build() {
        removeNow()
        val f = FrameLayout(s)
        f.background = GradientDrawable().apply { setColor(0xFF06080F.toInt()) }
        f.addView(LockBackdrop(s), FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(s)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(14), dp(16), dp(12))
        f.addView(col, FrameLayout.LayoutParams(-1, -1))

        // ---- top row: close, clear
        val top = FrameLayout(s)
        val close = LinearLayout(s)
        close.orientation = LinearLayout.HORIZONTAL
        close.gravity = Gravity.CENTER_VERTICAL
        close.setPadding(dp(12), dp(9), dp(16), dp(9))
        close.background = LockUi.glass(dpf(22f), 0x14FFFFFF, 0x1FFFFFFF, dpf(1f))
        val arrow = ImageView(s)
        try { arrow.setImageResource(R.drawable.ic_back) } catch (_: Exception) {}
        arrow.setColorFilter(0xF2FFFFFF.toInt())
        close.addView(arrow, LinearLayout.LayoutParams(dp(15), dp(15)))
        close.addView(txt("Close", 13f, 0xE6FFFFFF.toInt(), "sans-serif-medium"),
            LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        close.setOnClickListener { hide() }
        top.addView(close, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))

        val clearBtn = txt("Clear list", 12f, 0xB3FFFFFF.toInt(), "sans-serif-medium")
        clearBtn.setPadding(dp(12), dp(9), dp(12), dp(9))
        clearBtn.background = LockUi.glass(dpf(18f), 0x0FFFFFFF, 0x1FFFFFFF, dpf(1f))
        clearBtn.setOnClickListener {
            clear()
            h.postDelayed({ removeNow(); build() }, 120)
        }
        top.addView(clearBtn, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        col.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- title
        val title = txt("Recent apps", 24f, Color.WHITE, "sans-serif-medium")
        title.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        col.addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })

        counter = txt("", 12.5f, 0x8AFFFFFF.toInt())
        counter?.gravity = Gravity.START
        col.addView(counter, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })

        // ---- layout switch
        chipRow = LinearLayout(s)
        chipRow?.gravity = Gravity.CENTER_VERTICAL
        col.addView(chipRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // ---- body
        val b = FrameLayout(s)
        body = b
        col.addView(b, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })

        val p = WindowManager.LayoutParams(-1, -1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(f, p) } catch (_: Exception) { return }
        root = f

        f.alpha = 0f
        f.animate().alpha(1f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()

        paintChips()
        fill()
    }

    private fun txt(t: String, size: Float, color: Int, face: String = "sans-serif"): TextView {
        val v = TextView(s)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        v.typeface = Typeface.create(face, Typeface.NORMAL)
        v.gravity = Gravity.CENTER
        v.includeFontPadding = false
        return v
    }

    private fun paintChips() {
        val row = chipRow ?: return
        row.removeAllViews()
        val cur = layout()
        listOf("stack" to "Stack", "grid" to "Grid", "carousel" to "Carousel").forEach { (k, name) ->
            val on = k == cur
            val b = txt(name, 12f, if (on) Color.WHITE else 0xB3FFFFFF.toInt(), "sans-serif-medium")
            b.setPadding(dp(14), dp(8), dp(14), dp(8))
            b.background = if (on)
                GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF6C8CFF.toInt(), 0xFFA855F7.toInt())).apply { cornerRadius = dpf(16f) }
            else LockUi.glass(dpf(16f), 0x12FFFFFF, 0x26FFFFFF, dpf(1f))
            b.setOnClickListener {
                setLayout(k)
                paintChips()
                fill()
            }
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
    }

    private fun fill() {
        val b = body ?: return
        b.removeAllViews()
        cards.clear()
        val list = load()
        counter?.text = when {
            list.isEmpty() -> "Nothing yet"
            list.size == 1 -> "1 app · swipe a card up to remove it"
            else -> "${list.size} apps · swipe a card up to remove it"
        }
        if (list.isEmpty()) {
            val empty = LinearLayout(s)
            empty.orientation = LinearLayout.VERTICAL
            empty.gravity = Gravity.CENTER
            val i = txt("🕘", 34f, 0x66FFFFFF)
            empty.addView(i)
            empty.addView(txt("Open a few apps and they will show up here", 13f, 0x8AFFFFFF.toInt()),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            b.addView(empty, FrameLayout.LayoutParams(-1, -1))
            return
        }
        when (layout()) {
            "grid" -> fillGrid(list)
            "carousel" -> fillCarousel(list)
            else -> fillStack(list)
        }
        springIn()
    }

    private fun springIn() {
        cards.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dpf(26f)
            v.scaleX = 0.92f; v.scaleY = 0.92f
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay((i * 42).toLong()).setDuration(430)
                .setInterpolator(OvershootInterpolator(1.15f)).start()
        }
    }

    // ---- the three layouts ----------------------------------------------------------------------
    private fun fillStack(list: List<String>) {
        val b = body ?: return
        val sv = ScrollView(s)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        val box = LinearLayout(s)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(4), 0, dp(30))
        sv.addView(box, FrameLayout.LayoutParams(-1, -2))
        list.forEachIndexed { i, pkg ->
            val card = card(pkg, 96)
            cards.add(card)
            box.addView(card, LinearLayout.LayoutParams(-1, dp(96)).apply {
                topMargin = if (i == 0) 0 else -dp(16)
                leftMargin = dp(minOf(i * 6, 30)); rightMargin = dp(minOf(i * 6, 30))
            })
        }
        b.addView(sv, FrameLayout.LayoutParams(-1, -1))
    }

    private fun fillGrid(list: List<String>) {
        val b = body ?: return
        val sv = ScrollView(s)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        val box = LinearLayout(s)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(4), 0, dp(30))
        var row: LinearLayout? = null
        list.forEachIndexed { i, pkg ->
            if (i % 3 == 0) {
                val r = LinearLayout(s)
                box.addView(r, LinearLayout.LayoutParams(-1, -2))
                row = r
            }
            val card = card(pkg, 104, compact = true)
            cards.add(card)
            row?.addView(card, LinearLayout.LayoutParams(0, dp(104), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        sv.addView(box, FrameLayout.LayoutParams(-1, -2))
        b.addView(sv, FrameLayout.LayoutParams(-1, -1))
    }

    private fun fillCarousel(list: List<String>) {
        val b = body ?: return
        val sv = Carousel(s)
        scroller = sv
        val box = LinearLayout(s)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(6), dp(10), dp(6), dp(10))
        val cw = minOf(dp(212), (s.resources.displayMetrics.widthPixels * 0.62f).toInt())
        list.forEach { pkg ->
            val card = card(pkg, 268, big = true)
            cards.add(card)
            box.addView(card, LinearLayout.LayoutParams(cw, -1).apply { setMargins(dp(6), dp(4), dp(6), dp(4)) })
        }
        sv.addView(box, FrameLayout.LayoutParams(-2, -2))
        sv.onSettle = { cx ->
            // lift whichever card is nearest the middle
            val mid = cx + sv.width / 2f
            cards.forEach { c ->
                val cxx = c.left + c.width / 2f
                val d = abs(cxx - mid) / (cw.toFloat())
                val sc = (1f - 0.12f * d).coerceIn(0.82f, 1f)
                c.scaleX = sc; c.scaleY = sc
                c.alpha = (1f - 0.35f * d).coerceIn(0.5f, 1f)
            }
        }
        b.addView(sv, FrameLayout.LayoutParams(-1, -1))
        h.postDelayed({ sv.onSettle?.invoke(sv.scrollX) }, 300)
        h.postDelayed({ sv.onSettle?.invoke(sv.scrollX) }, 560)
    }

    // ---- one card -------------------------------------------------------------------------------
    private fun card(pkg: String, heightDp: Int, compact: Boolean = false, big: Boolean = false): View {
        val card = LinearLayout(s)
        card.orientation = if (big) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        card.gravity = if (big) Gravity.CENTER else Gravity.CENTER_VERTICAL
        card.setPadding(dp(14), dp(12), dp(14), dp(12))
        card.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0x1FFFFFFF, 0x14FFFFFF)).apply {
            cornerRadius = dpf(if (big) 26f else 22f)
            setStroke(dp(1), 0x26FFFFFF)
        }
        card.isClickable = true

        val iconSize = when { big -> 58; compact -> 40; else -> 46 }
        val ring = FrameLayout(s)
        ring.background = LockUi.glass(dpf(if (big) 20f else 16f), 0x1AFFFFFF, 0x2EFFFFFF, dpf(1f))
        val iv = ImageView(s)
        try { iv.setImageDrawable(s.packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {}
        ring.addView(iv, FrameLayout.LayoutParams(dp(iconSize), dp(iconSize), Gravity.CENTER))
        card.addView(ring, LinearLayout.LayoutParams(dp(iconSize + 18), dp(iconSize + 18)))

        val name = txt(label(pkg), if (big) 14f else 13.5f, Color.WHITE, "sans-serif-medium")
        name.gravity = if (big) Gravity.CENTER else Gravity.START or Gravity.CENTER_VERTICAL
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        if (big) card.addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        else if (compact) {
            // narrow tiles: the name goes under the icon
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER
            name.textSize = 10.5f
            name.gravity = Gravity.CENTER
            card.addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        } else {
            card.addView(name, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        }

        attachTouch(card, pkg)
        return card
    }

    // tap to open, swipe up to forget
    private fun attachTouch(v: View, pkg: String) {
        var y0 = 0f
        var moved = false
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    y0 = ev.rawY
                    moved = false
                    view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(110).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = ev.rawY - y0
                    if (dy < -dpf(6f)) {
                        moved = true
                        view.translationY = dy
                        view.alpha = (1f + dy / dpf(260f)).coerceIn(0.2f, 1f)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                    if (view.translationY < -dpf(64f)) {
                        drop(view, pkg)
                    } else {
                        view.animate().translationY(0f).alpha(1f).setDuration(170)
                            .setInterpolator(OvershootInterpolator(1.4f)).start()
                        if (!moved && ev.actionMasked == MotionEvent.ACTION_UP) open(pkg)
                    }
                }
            }
            true
        }
    }

    private fun drop(v: View, pkg: String) {
        cards.remove(v)
        v.animate().translationY(-dpf(320f)).alpha(0f).scaleX(0.9f).scaleY(0.9f)
            .setDuration(230).setInterpolator(DecelerateInterpolator()).withEndAction {
                val l = load()
                l.remove(pkg)
                save(l)
                (v.parent as? android.view.ViewGroup)?.removeView(v)
                counter?.text = when {
                    load().isEmpty() -> "Nothing yet"
                    else -> "${load().size} apps · swipe a card up to remove it"
                }
                if (load().isEmpty()) fill()
            }.start()
    }

    private fun open(pkg: String) {
        try {
            val i = s.packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                s.startActivity(i)
                LockUi.buzz(s, 16, 120)
            }
        } catch (_: Exception) {}
        hide()
    }

    // horizontal pager for the carousel: follows the finger, snaps, and reports where it settled
    private inner class Carousel(c: Context) : HorizontalScrollView(c) {
        var onSettle: ((Int) -> Unit)? = null
        private var downX = 0f
        private var vt: VelocityTracker? = null

        init {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(ev)
                }
                MotionEvent.ACTION_MOVE -> vt?.addMovement(ev)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    vt?.addMovement(ev)
                    vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    vt?.recycle(); vt = null
                    val step = if (cards.size > 1) (cards[1].left - cards[0].left).toFloat() else 1f
                    var target = ((scrollX + step / 2f) / step).toInt()
                    if (vx < -650f) target += 1
                    else if (vx > 650f) target -= 1
                    target = target.coerceIn(0, (cards.size - 1).coerceAtLeast(0))
                    val x = (target * step).toInt()
                    val handled = super.dispatchTouchEvent(ev)   // let the card see its own tap
                    smoothScrollTo(x, 0)
                    onSettle?.invoke(x)
                    return handled
                }
            }
            return super.dispatchTouchEvent(ev)
        }

        override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
            super.onScrollChanged(l, t, oldl, oldt)
            onSettle?.invoke(l)
        }
    }
}
