package com.raja.gesturecapture

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

// ---------------------------------------------------------------------------------------------------
// The keypad, drawn by hand instead of assembled from buttons, so every key can breathe: keys stagger
// in on show, sink and glow under the finger, throw a ring of light on each tap, and the fingerprint
// and backspace keys are drawn as vectors. Haptics on every press.
// ---------------------------------------------------------------------------------------------------
class LockKeypad(c: Context) : View(c) {
    var onDigit: ((String) -> Unit)? = null
    var onDelete: (() -> Unit)? = null
    var onBio: (() -> Unit)? = null

    var showBio = true
        set(v) { field = v; invalidate() }

    var inputEnabled = true
        set(v) { field = v; if (!v) keys.forEach { it.target = 0f }; invalidate() }

    private val den = resources.displayMetrics.density
    private fun d(x: Float) = x * den

    private class Key {
        var press = 0f
        var target = 0f
        var rippleAt = -1L
        var enterAt = 0L
        var shader: Shader? = null
    }

    private val keys = Array(12) { Key() }
    private val label = arrayOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "")
    private val sub = arrayOf("", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ", "", "+", "")

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d(1f)
        color = 0x1FFFFFFF
    }
    private val pressP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x1FFFFFFF }
    private val rip = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d(1.6f)
        strokeCap = Paint.Cap.ROUND
    }
    private val digit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xF2FFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    }
    private val letters = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x5CFFFFFF
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        letterSpacing = 0.12f
    }
    private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x5A000000 }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d(1.9f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0xE6FFFFFF.toInt()
    }

    private var cellW = 0f
    private var cellH = 0f
    private var padH = 0f
    private var radius = 0f
    private var downIdx = -1
    private var enterBase = 0L
    private val tmpRect = RectF()
    private val path = Path()

    fun playEnter() {
        enterBase = SystemClock.uptimeMillis() + 40
        keys.forEachIndexed { i, k -> k.enterAt = enterBase + i * 38L; k.press = 0f; k.rippleAt = -1L }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        padH = d(10f)
        cellW = (w - padH * 2) / 3f
        cellH = h / 4f
        radius = min(cellW, cellH) * 0.44f
        digit.textSize = radius * 0.86f
        letters.textSize = radius * 0.26f
        for (i in 0 until 12) {
            val (cx, cy) = center(i)
            keys[i].shader = LinearGradient(cx, cy - radius, cx, cy + radius,
                intArrayOf(0x1FFFFFFF, 0x0AFFFFFF), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        }
    }

    private fun center(i: Int): Pair<Float, Float> {
        val col = i % 3
        val row = i / 3
        return Pair(padH + cellW * (col + 0.5f), cellH * (row + 0.5f))
    }

    private fun hit(x: Float, y: Float): Int {
        val col = ((x - padH) / cellW).toInt()
        val row = (y / cellH).toInt()
        if (col < 0 || col > 2 || row < 0 || row > 3) return -1
        val i = row * 3 + col
        if (i == 9 && !showBio) return -1
        return i
    }

    private fun fire(i: Int) {
        when {
            i == 11 -> onDelete?.invoke()
            i == 9 -> if (showBio) onBio?.invoke()
            label[i].isNotEmpty() -> onDigit?.invoke(label[i])
        }
    }

    private fun tap() { if (LockStore.haptics(context)) LockUi.buzz(context, 11, 80) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!inputEnabled) return true
        val now = SystemClock.uptimeMillis()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downIdx = hit(e.x, e.y)
                if (downIdx >= 0) { keys[downIdx].target = 1f; keys[downIdx].rippleAt = now; tap() }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val i = hit(e.x, e.y)
                if (i != downIdx) {
                    if (downIdx >= 0) keys[downIdx].target = 0f
                    downIdx = i
                    if (i >= 0) { keys[i].target = 1f; keys[i].rippleAt = now; tap() }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val i = downIdx
                if (i >= 0) { keys[i].target = 0f; fire(i) }
                downIdx = -1
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                if (downIdx >= 0) keys[downIdx].target = 0f
                downIdx = -1
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        var alive = false
        for (i in 0 until 12) {
            val k = keys[i]
            // entrance
            var enter = 1f
            if (k.enterAt > 0) {
                val p = ((now - k.enterAt) / 360f).coerceIn(0f, 1f)
                if (p < 1f) alive = true
                enter = easeOutBack(p)
            }
            // press spring
            if (k.press != k.target) {
                k.press += (k.target - k.press) * 0.34f
                if (kotlin.math.abs(k.target - k.press) < 0.01f) k.press = k.target
                alive = true
            }
            if (k.rippleAt > 0 && now - k.rippleAt < 460) alive = true

            val (cx, cy) = center(i)
            val empty = (i == 9 && !showBio)
            val r = radius
            val sc = enter * (1f - 0.055f * k.press)

            canvas.save()
            canvas.translate(cx, cy)
            canvas.scale(sc, sc)

            if (!empty) {
                fill.shader = k.shader
                fill.alpha = (150 + 105 * k.press).toInt().coerceIn(0, 255)
                canvas.drawCircle(0f, 0f, r, fill)
                fill.shader = null
                line.alpha = (120 + 90 * k.press).toInt().coerceIn(0, 255)
                canvas.drawCircle(0f, 0f, r, line)
                if (k.press > 0.01f) {
                    pressP.alpha = (k.press * 70).toInt()
                    canvas.drawCircle(0f, 0f, r * (0.94f + 0.06f * k.press), pressP)
                }
                // ripple ring
                if (k.rippleAt > 0) {
                    val q = ((now - k.rippleAt) / 460f).coerceIn(0f, 1f)
                    if (q < 1f) {
                        rip.color = Color.argb(((1f - q) * 120).toInt(), 255, 255, 255)
                        rip.strokeWidth = d(1.8f) * (1f - q * 0.4f)
                        canvas.drawCircle(0f, 0f, r * (1f + 0.85f * q), rip)
                    }
                }
                if (label[i].isNotEmpty()) {
                    canvas.drawText(label[i], 0f, r * 0.30f, digit)
                    if (sub[i].isNotEmpty()) canvas.drawText(sub[i], 0f, r * 0.68f, letters)
                } else if (i == 11) {
                    drawBackspace(canvas, r)
                } else if (i == 9) {
                    drawFinger(canvas, r)
                }
            }
            canvas.restore()
        }
        if (!inputEnabled) canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        if (alive) postInvalidateOnAnimation()
    }

    private fun easeOutBack(p: Float): Float {
        val c = 1.35f
        val x = p - 1f
        return 1f + (c + 1f) * x * x * x + c * x * x
    }

    // nested arcs, open at the bottom, with a core line: reads as a fingerprint at any size
    private fun drawFinger(canvas: Canvas, r: Float) {
        val s = r * 0.62f
        path.reset()
        for (i in 0..2) {
            val rr = s * (0.34f + 0.30f * i)
            tmpRect.set(-rr, -rr, rr, rr)
            path.addArc(tmpRect, 148f, 244f)
        }
        canvas.drawPath(path, icon)
        canvas.drawLine(0f, -s * 0.10f, 0f, s * 0.52f, icon)
    }

    private fun drawBackspace(canvas: Canvas, r: Float) {
        val w = r * 0.86f
        val h = r * 0.66f
        val rr = h * 0.26f
        path.reset()
        path.moveTo(-w * 0.62f, 0f)
        path.lineTo(-w * 0.16f, -h * 0.5f)
        path.lineTo(w * 0.50f - rr, -h * 0.5f)
        path.quadTo(w * 0.58f, -h * 0.5f, w * 0.58f, -h * 0.5f + rr)
        path.lineTo(w * 0.58f, h * 0.5f - rr)
        path.quadTo(w * 0.58f, h * 0.5f, w * 0.50f - rr, h * 0.5f)
        path.lineTo(-w * 0.16f, h * 0.5f)
        path.close()
        canvas.drawPath(path, icon)
        path.reset()
        path.moveTo(w * 0.02f, -h * 0.15f)
        path.lineTo(w * 0.26f, h * 0.15f)
        path.moveTo(w * 0.26f, -h * 0.15f)
        path.lineTo(w * 0.02f, h * 0.15f)
        canvas.drawPath(path, icon)
    }
}
