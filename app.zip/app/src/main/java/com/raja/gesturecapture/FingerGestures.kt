package com.raja.gesturecapture

import android.accessibilityservice.FingerprintGestureController
import android.os.Handler
import android.os.Looper

// ---------------------------------------------------------------------------------------------------
// Fingerprint gestures. Android lets an accessibility service listen to swipes on the fingerprint
// sensor (API 26+), so a swipe up / down / left / right on the sensor can run any action you bind.
// Not every phone has a sensor that reports gestures — in-display sensors usually do not — so the
// app asks first and says so plainly instead of silently doing nothing.
// ---------------------------------------------------------------------------------------------------
class FingerGestures(private val s: GestureService) {
    private val h = Handler(Looper.getMainLooper())
    private var registered = false
    private var cb: FingerprintGestureController.FingerprintGestureCallback? = null
    private var lastFire = 0L

    private fun controller(): FingerprintGestureController? = try {
        s.getFingerprintGestureController()
    } catch (_: Exception) { null }

    // true only when this phone actually reports sensor gestures right now
    fun available(): Boolean = try {
        controller()?.isGestureDetectionAvailable == true
    } catch (_: Exception) { false }

    fun hasSensor(): Boolean = try {
        s.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_FINGERPRINT)
    } catch (_: Exception) { false }

    fun start() {
        if (registered) return
        val c = controller() ?: return
        // hold the callback in a local: a nullable var cannot be smart-cast into the register call
        val callback = cb ?: object : FingerprintGestureController.FingerprintGestureCallback() {
            override fun onGestureDetected(gesture: Int) {
                val dir = when (gesture) {
                    FingerprintGestureController.FINGERPRINT_GESTURE_SWIPE_UP -> "up"
                    FingerprintGestureController.FINGERPRINT_GESTURE_SWIPE_DOWN -> "down"
                    FingerprintGestureController.FINGERPRINT_GESTURE_SWIPE_LEFT -> "left"
                    FingerprintGestureController.FINGERPRINT_GESTURE_SWIPE_RIGHT -> "right"
                    else -> return
                }
                fire(dir)
            }

            override fun onGestureDetectionAvailabilityChanged(available: Boolean) {
                // the sensor stops reporting while it is busy authenticating, so this can flip
            }
        }.also { cb = it }
        try {
            c.registerFingerprintGestureCallback(callback, h)
            registered = true
        } catch (_: Exception) { registered = false }
    }

    fun stop() {
        if (!registered) return
        val callback = cb ?: return
        try { controller()?.unregisterFingerprintGestureCallback(callback) } catch (_: Exception) {}
        registered = false
    }

    private fun fire(dir: String) {
        val act = try { Prefs.sp(s).getString("fg_$dir", "none") } catch (_: Exception) { "none" } ?: "none"
        if (act == "none") return
        val now = System.currentTimeMillis()
        if (now - lastFire < 700) return          // one action per tap of the sensor
        lastFire = now
        h.post {
            try { LockUi.buzz(s, 22, 160) } catch (_: Exception) {}
            try { s.doAct(act, "finger_$dir") } catch (_: Exception) {}
        }
    }
}
