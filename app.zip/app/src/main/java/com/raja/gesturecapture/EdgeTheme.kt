package com.raja.gesturecapture

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------------
// One place for the edge panel's look: a light palette and a dark palette, built from the accent
// colour you pick in settings. Every view in the panel asks this for its colours, so the whole
// panel switches between light and dark together, and stays colourful either way.
// ---------------------------------------------------------------------------------------------------
class EdgeTheme(
    val dark: Boolean,
    val a1: Int,
    val a2: Int,
    val cardTop: Int,
    val cardBottom: Int,
    val text: Int,
    val sub: Int,
    val faint: Int,
    val tile: Int,
    val tileLine: Int,
    val line: Int,
    val scrim: Int,
    val handleA: Int,
    val handleB: Int,
    val handleLine: Int
) {
    fun onText(): Int = if (dark) Color.WHITE else 0xFF0B0B12.toInt()

    companion object {
        fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or ((a.coerceIn(0, 255)) shl 24)

        fun blend(c1: Int, c2: Int, f: Float): Int {
            val k = f.coerceIn(0f, 1f)
            val r = (Color.red(c1) * (1 - k) + Color.red(c2) * k).toInt()
            val g = (Color.green(c1) * (1 - k) + Color.green(c2) * k).toInt()
            val b = (Color.blue(c1) * (1 - k) + Color.blue(c2) * k).toInt()
            return Color.rgb(r, g, b)
        }

        fun lighten(c: Int, f: Float): Int = blend(c, Color.WHITE, f)
        fun darken(c: Int, f: Float): Int = blend(c, Color.BLACK, f)

        // theme key: "auto" | "light" | "dark"
        fun isDark(c: Context, cfg: JSONObject): Boolean {
            return when (cfg.optString("theme", "auto")) {
                "dark" -> true
                "light" -> false
                else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                        Configuration.UI_MODE_NIGHT_YES
            }
        }

        fun of(c: Context, cfg: JSONObject): EdgeTheme {
            val a1 = parse(cfg.optString("c1", "#2563EB"), "#2563EB")
            val a2 = parse(cfg.optString("c2", "#7C3AED"), "#7C3AED")
            val dark = isDark(c, cfg)
            return if (dark) {
                EdgeTheme(
                    dark = true, a1 = a1, a2 = a2,
                    cardTop = alpha(0xFF17171F.toInt(), 246),
                    cardBottom = alpha(0xFF0A0A10.toInt(), 250),
                    text = Color.WHITE,
                    sub = 0xFFB4B9C6.toInt(),
                    faint = 0xFF7C8194.toInt(),
                    tile = 0x1AFFFFFF,
                    tileLine = 0x26FFFFFF,
                    line = 0x1FFFFFFF,
                    scrim = 0x99000000.toInt(),
                    handleA = alpha(lighten(a1, 0.10f), 235),
                    handleB = alpha(darken(a2, 0.15f), 235),
                    handleLine = 0x59FFFFFF
                )
            } else {
                EdgeTheme(
                    dark = false, a1 = a1, a2 = a2,
                    cardTop = alpha(0xFFFFFFFF.toInt(), 250),
                    cardBottom = alpha(0xFFF1F3F9.toInt(), 252),
                    text = 0xFF0B0B12.toInt(),
                    sub = 0xFF5C6273.toInt(),
                    faint = 0xFF8A90A0.toInt(),
                    tile = 0x0F0B0B12,
                    tileLine = 0x1A0B0B12,
                    line = 0x140B0B12,
                    scrim = 0x66000000,
                    handleA = alpha(lighten(a1, 0.18f), 240),
                    handleB = alpha(darken(a1, 0.10f), 240),
                    handleLine = 0x40FFFFFF
                )
            }
        }

        fun parse(s: String?, def: String): Int = try {
            Color.parseColor(if (s.isNullOrBlank()) def else s)
        } catch (_: Exception) {
            try { Color.parseColor(def) } catch (_: Exception) { 0xFF2563EB.toInt() }
        }

        // each panel gets its own colour so the panel feels alive as you swipe through it
        fun accentFor(key: String, a1: Int, a2: Int): Pair<Int, Int> = when (key) {
            "apps" -> a1 to a2
            "clip" -> 0xFF14B8A6.toInt() to 0xFF0E7490.toInt()
            "actions" -> 0xFFF59E0B.toInt() to 0xFFEF4444.toInt()
            "controls" -> 0xFF8B5CF6.toInt() to 0xFF6366F1.toInt()
            "tools" -> 0xFFEC4899.toInt() to 0xFF8B5CF6.toInt()
            "draw" -> 0xFF06B6D4.toInt() to 0xFF3B82F6.toInt()
            "device" -> 0xFF22C55E.toInt() to 0xFF0EA5E9.toInt()
            "timer" -> 0xFFF97316.toInt() to 0xFFDB2777.toInt()
            "compass" -> 0xFF3B82F6.toInt() to 0xFF06B6D4.toInt()
            else -> a1 to a2
        }
    }
}
