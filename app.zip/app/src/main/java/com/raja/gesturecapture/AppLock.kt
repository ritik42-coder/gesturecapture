package com.raja.gesturecapture

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------------
// App lock. Pick the apps you want to keep private. When one of them comes to the front, a PIN pad
// covers it before anything is shown. Right PIN opens it; leaving the app locks it again.
// The PIN lives in this app's private storage. Nothing is sent anywhere.
// ---------------------------------------------------------------------------------------------------
class AppLock(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var cur = ""
    private var unlocked = ""
    private var buf = ""
    private var dots: LinearLayout? = null

    private fun sec(): JSONObject = try {
        JSONObject(Prefs.sp(s).getString("fx", "{}") ?: "{}").optJSONObject("al") ?: JSONObject()
    } catch (_: Exception) { JSONObject() }

    private fun dp(x: Int) = (x * s.resources.displayMetrics.density).toInt()
    fun on() = sec().optBoolean("on", false)
    private fun pin(): String = (Prefs.sp(s).getString("al_pin", "") ?: "").ifBlank { "1234" }

    fun sync() { h.post { if (!on()) hide() } }
    fun destroy() { h.post { hide() } }
    fun hideNow() { h.post { hide() } }

    private fun locked(pkg: String): Boolean {
        val a: JSONArray = sec().optJSONArray("apps") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == pkg) return true
        return false
    }

    // never lock these, or the phone can be locked out of itself
    private fun safe(pkg: String): Boolean {
        if (pkg == s.packageName) return true
        if (pkg == "android" || pkg.contains("systemui") || pkg.contains("inputmethod") || pkg.contains("launcher")) return true
        if (pkg == "com.android.settings") return true
        return try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            s.packageManager.resolveActivity(i, 0)?.activityInfo?.packageName == pkg
        } catch (_: Exception) { false }
    }

    fun onForeground(pkg: String) { h.post {
        if (pkg.isEmpty() || pkg == s.packageName) return@post
        if (pkg != unlocked && pkg != cur) unlocked = ""
        if (!on()) { hide(); return@post }
        if (root != null) { if (pkg != cur) hide(); return@post }
        if (safe(pkg) || !locked(pkg)) return@post
        if (unlocked == pkg) return@post
        cur = pkg
        show(pkg)
    } }

    private fun buzz(ms: Long = 30) {
        try { s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(ms, 255)) } catch (_: Exception) {}
    }

    private fun hide() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; dots = null; buf = ""
    }

    private fun show(pkg: String) {
        hide()
        val name = try { s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        val f = FrameLayout(s)
        f.background = GradientDrawable().apply { setColor(0xFF070A12.toInt()) }

        val col = LinearLayout(s)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(28), dp(60), dp(28), dp(28))

        // app icon in a soft ring
        val ring = FrameLayout(s)
        ring.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x14FFFFFF) }
        val iv = ImageView(s)
        try { iv.setImageDrawable(s.packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {}
        ring.addView(iv, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.CENTER))
        col.addView(ring, LinearLayout.LayoutParams(dp(76), dp(76)).apply { topMargin = dp(10) })

        val nm = TextView(s)
        nm.text = name; nm.textSize = 16f; nm.setTextColor(Color.WHITE); nm.gravity = Gravity.CENTER
        nm.maxLines = 1; nm.ellipsize = TextUtils.TruncateAt.END
        nm.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        col.addView(nm, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        val sub = TextView(s)
        sub.text = "Locked · enter PIN"; sub.textSize = 11.5f; sub.setTextColor(0x88FFFFFF.toInt()); sub.gravity = Gravity.CENTER
        col.addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        // PIN dots
        val dl = LinearLayout(s); dl.gravity = Gravity.CENTER
        dots = dl
        val n = pin().length.coerceIn(4, 8)
        for (i in 0 until n) {
            val d = View(s)
            d.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x33FFFFFF) }
            dl.addView(d, LinearLayout.LayoutParams(dp(13), dp(13)).apply { setMargins(dp(7), 0, dp(7), 0) })
        }
        col.addView(dl, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })

        // keypad
        val pad = LinearLayout(s); pad.orientation = LinearLayout.VERTICAL; pad.gravity = Gravity.CENTER_HORIZONTAL
        var row: LinearLayout? = null
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫")
        keys.forEachIndexed { i, k ->
            if (i % 3 == 0) { val r = LinearLayout(s); r.gravity = Gravity.CENTER; pad.addView(r); row = r }
            val b = TextView(s)
            b.text = k; b.textSize = 21f; b.gravity = Gravity.CENTER
            b.setTextColor(if (k == "⌫") 0xCCFFFFFF.toInt() else Color.WHITE)
            b.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
            if (k.isNotEmpty()) {
                b.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (k == "⌫") 0x10FFFFFF else 0x1AFFFFFF) }
                b.setOnClickListener { tap(k) }
            }
            row?.addView(b, LinearLayout.LayoutParams(dp(66), dp(66)).apply { setMargins(dp(7), dp(7), dp(7), dp(7)) })
        }
        col.addView(pad, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        val home = TextView(s)
        home.text = "Use PIN, or go home"; home.textSize = 12f; home.setTextColor(0x99FFFFFF.toInt()); home.gravity = Gravity.CENTER
        home.setPadding(dp(16), dp(14), dp(16), dp(14))
        home.setOnClickListener { hide(); try { s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) } catch (_: Exception) {} }
        col.addView(home, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        f.addView(col, FrameLayout.LayoutParams(-1, -1))
        val p = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(f, p) } catch (_: Exception) { return }
        root = f
        f.alpha = 0f; f.scaleX = 0.97f; f.scaleY = 0.97f
        f.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
        paintDots()
    }

    private fun paintDots() {
        val dl = dots ?: return
        for (i in 0 until dl.childCount) {
            val d = dl.getChildAt(i)
            d.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (i < buf.length) 0xFF2F7BFF.toInt() else 0x33FFFFFF)
            }
            d.scaleX = if (i < buf.length) 1.15f else 1f
            d.scaleY = d.scaleX
        }
    }

    private fun tap(k: String) {
        buzz(14)
        if (k == "⌫") { if (buf.isNotEmpty()) buf = buf.dropLast(1); paintDots(); return }
        if (buf.length >= pin().length) return
        buf += k
        paintDots()
        if (buf.length == pin().length) {
            if (buf == pin()) {
                buzz(40)
                unlocked = cur
                val f = root
                root = null; dots = null; buf = ""
                if (f != null) {
                    f.animate().alpha(0f).scaleX(1.03f).scaleY(1.03f).setDuration(170).withEndAction {
                        try { wm.removeView(f) } catch (_: Exception) {}
                    }.start()
                }
            } else {
                buzz(70)
                val f = root
                if (f != null) {
                    f.animate().translationX(dp(10).toFloat()).setDuration(55).withEndAction {
                        f.animate().translationX(-dp(10).toFloat()).setDuration(55).withEndAction {
                            f.animate().translationX(0f).setDuration(55).start()
                        }.start()
                    }.start()
                }
                buf = ""
                paintDots()
            }
        }
    }
}
