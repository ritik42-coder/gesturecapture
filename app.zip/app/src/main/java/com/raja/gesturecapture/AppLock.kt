package com.raja.gesturecapture

import android.accessibilityservice.AccessibilityService
import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------------
// The app lock. Pick the apps you want to keep private; when one of them comes to the front this
// premium lock screen covers it before anything is shown. Unlock with a PIN, a pattern, or the
// phone's own fingerprint / face. First run walks you through registering a PIN.
//
// Credentials live in this app's private storage as salted hashes. Nothing is sent anywhere.
// ---------------------------------------------------------------------------------------------------
class AppLock(private val s: GestureService, private val wm: WindowManager) {
    private companion object {
        const val ST_UNLOCK = 0
        const val ST_SET_PIN = 1
        const val ST_CONFIRM_PIN = 2
        const val ST_SET_PAT = 3
        const val ST_CONFIRM_PAT = 4

        val ACCENT = 0xFF6C8CFF.toInt()
        val ACCENT2 = 0xFFA855F7.toInt()
        val DANGER = 0xFFFF5C7A.toInt()
        val MUTED = 0x8AFFFFFF.toInt()

        // the six looks of the lock screen, picked in settings
        val ACCENTS = intArrayOf(
            0xFF6C8CFF.toInt(), 0xFF22D3EE.toInt(), 0xFF34D399.toInt(),
            0xFFFFB020.toInt(), 0xFFFF5C7A.toInt(), 0xFFA855F7.toInt()
        )
    }

    private val h = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var cur = ""
    private var unlocked = ""
    private var demo = false
    private var stage = ST_UNLOCK
    private var mode = "pin"
    private var buf = ""
    private var firstPin = ""
    private var firstPat = ""
    private var autoDone = false
    private var busyBio = false
    private var accent = ACCENT
    private var lastPkg = ""
    private var unlockedAt = 0L

    private var dots: LinearLayout? = null
    private var msg: TextView? = null
    private var pad: LockKeypad? = null
    private var pat: LockPattern? = null
    private var link: TextView? = null
    private var title: TextView? = null
    private var pill: TextView? = null
    private var center: FrameLayout? = null
    private var hero: FrameLayout? = null
    private var tick: Runnable? = null

    private fun dp(x: Int) = LockUi.dp(s, x)
    private fun dpf(x: Float) = LockUi.dpf(s, x)

    private fun sec(): JSONObject = try {
        JSONObject(Prefs.sp(s).getString("fx", "{}") ?: "{}").optJSONObject("al") ?: JSONObject()
    } catch (_: Exception) { JSONObject() }

    fun on() = sec().optBoolean("on", false)

    private fun locked(pkg: String): Boolean {
        val a: JSONArray = sec().optJSONArray("apps") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == pkg) return true
        return false
    }

    // never lock these, or the phone can be locked out of itself
    private fun safe(pkg: String): Boolean {
        if (pkg == s.packageName) return true
        if (pkg == "android" || pkg.contains("systemui") || pkg.contains("inputmethod") || pkg.contains("launcher")) return true
        if (pkg == "com.android.settings") return true
        return try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            s.packageManager.resolveActivity(i, 0)?.activityInfo?.packageName == pkg
        } catch (_: Exception) { false }
    }

    // what the lock screen is allowed to say about the app behind it
    private fun nameFor(pkg: String): String = if (!demo && LockStore.hideIcon(s)) "Locked app" else label(pkg)

    private fun displayName(): String = nameFor(cur)

    private fun label(pkg: String): String = try {
        if (pkg.isEmpty()) "Preview" else
            s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { if (pkg.isEmpty()) "Preview" else pkg }

    // ---- lifecycle ---------------------------------------------------------------------------------
    fun sync() { h.post { if (!on() && !demo) removeNow() } }
    fun destroy() { h.post { removeNow() } }
    fun hideNow() { h.post { removeNow() } }

    fun demo() { h.post { show("", true, false) } }

    // re-lock everything at once, including the app that is on screen right now
    fun lockNow() {
        h.post {
            unlocked = ""
            removeNow()
            if (lastPkg.isNotEmpty() && !safe(lastPkg) && locked(lastPkg)) {
                cur = lastPkg
                show(lastPkg, false, false)
            }
        }
    }

    fun onForeground(pkg: String) {
        h.post {
            if (pkg.isEmpty() || pkg == s.packageName) return@post
            if (busyBio) return@post
            lastPkg = pkg
            if (pkg != unlocked && pkg != cur) {
                // "re-lock after" gives an app a short grace window before it locks again
                val grace = LockStore.relock(s) * 1000L
                val keep = unlocked.isNotEmpty() && grace > 0 &&
                    System.currentTimeMillis() - unlockedAt < grace
                if (!keep) unlocked = ""
            }
            if (!on() && !demo) { removeNow(); return@post }
            if (root != null) { if (pkg != cur) removeNow(); return@post }
            if (safe(pkg) || !locked(pkg)) return@post
            if (unlocked == pkg) return@post
            cur = pkg
            show(pkg, false, true)
        }
    }

    // ---- window ------------------------------------------------------------------------------------
    private fun removeNow() {
        stopTick()
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        dots = null; msg = null; pad = null; pat = null; link = null
        title = null; pill = null; center = null; hero = null
        buf = ""
        stage = ST_UNLOCK
        demo = false
    }

    private fun txt(t: String, size: Float, color: Int, face: String = "sans-serif"): TextView {
        val v = TextView(s)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        v.typeface = Typeface.create(face, Typeface.NORMAL)
        v.gravity = Gravity.CENTER
        v.includeFontPadding = false
        return v
    }

    private fun say(t: String, color: Int = MUTED) {
        msg?.text = t
        msg?.setTextColor(color)
    }

    private fun hint(): String = when (stage) {
        ST_SET_PIN -> "Choose a 4-digit PIN"
        ST_CONFIRM_PIN -> "Enter the same 4 digits"
        ST_SET_PAT -> "Draw a pattern with at least 4 dots"
        ST_CONFIRM_PAT -> "Draw the same pattern again"
        else -> when {
            demo -> "Preview · unlock to close"
            mode == "pattern" -> "Draw your pattern"
            else -> "Enter your 4-digit PIN"
        }
    }

    private fun bioReady() = LockStore.bio(s) && LockBio.enrolled(s)

    // ---- build -------------------------------------------------------------------------------------
    private fun show(pkg: String, isDemo: Boolean, auto: Boolean) {
        removeNow()
        cur = pkg
        demo = isDemo
        autoDone = !auto
        buf = ""; firstPin = ""; firstPat = ""

        val hasPin = LockStore.hasPin(s)
        val hasPat = LockStore.hasPattern(s)
        mode = LockStore.method(s)
        if (mode == "pattern" && !hasPat) mode = "pin"
        if (mode == "pin" && !hasPin && hasPat) mode = "pattern"
        stage = if (!hasPin && !hasPat) ST_SET_PIN else ST_UNLOCK
        accent = ACCENTS[LockStore.accent(s)]
        val hide = !isDemo && LockStore.hideIcon(s)

        val f = FrameLayout(s)
        f.background = GradientDrawable().apply { setColor(0xFF06080F.toInt()) }
        f.addView(LockBackdrop(s), FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(s)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(18), dp(14), dp(18), dp(10))

        // ---- top bar: back / close the locked app, plus a preview badge
        val top = FrameLayout(s)
        val close = LinearLayout(s)
        close.orientation = LinearLayout.HORIZONTAL
        close.gravity = Gravity.CENTER_VERTICAL
        close.setPadding(dp(12), dp(9), dp(16), dp(9))
        close.background = LockUi.glass(dpf(22f), 0x14FFFFFF, 0x1FFFFFFF, dpf(1f))
        val arrow = ImageView(s)
        try { arrow.setImageResource(R.drawable.ic_back) } catch (_: Exception) {}
        arrow.setColorFilter(0xF2FFFFFF.toInt())
        close.addView(arrow, LinearLayout.LayoutParams(dp(15), dp(15)))
        val closeTxt = txt(if (demo) "Exit preview" else "Close", 13f, 0xE6FFFFFF.toInt(), "sans-serif-medium")
        close.addView(closeTxt, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        close.setOnClickListener { closeApp() }
        top.addView(close, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
        if (demo) {
            val badge = txt("PREVIEW", 9.5f, 0xCCFFFFFF.toInt(), "sans-serif-medium")
            badge.letterSpacing = 0.16f
            badge.setPadding(dp(11), dp(6), dp(11), dp(6))
            badge.background = LockUi.glass(dpf(14f), 0x1FFFFFFF, 0x33FFFFFF, dpf(1f))
            top.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        }
        col.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- app icon with a breathing glow
        val heroBox = FrameLayout(s)
        hero = heroBox
        val glow = LockGlow(s)
        glow.accent(accent)
        heroBox.addView(glow, FrameLayout.LayoutParams(dp(104), dp(104)))
        val ring = FrameLayout(s)
        ring.background = LockUi.glass(dpf(27f), 0x1AFFFFFF, 0x33FFFFFF, dpf(1f))
        val icon = ImageView(s)
        try {
            if (hide) {
                icon.setImageResource(R.drawable.ic_lock)
                icon.setColorFilter(accent)
            } else if (pkg.isEmpty()) icon.setImageResource(android.R.drawable.ic_menu_camera)
            else icon.setImageDrawable(s.packageManager.getApplicationIcon(pkg))
        } catch (_: Exception) {}
        ring.addView(icon, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        heroBox.addView(ring, FrameLayout.LayoutParams(dp(80), dp(80), Gravity.CENTER))
        col.addView(heroBox, LinearLayout.LayoutParams(dp(104), dp(104)).apply { topMargin = dp(14) })

        val nameView = txt(if (hide) "Locked app" else label(pkg), 19f, Color.WHITE, "sans-serif-medium")
        nameView.maxLines = 1
        nameView.ellipsize = TextUtils.TruncateAt.END
        title = nameView
        col.addView(nameView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val pillView = txt("LOCKED", 9.5f, 0xD9FFFFFF.toInt(), "sans-serif-medium")
        pillView.letterSpacing = 0.16f
        pillView.setPadding(dp(12), dp(6), dp(12), dp(6))
        pillView.background = LockUi.glass(dpf(14f), 0x1FFFFFFF, 0x2EFFFFFF, dpf(1f))
        pill = pillView
        col.addView(pillView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })

        val msgView = txt(hint(), 12.5f, MUTED)
        msg = msgView
        col.addView(msgView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        col.addView(View(s), LinearLayout.LayoutParams(-1, 0).apply { weight = 1f })

        // ---- middle: PIN dots or the pattern grid
        val centerBox = FrameLayout(s)
        center = centerBox
        val dl = LinearLayout(s)
        dl.gravity = Gravity.CENTER
        dots = dl
        centerBox.addView(dl, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        val patView = LockPattern(s)
        patView.accent = accent
        patView.onComplete = { seq -> onPattern(seq) }
        patView.visibility = View.GONE
        pat = patView
        centerBox.addView(patView, FrameLayout.LayoutParams(dp(250), dp(250), Gravity.CENTER))

        col.addView(centerBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        col.addView(View(s), LinearLayout.LayoutParams(-1, 0).apply { weight = 1f })

        // ---- keypad
        val tall = s.resources.displayMetrics.heightPixels / s.resources.displayMetrics.density
        val kh = if (tall < 700f) 258 else if (tall < 800f) 292 else 320
        val padView = LockKeypad(s)
        padView.shuffle = LockStore.shuffle(s)
        padView.onDigit = { onDigit(it) }
        padView.onDelete = { onDelete() }
        padView.onBio = { bio() }
        pad = padView
        col.addView(padView, LinearLayout.LayoutParams(-1, dp(kh)))

        val linkView = txt("", 12.5f, 0x99FFFFFF.toInt(), "sans-serif-medium")
        linkView.setPadding(dp(14), dp(10), dp(14), dp(10))
        linkView.setOnClickListener { onLink() }
        link = linkView
        col.addView(linkView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })

        f.addView(col, FrameLayout.LayoutParams(-1, -1))

        val p = WindowManager.LayoutParams(-1, -1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(f, p) } catch (_: Exception) { return }
        root = f

        applyMode()
        paintDots()

        // entrance: the whole screen fades up, the icon pops, the rest slides in behind it
        f.alpha = 0f
        f.scaleX = 0.975f; f.scaleY = 0.975f
        f.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260)
            .setInterpolator(DecelerateInterpolator()).start()

        hero?.let {
            it.alpha = 0f; it.scaleX = 0.55f; it.scaleY = 0.55f
            it.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(560)
                .setStartDelay(70).setInterpolator(OvershootInterpolator(1.5f)).start()
        }
        listOf(title to 150L, pill to 200L, msg to 240L, center to 280L, link to 340L)
            .forEach { (v, delay) ->
                v ?: return@forEach
                v.alpha = 0f
                v.translationY = dpf(14f)
                v.animate().alpha(1f).translationY(0f).setDuration(380).setStartDelay(delay)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
        pad?.playEnter()

        // offer the sensor straight away, once per show
        if (stage == ST_UNLOCK && !autoDone && bioReady() && LockStore.bioAuto(s) && !LockStore.locked(s)) {
            autoDone = true
            h.postDelayed({ if (root != null && stage == ST_UNLOCK) bio() }, 780)
        }
    }

    // ---- state -------------------------------------------------------------------------------------
    private fun applyMode() {
        val setup = stage != ST_UNLOCK
        val patStage = stage == ST_SET_PAT || stage == ST_CONFIRM_PAT
        val usePattern = patStage || (!setup && mode == "pattern")

        dots?.visibility = if (usePattern) View.GONE else View.VISIBLE
        pat?.visibility = if (usePattern) View.VISIBLE else View.GONE
        pad?.visibility = if (patStage) View.GONE else View.VISIBLE
        pad?.showBio = !setup && bioReady()

        when (stage) {
            ST_SET_PIN -> { title?.text = "Create your PIN"; badge("STEP 1 OF 2") }
            ST_CONFIRM_PIN -> { title?.text = "Confirm your PIN"; badge("STEP 2 OF 2") }
            ST_SET_PAT -> { title?.text = "Draw a pattern"; badge("STEP 1 OF 2") }
            ST_CONFIRM_PAT -> { title?.text = "Confirm pattern"; badge("STEP 2 OF 2") }
            else -> {
                title?.text = displayName()
                badge("LOCKED")
            }
        }
        msg?.text = hint()
        msg?.setTextColor(MUTED)

        // one unlock method only, so the switch exists just while you are registering
        link?.text = when (stage) {
            ST_SET_PIN, ST_CONFIRM_PIN -> "Use a pattern instead"
            ST_SET_PAT, ST_CONFIRM_PAT -> "Use a 4-digit PIN instead"
            else -> ""
        }
        link?.visibility = if ((link?.text ?: "").isEmpty()) View.GONE else View.VISIBLE

        val cool = LockStore.locked(s)
        pad?.inputEnabled = !cool
        pat?.inputEnabled = !cool
        if (cool) startCooldown()
    }

    private fun badge(t: String) { pill?.text = t }

    private fun paintDots() {
        val dl = dots ?: return
        val total = 4
        while (dl.childCount > total) dl.removeViewAt(dl.childCount - 1)
        while (dl.childCount < total) {
            val v = View(s)
            dl.addView(v, LinearLayout.LayoutParams(dp(13), dp(13)).apply { setMargins(dp(7), 0, dp(7), 0) })
        }
        for (i in 0 until dl.childCount) {
            val v = dl.getChildAt(i)
            val filled = i < buf.length
            v.background = LockUi.oval(
                if (filled) accent else 0x2EFFFFFF,
                if (filled) 0 else 0x33FFFFFF, dp(1)
            )
            v.scaleX = if (filled) 1.2f else 1f
            v.scaleY = v.scaleX
            if (filled && i == buf.length - 1) {
                v.animate().scaleX(1.45f).scaleY(1.45f).setDuration(90).withEndAction {
                    v.animate().scaleX(1.2f).scaleY(1.2f).setDuration(120).start()
                }.start()
            }
        }
    }

    // ---- input -------------------------------------------------------------------------------------
    // Four digits, and no Continue button: the fourth digit moves on by itself, and a correct PIN
    // opens the app straight away.
    private fun onDigit(k: String) {
        if (LockStore.locked(s)) return
        when (stage) {
            ST_UNLOCK -> {
                if (buf.length >= 4) return
                buf += k
                paintDots()
                if (buf.length == 4) {
                    if (LockStore.checkPin(s, buf)) success() else wrong()
                }
            }
            ST_SET_PIN, ST_CONFIRM_PIN -> {
                if (buf.length >= 4) return
                buf += k
                paintDots()
                if (buf.length == 4) advancePin()
            }
        }
    }

    private fun onDelete() {
        if (buf.isEmpty()) return
        buf = buf.dropLast(1)
        paintDots()
    }

    private fun advancePin() {
        when (stage) {
            ST_SET_PIN -> {
                firstPin = buf
                buf = ""
                stage = ST_CONFIRM_PIN
                applyMode(); paintDots()
            }
            ST_CONFIRM_PIN -> {
                if (buf == firstPin) {
                    LockStore.setPin(s, buf)
                    mode = "pin"
                    stage = ST_UNLOCK
                    LockUi.buzz(s, 22, 150)
                    applyMode()
                    h.postDelayed({ success() }, 180)
                } else {
                    LockUi.buzz(s, 70, 220)
                    shake()
                    firstPin = ""
                    buf = ""
                    stage = ST_SET_PIN
                    applyMode(); paintDots()
                    say("Those didn't match · start again", DANGER)
                }
            }
        }
    }

    private fun onPattern(seq: String) {
        if (LockStore.locked(s)) return
        when (stage) {
            ST_SET_PAT -> {
                firstPat = seq
                buf = ""
                stage = ST_CONFIRM_PAT
                pat?.reset()
                applyMode()
                say("Draw it again to confirm")
            }
            ST_CONFIRM_PAT -> {
                if (seq == firstPat) {
                    LockStore.setPattern(s, seq)
                    mode = "pattern"
                    stage = ST_UNLOCK
                    LockUi.buzz(s, 22, 150)
                    applyMode()
                    pat?.reset()
                    h.postDelayed({ success() }, 180)
                } else {
                    LockUi.buzz(s, 70, 220)
                    shake()
                    firstPat = ""
                    stage = ST_SET_PAT
                    applyMode()
                    pat?.reset()
                    pat?.flashError()
                    say("Those didn't match · start again", DANGER)
                }
            }
            else -> {
                if (LockStore.checkPattern(s, seq)) {
                    success()
                } else {
                    wrong()
                    h.postDelayed({ pat?.reset() }, 380)
                }
            }
        }
    }

    private fun wrong() {
        LockStore.fail(s)
        LockUi.buzz(s, 70, 220)
        shake()
        buf = ""
        paintDots()
        pat?.flashError()
        if (LockStore.locked(s)) {
            startCooldown()
        } else {
            val left = 5 - LockStore.fails(s)
            say(if (left in 1..2) "Wrong · $left ${if (left == 1) "try" else "tries"} left" else "Wrong · try again", DANGER)
            h.postDelayed({ if (msg?.text?.startsWith("Wrong") == true) say(hint()) }, 1800)
        }
    }

    private fun success() {
        LockStore.clearFails(s)
        LockUi.buzz(s, 28, 180)
        unlocked = cur
        unlockedAt = System.currentTimeMillis()
        stopTick()
        pat?.flashOk()
        val f = root
        if (f != null) {
            val burst = LockBurst(s)
            f.addView(burst, FrameLayout.LayoutParams(-1, -1))
            burst.onDone = { try { f.removeView(burst) } catch (_: Exception) {} }
            burst.play()
        }
        h.postDelayed({
            val v = root
            if (v != null) {
                v.animate().alpha(0f).scaleX(1.06f).scaleY(1.06f).setDuration(250)
                    .setInterpolator(DecelerateInterpolator()).withEndAction { removeNow() }.start()
            }
        }, 300)
    }

    private fun shake() {
        val v = root ?: return
        ObjectAnimator.ofFloat(v, "translationX", 0f, dpf(12f), dpf(-10f), dpf(7f), dpf(-3f), 0f).apply {
            duration = 320
            start()
        }
    }

    // ---- cooldown after repeated wrong tries -------------------------------------------------------
    private fun startCooldown() {
        stopTick()
        pad?.inputEnabled = false
        pat?.inputEnabled = false
        val r = object : Runnable {
            override fun run() {
                val left = LockStore.cooldownLeft(s)
                if (left <= 0L) {
                    pad?.inputEnabled = true
                    pat?.inputEnabled = true
                    say(hint())
                    tick = null
                    return
                }
                say("Too many tries · wait ${(left / 1000) + 1}s", DANGER)
                h.postDelayed(this, 450)
            }
        }
        tick = r
        h.post(r)
    }

    private fun stopTick() {
        tick?.let { h.removeCallbacks(it) }
        tick = null
    }

    // ---- leaving -----------------------------------------------------------------------------------
    private fun closeApp() {
        stopTick()
        if (demo) { removeNow(); return }
        // leave the locked app, then make sure it really closed
        try { s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) } catch (_: Exception) {}
        h.postDelayed({
            try { s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) } catch (_: Exception) {}
            h.postDelayed({ removeNow(); cur = ""; unlocked = "" }, 260)
        }, 280)
    }

    private fun onLink() {
        when (stage) {
            ST_SET_PIN, ST_CONFIRM_PIN -> {
                buf = ""; firstPin = ""
                stage = ST_SET_PAT
                applyMode(); pat?.reset()
            }
            ST_SET_PAT, ST_CONFIRM_PAT -> {
                firstPat = ""
                stage = ST_SET_PIN
                applyMode(); paintDots()
            }
        }
    }

    // ---- fingerprint / face ------------------------------------------------------------------------
    private fun bio() {
        if (!bioReady() || LockStore.locked(s) || stage != ST_UNLOCK) return
        busyBio = true
        val face = !LockBio.hasFingerprint(s) && LockBio.hasFace(s)
        val keepDemo = demo
        val who = cur
        removeNow()   // step aside: the system sheet needs to be visible, and the app behind must not be
        LockBioActivity.launch(s, nameFor(who), face) { ok ->
            h.post {
                busyBio = false
                if (ok) {
                    LockStore.clearFails(s)
                    unlocked = who
                    unlockedAt = System.currentTimeMillis()
                    removeNow()
                } else {
                    show(who, keepDemo, false)
                }
            }
        }
    }
}
