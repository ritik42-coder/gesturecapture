package com.raja.gesturecapture

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

// One nav-bar glyph in the Samsung style, drawn with strokes so it stays sharp at any size:
// recents = three bars, home = a rounded pill, back = a chevron. The island handles touches itself
// (so a swipe can start on any button), this view only draws.
class SamIcon(c: Context, private val kind: String) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = Color.WHITE
    }
    private val path = Path()
    private val box = RectF()

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f; val cy = h / 2f; val u = minOf(w, h)
        p.strokeWidth = maxOf(u * .075f, 2f)
        when (kind) {
            "recents" -> {
                val g = u * .19f; val half = u * .2f
                for (i in -1..1) cv.drawLine(cx + i * g, cy - half, cx + i * g, cy + half, p)
            }
            "home" -> {
                val r = u * .2f
                box.set(cx - r, cy - r, cx + r, cy + r)
                cv.drawRoundRect(box, r, r, p)
            }
            else -> {
                path.reset()
                path.moveTo(cx + u * .1f, cy - u * .21f)
                path.lineTo(cx - u * .11f, cy)
                path.lineTo(cx + u * .1f, cy + u * .21f)
                cv.drawPath(path, p)
            }
        }
    }
}
