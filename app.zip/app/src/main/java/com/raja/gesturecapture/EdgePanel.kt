package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------------
// Edge panel, rebuilt to feel like the One UI edge panel.
//
// A slim handle sits flush on the screen edge. Pull it and the panel follows your finger exactly, so
// the swipe never feels like a button press. Inside there are panels you swipe through one by one -
// Apps, Clipboard, Quick actions, Controls, Tools, Draw - and the dots at the bottom stretch into a
// pill under the panel you are on and follow your finger while you swipe.
//
// The Clipboard panel holds everything you copy, text and images. Tap an item to copy it and paste it
// straight into the field you were typing in; hold an item and it pops out of the list as a floating
// card you can drag - drop it on Copy, Share, Pin or Delete, or drag it out of the panel and it is
// pasted into the app behind.
//
// Everything is drawn in the panel's own palette, so light and dark both look finished, and the
// accent colour you pick in settings runs through the whole panel.
// ---------------------------------------------------------------------------------------------------
class EdgePanel(private val s: GestureService, private val wm: WindowManager) : SensorEventListener {

    private val h = Handler(Looper.getMainLooper())
    private var grip: GripView? = null
    private var root: FrameLayout? = null
    private var scrim: View? = null
    private var card: FrameLayout? = null
    private var pager: Pager? = null
    private var row: LinearLayout? = null
    private var dotsView: DotsView? = null
    private var index = 0
    private var pageW = 0
    private var cardW = 0
    private var pages: List<String> = listOf("apps")
    private var built = false
    private var signature = ""
    private var isOpen = false
    private var busy = false
    private var compass: CompassView? = null
    private var sensReg = false
    private var tick: Runnable? = null
    private var timeTv: TextView? = null
    private var batTv: TextView? = null
    private var lockPager = false
    private var pageLabel: TextView? = null
    private var headerTitle: TextView? = null
    private var headerDot: View? = null
    private val devViews = HashMap<String, TextView>()
    private var th: EdgeTheme = EdgeTheme.of(s, JSONObject())

    // clipboard panel
    private var clipList: LinearLayout? = null
    private var clipScroll: ScrollView? = null
    private var clipEmpty: View? = null
    private var clipCount: TextView? = null
    private var vscroll: ScrollView? = null

    // pop-out drag
    private var dragGhost: View? = null
    private var dragLp: WindowManager.LayoutParams? = null
    private var dragItem: ClipStore.Item? = null
    private var dropBox: View? = null
    private var dropTargets: List<Pair<String, View>> = emptyList()

    private val density get() = s.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()
    private fun dpf(v: Float) = v * density

    private fun cfg(): JSONObject = try { JSONObject(Prefs.sp(s).getString("ep", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun on() = cfg().optBoolean("on", false)
    private fun right() = cfg().optString("side", "right") != "left"
    private fun op() = cfg().optInt("op", 96).coerceIn(40, 100)
    private fun radius() = dp(cfg().optInt("radius", 28))
    private fun dim() = cfg().optInt("dim", 45).coerceIn(0, 90)
    private fun style() = cfg().optString("anim", "spring")
    private fun spd() = when (cfg().optString("speed", "normal")) { "fast" -> 0.72f; "slow" -> 1.45f; else -> 1f }
    private fun autopaste() = cfg().optBoolean("autopaste", true)
    private fun buzz(ms: Long = 26) { try { s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(ms, 255)) } catch (_: Exception) {} }

    private fun lp(w: Int, ht: Int, f: Int = 0) = WindowManager.LayoutParams(
        w, ht, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or f,
        PixelFormat.TRANSLUCENT
    )

    // the colours the app icons sit on, so the grid is colourful in both themes
    private val tilePalette = arrayOf(
        0xFF6366F1.toInt() to 0xFF8B5CF6.toInt(),
        0xFF0EA5E9.toInt() to 0xFF2563EB.toInt(),
        0xFFF59E0B.toInt() to 0xFFEF4444.toInt(),
        0xFF10B981.toInt() to 0xFF059669.toInt(),
        0xFFEC4899.toInt() to 0xFFDB2777.toInt(),
        0xFF14B8A6.toInt() to 0xFF0891B2.toInt(),
        0xFFF97316.toInt() to 0xFFF59E0B.toInt(),
        0xFF8B5CF6.toInt() to 0xFF6366F1.toInt()
    )

    private val quick = listOf(
        Triple("torch", R.drawable.ic_flash, "Torch"),
        Triple("shot", R.drawable.ic_cam, "Screenshot"),
        Triple("timer", R.drawable.ic_timer, "Timer"),
        Triple("lock", R.drawable.ic_lock, "Lock"),
        Triple("home", R.drawable.ic_home, "Home"),
        Triple("back", R.drawable.ic_back, "Back"),
        Triple("notif", R.drawable.ic_bell, "Alerts"),
        Triple("recents", R.drawable.ic_recents, "Recents"),
        Triple("pad", R.drawable.ic_edit, "Draw"),
        Triple("quick", R.drawable.ic_tune, "Settings")
    )

    // ------------------------------------------------------------------------------------------
    fun sync() {
        h.post {
            ClipStore.start(s)
            ClipStore.onChanged = { h.post { refreshClip() } }
            val c = cfg()
            val sig = c.toString()
            if (!c.optBoolean("on", false)) { hideGrip(); closeNow(); signature = ""; return@post }
            if (sig != signature) {
                signature = sig
                hideGrip(); closeNow()
                built = false; card = null
                th = EdgeTheme.of(s, c)
            }
            showGrip()
        }
    }

    fun destroy() { h.post { hideGrip(); closeNow() } }

    // ------------------------------------------------------------------------------------------
    // handle on the edge of the screen
    // ------------------------------------------------------------------------------------------
    private fun showGrip() {
        if (grip != null) return
        val len = dp(cfg().optInt("len", 168))
        val inset = dp(cfg().optInt("inset", 0).coerceIn(0, 24))
        val g = GripView(s)
        g.len = len
        g.alpha = 0.78f

        // pull it inwards: the panel follows your finger. Slide it up or down: the Draw panel comes
        // out. Hold it: the full-screen draw pad. Tap it: the panel opens.
        var sx = 0f; var sy = 0f; var axis = 0; var pulled = false; var held = false
        val holdR = Runnable { if (axis == 0) { held = true; buzz(38); openPad() } }
        g.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.rawX; sy = ev.rawY; axis = 0; pulled = false; held = false
                    v.animate().cancel(); v.animate().alpha(1f).setDuration(120).start()
                    attachWindow()
                    h.removeCallbacks(holdR); h.postDelayed(holdR, 520)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - sx; val dy = ev.rawY - sy
                    val inward = if (right()) -dx else dx
                    if (axis == 0) {
                        if (abs(dy) > dp(9) && abs(dy) > abs(dx) * 1.25f) axis = 2
                        else if (abs(inward) > dp(7)) axis = 1
                        if (axis != 0) h.removeCallbacks(holdR)
                    }
                    if (axis == 1) { pulled = true; follow(inward) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(holdR)
                    v.animate().alpha(0.78f).setDuration(220).start()
                    when {
                        held -> {}
                        axis == 2 -> { buzz(40); openDraw() }
                        pulled -> settle()
                        else -> { buzz(); settleOpen() }
                    }
                }
            }
            true
        }
        val p = lp(dp(26), len + dp(20))
        p.gravity = (if (right()) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        p.x = inset
        p.y = dp(cfg().optInt("gy", 0))
        try { wm.addView(g, p) } catch (_: Exception) { return }
        grip = g
    }

    private fun hideGrip() {
        grip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        grip = null
    }

    // the handle: a rounded sliver of the accent colour with a soft halo, like One UI's edge handle
    private inner class GripView(c: Context) : View(c) {
        var len = 0
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val g = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat(); val hgt = height.toFloat()
            if (w <= 0f || hgt <= 0f || len <= 0) return
            val t = th
            val cw = dp(7).toFloat()
            val x = if (right()) w - cw else 0f
            rect.set(x, (hgt - len) / 2f, x + cw, (hgt + len) / 2f)
            val rad = cw / 2f
            // halo
            g.shader = RadialGradient(rect.centerX(), rect.centerY(), len * 0.60f,
                EdgeTheme.alpha(t.a1, 88), EdgeTheme.alpha(t.a1, 0), Shader.TileMode.CLAMP)
            cv.drawCircle(rect.centerX(), rect.centerY(), len * 0.60f, g)
            g.shader = null
            // body
            p.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                t.handleA, t.handleB, Shader.TileMode.CLAMP)
            cv.drawRoundRect(rect, rad, rad, p)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = dpf(1f)
            p.color = t.handleLine
            cv.drawRoundRect(rect, rad, rad, p)
            // three dots, so it reads as a handle and not a bar
            p.style = Paint.Style.FILL
            p.color = 0xCCFFFFFF.toInt()
            for (i in -1..1) cv.drawCircle(rect.centerX(), rect.centerY() + i * dpf(9f), dpf(1.15f), p)
        }
    }

    private fun openPad() {
        closeNow()
        h.postDelayed({ try { s.openPad() } catch (_: Exception) {} }, 120)
    }

    // slide the handle along the edge: the Draw panel comes out, ready to draw on
    fun openDraw() {
        h.post {
            if (!on()) return@post
            val ps = pageList()
            val i = ps.indexOf("draw")
            if (i < 0) { openPad(); return@post }
            if (root == null) attachWindow()
            settleOpen()
            goPage(i)
        }
    }

    fun openPage(k: String) {
        h.post {
            if (!on()) return@post
            val i = pageList().indexOf(k)
            if (root == null) attachWindow()
            settleOpen()
            if (i >= 0) goPage(i)
        }
    }

    // ------------------------------------------------------------------------------------------
    // the card
    // ------------------------------------------------------------------------------------------
    private fun buildCard(): FrameLayout {
        val dm = s.resources.displayMetrics
        cardW = min(dp(cfg().optInt("w", 320)), (dm.widthPixels * 0.88).toInt())
        val sidePad = dp(14)
        pageW = cardW - sidePad * 2
        pages = pageList()
        th = EdgeTheme.of(s, cfg())

        val f = FrameLayout(s)
        f.clipChildren = true
        f.elevation = dpf(16f)
        f.addView(PanelBg(s), FrameLayout.LayoutParams(-1, -1))
        f.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                val r = radius().toFloat()
                val path = Path()
                if (right()) path.addRoundRect(0f, 0f, v.width.toFloat(), v.height.toFloat(),
                    floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f), Path.Direction.CW)
                else path.addRoundRect(0f, 0f, v.width.toFloat(), v.height.toFloat(),
                    floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r), Path.Direction.CW)
                try { o.setConvexPath(path) } catch (_: Exception) {}
                o.alpha = 1f
            }
        }
        f.clipToOutline = true

        val col = LinearLayout(s)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(sidePad, dp(12), sidePad, dp(8))
        f.addView(col, FrameLayout.LayoutParams(-1, -1))

        col.addView(buildHeader(), LinearLayout.LayoutParams(-1, dp(40)))

        val pg = Pager(s)
        val rw = LinearLayout(s)
        rw.orientation = LinearLayout.HORIZONTAL
        row = rw
        pg.addView(rw, FrameLayout.LayoutParams(pageW * pages.size, -1))
        for (k in pages) rw.addView(pageFor(k), LinearLayout.LayoutParams(pageW, -1))
        pg.setOnScrollChangeListener { _, _, _, _, _ -> onScroll() }
        pager = pg
        col.addView(pg, LinearLayout.LayoutParams(-1, 0, 1f))

        val foot = LinearLayout(s)
        foot.orientation = LinearLayout.VERTICAL
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, dp(4), 0, dp(2))
        val pl = TextView(s)
        pl.textSize = 8.5f
        pl.setTextColor(th.faint)
        pl.gravity = Gravity.CENTER
        pl.letterSpacing = 0.14f
        pl.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        pageLabel = pl
        foot.addView(pl, LinearLayout.LayoutParams(-1, -2))
        val dv = DotsView(s)
        dv.count = pages.size
        dotsView = dv
        foot.addView(dv, LinearLayout.LayoutParams(-1, dp(20)))
        col.addView(foot, LinearLayout.LayoutParams(-1, -2))

        applyIndex(false)
        updateHeader()
        return f
    }

    // the panel background: accent gradient, a wash of colour at the top and a hairline edge
    private inner class PanelBg(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(cv: Canvas) {
            val t = th
            val w = width.toFloat(); val hgt = height.toFloat()
            if (w <= 0f || hgt <= 0f) return
            val r = radius().toFloat()
            val path = Path()
            if (right()) path.addRoundRect(0f, 0f, w, hgt, floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f), Path.Direction.CW)
            else path.addRoundRect(0f, 0f, w, hgt, floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r), Path.Direction.CW)

            p.style = Paint.Style.FILL
            p.alpha = op() * 255 / 100
            p.shader = LinearGradient(0f, 0f, w * 0.35f, hgt, t.cardTop, t.cardBottom, Shader.TileMode.CLAMP)
            cv.drawPath(path, p)

            // a soft glow of the accent colour across the top, so the card is never flat
            p.shader = RadialGradient(w * 0.45f, -hgt * 0.06f, hgt * 0.62f,
                EdgeTheme.alpha(t.a1, if (t.dark) 62 else 30), EdgeTheme.alpha(t.a1, 0),
                Shader.TileMode.CLAMP)
            cv.drawPath(path, p)
            p.shader = null
            p.alpha = 255

            p.style = Paint.Style.STROKE
            p.strokeWidth = dpf(1f)
            p.color = if (t.dark) 0x2EFFFFFF else 0x14000000
            cv.drawPath(path, p)
            p.style = Paint.Style.FILL
        }
    }

    private fun buildHeader(): LinearLayout {
        val head = LinearLayout(s)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(2), 0, 0, 0)
        val dot = View(s)
        dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(th.a1) }
        headerDot = dot
        head.addView(dot, LinearLayout.LayoutParams(dp(6), dp(6)).apply { rightMargin = dp(8) })
        val ttl = TextView(s)
        ttl.text = "Apps"
        ttl.textSize = 12.5f
        ttl.setTextColor(th.text)
        ttl.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        headerTitle = ttl
        head.addView(ttl, LinearLayout.LayoutParams(0, -2, 1f))

        val set = TextView(s)
        set.text = "⚙"
        set.textSize = 13f
        set.gravity = Gravity.CENTER
        set.setTextColor(th.sub)
        set.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(th.tile) }
        set.setOnClickListener { buzz(); openApp("4") }
        head.addView(set, LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(7) })

        val close = TextView(s)
        close.text = "✕"
        close.textSize = 12f
        close.gravity = Gravity.CENTER
        close.setTextColor(th.sub)
        close.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(th.tile) }
        close.setOnClickListener { closeAnimated() }
        head.addView(close, LinearLayout.LayoutParams(dp(28), dp(28)))
        return head
    }

    // the dots: the one you are on stretches into a pill, and the whole row slides with your finger
    private inner class DotsView(c: Context) : View(c) {
        var count = 0
        var pos = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        override fun onDraw(cv: Canvas) {
            val t = th
            if (count <= 0 || width <= 0) return
            val base = dpf(5.5f)
            val gap = dpf(6f)
            var total = 0f
            val widths = FloatArray(count)
            for (i in 0 until count) {
                val near = (1f - abs(i - pos)).coerceIn(0f, 1f)
                widths[i] = base + dpf(13f) * near
                total += widths[i]
            }
            total += gap * (count - 1)
            var x = (width - total) / 2f
            val cy = height / 2f
            for (i in 0 until count) {
                val near = (1f - abs(i - pos)).coerceIn(0f, 1f)
                val w = widths[i]
                r.set(x, cy - base / 2f, x + w, cy + base / 2f)
                if (near > 0.05f) {
                    val acc = EdgeTheme.accentFor(pages.getOrElse(i) { "apps" }, t.a1, t.a2)
                    p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, acc.first, acc.second, Shader.TileMode.CLAMP)
                    p.alpha = (60 + 195 * near).toInt().coerceIn(0, 255)
                } else {
                    p.shader = null
                    p.color = if (t.dark) 0x59FFFFFF else 0x38000000
                    p.alpha = 255
                }
                cv.drawRoundRect(r, base / 2f, base / 2f, p)
                x += w + gap
            }
            p.shader = null
            p.alpha = 255
        }
    }

    private fun attachWindow() {
        if (root != null) return
        th = EdgeTheme.of(s, cfg())
        if (!built) { card = buildCard(); built = true }
        val c = card ?: return
        val full = FrameLayout(s)
        val sc = View(s)
        sc.setBackgroundColor(th.scrim)
        sc.alpha = 0f
        sc.setOnClickListener { closeAnimated() }
        full.addView(sc, FrameLayout.LayoutParams(-1, -1))
        if (c.parent != null) (c.parent as ViewGroup).removeView(c)
        val cp = FrameLayout.LayoutParams(cardW, -1)
        cp.gravity = if (right()) Gravity.END else Gravity.START
        full.addView(c, cp)
        val p = lp(-1, -1, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val b = cfg().optInt("blur", 0)
                if (b > 0) {
                    p.flags = p.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                    p.blurBehindRadius = dp(b)
                }
            } catch (_: Exception) {}
        }
        try { wm.addView(full, p) } catch (_: Exception) { return }
        root = full
        scrim = sc
        c.translationX = if (right()) cardW.toFloat() else -cardW.toFloat()
        c.scaleX = 0.94f; c.scaleY = 0.94f; c.alpha = 0f
        index = 0
        applyIndex(false)
        updateHeader()
        startTick(); registerCompass()
        refreshClip()
    }

    // follow the finger while the handle is dragged, so the panel is stuck to your thumb
    private fun follow(inward: Float) {
        val c = card ?: return
        if (isOpen) return
        val w = cardW.toFloat()
        val prog = (inward / w).coerceIn(0f, 1f)
        c.translationX = (if (right()) 1f else -1f) * w * (1f - prog)
        c.scaleX = 0.94f + 0.06f * prog
        c.scaleY = c.scaleX
        c.alpha = 0.30f + 0.70f * prog
        scrim?.alpha = prog * dim() / 100f
    }

    private fun settle() {
        val c = card ?: return
        val w = cardW.toFloat()
        val prog = 1f - abs(c.translationX) / w
        if (prog > 0.30f) settleOpen() else settleClose()
    }

    private fun settleOpen() {
        val c = card ?: return
        if (isOpen) return
        isOpen = true; busy = true
        val dur = (300 * spd()).toLong().coerceIn(140, 640)
        val itp: android.animation.TimeInterpolator = when (style()) {
            "spring" -> PathInterpolator(0.16f, 1f, 0.30f, 1f)
            "elastic" -> OvershootInterpolator(1.7f)
            "fade" -> DecelerateInterpolator()
            "cover" -> DecelerateInterpolator()
            else -> PathInterpolator(0.20f, 0f, 0f, 1f)
        }
        val fromX = c.translationX
        val fromS = c.scaleX
        val fromA = c.alpha
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur
            interpolator = itp
            addUpdateListener { a ->
                val f = (a.animatedValue as Float).coerceIn(0f, 1.15f)
                c.translationX = fromX * (1f - f)
                c.scaleX = fromS + (1f - fromS) * f
                c.scaleY = c.scaleX
                c.alpha = (fromA + (1f - fromA) * f).coerceIn(0f, 1f)
                scrim?.alpha = (dim() / 100f) * f.coerceIn(0f, 1f)
            }
            start()
        }
        h.postDelayed({ busy = false }, dur + 40)
        grip?.animate()?.alpha(0f)?.setDuration(140)?.start()
        // read the clipboard once the panel is actually open, not while the finger is still down
        h.postDelayed({ if (isOpen) peekClipboard() }, 120)
        if (pages.size > 1 && !Prefs.sp(s).getBoolean("ep_hint", false)) {
            pageLabel?.text = "swipe  ‹  ›   for more panels"
            h.postDelayed({ Prefs.sp(s).edit().putBoolean("ep_hint", true).apply(); updateHeader() }, 2800)
        }
    }

    private fun settleClose() {
        val c = card ?: return
        if (!isOpen) { detach(); return }
        isOpen = false
        val dur = (220 * spd()).toLong().coerceIn(110, 460)
        val target = if (right()) cardW.toFloat() else -cardW.toFloat()
        c.animate().translationX(target).scaleX(0.96f).scaleY(0.96f).alpha(0f)
            .setDuration(dur).setInterpolator(PathInterpolator(0.4f, 0f, 1f, 1f))
            .withEndAction { detach() }.start()
        scrim?.animate()?.alpha(0f)?.setDuration(dur)?.start()
    }

    fun open() { h.post { if (root == null) { attachWindow(); settleOpen() } } }
    fun close() { h.post { closeAnimated() } }

    private fun closeAnimated() {
        if (root == null) return
        settleClose()
    }

    private fun closeNow() { detach() }

    private fun detach() {
        hideDrag()
        stopTick(); unregisterCompass()
        if (card?.parent != null) (card!!.parent as ViewGroup).removeView(card)
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; scrim = null; isOpen = false; busy = false
        card?.let {
            it.translationX = 0f; it.alpha = 1f
            it.scaleX = 1f; it.scaleY = 1f
        }
        index = 0
        try { pager?.scrollTo(0, 0) } catch (_: Exception) {}
        grip?.animate()?.alpha(0.78f)?.setDuration(160)?.start()
    }

    // ------------------------------------------------------------------------------------------
    // paging
    // ------------------------------------------------------------------------------------------
    private fun onScroll() {
        val w = pageW.coerceAtLeast(1)
        val pos = (pager?.scrollX ?: 0).toFloat() / w
        dotsView?.pos = pos
        dotsView?.invalidate()
        // a little depth: the page leaving slides a touch slower than the one arriving
        row?.let { rw ->
            for (i in 0 until rw.childCount) {
                val v = rw.getChildAt(i)
                val dist = abs(i - pos).coerceAtMost(1f)
                val dir = if (i < pos) 1f else -1f
                v.translationX = dir * dpf(14f) * dist * (if (right()) 1f else -1f)
                v.alpha = 1f - 0.45f * dist
            }
        }
        val n = pos.roundToInt().coerceIn(0, (pages.size - 1).coerceAtLeast(0))
        if (n != index) {
            index = n
            updateHeader()
            buzz(12)
            if (pages.getOrElse(n) { "" } == "clip") peekClipboard()
        }
        pageLabel?.text = if (pages.size > 1) pageTitle(pages.getOrElse(n) { "apps" }) + "  ·  " + (n + 1) + "/" + pages.size
        else pageTitle(pages.getOrElse(0) { "apps" })
    }

    private fun applyIndex(animate: Boolean) {
        val pg = pager ?: return
        val x = (index * pageW).coerceAtLeast(0)
        if (!animate) { pg.scrollTo(x, 0); onScroll(); return }
        val from = pg.scrollX
        if (from == x) { onScroll(); return }
        ValueAnimator.ofInt(from, x).apply {
            duration = (320 * spd()).toLong().coerceIn(130, 700)
            interpolator = PathInterpolator(0.16f, 1f, 0.30f, 1f)
            addUpdateListener { a -> pg.scrollTo(a.animatedValue as Int, 0) }
            start()
        }
    }

    private fun goPage(to: Int) {
        if (pages.isEmpty()) return
        val n = to.coerceIn(0, pages.size - 1)
        val changed = n != index
        index = n
        applyIndex(true)
        updateHeader()
        if (changed) buzz(14)
    }

    private fun pageTitle(k: String) = when (k) {
        "apps" -> "Apps"
        "clip" -> "Clipboard"
        "actions" -> "Quick actions"
        "controls" -> "Controls"
        "draw" -> "Draw"
        "device" -> "Device"
        "timer" -> "Timer"
        "compass" -> "Compass"
        else -> "Tools"
    }

    private fun updateHeader() {
        val k = pages.getOrElse(index) { "apps" }
        headerTitle?.text = pageTitle(k)
        val acc = EdgeTheme.accentFor(k, th.a1, th.a2)
        val bg = headerDot?.background
        if (bg is GradientDrawable) bg.setColor(acc.first)
    }

    // Swipe through the panels with momentum and a snap; swipe down to close. The scroll is handled
    // in dispatchTouchEvent so it works whichever child the finger lands on.
    private inner class Pager(c: Context) : HorizontalScrollView(c) {
        private var downX = 0f; private var downY = 0f
        private var vt: VelocityTracker? = null
        private var vertical = false
        private var tracking = false
        private var startScroll = 0

        init {
            isHorizontalScrollBarEnabled = false
            overScrollMode = OVER_SCROLL_NEVER
            isFillViewport = false
            clipChildren = true
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (lockPager) return super.dispatchTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; vertical = false; tracking = true
                    startScroll = scrollX
                    vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(ev)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!tracking) return super.dispatchTouchEvent(ev)
                    vt?.addMovement(ev)
                    val dx = ev.x - downX; val dy = ev.y - downY
                    if (!vertical && abs(dy) > dp(22) && abs(dy) > abs(dx) * 1.15f) {
                        vertical = true
                        if (!inVScroll(ev)) {
                            val cancel = MotionEvent.obtain(ev)
                            cancel.action = MotionEvent.ACTION_CANCEL
                            super.dispatchTouchEvent(cancel)
                            cancel.recycle()
                        }
                    }
                    if (vertical && !inVScroll(ev)) return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!tracking) return super.dispatchTouchEvent(ev)
                    tracking = false
                    vt?.addMovement(ev); vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    vt?.recycle(); vt = null
                    if (vertical) {
                        if (inVScroll(ev)) return super.dispatchTouchEvent(ev)
                        if (ev.y - downY > dp(60)) closeAnimated()
                        return true
                    }
                    if (abs(scrollX - startScroll) > dp(3)) {
                        val handled = super.dispatchTouchEvent(ev)
                        snapTo(vx)
                        return handled
                    }
                    return super.dispatchTouchEvent(ev)
                }
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    // is this touch inside the scrolling list (the clipboard), where up and down means scroll?
    private fun inVScroll(ev: MotionEvent): Boolean {
        val sv = vscroll ?: return false
        if (sv.visibility != View.VISIBLE) return false
        val r = Rect()
        if (!sv.getGlobalVisibleRect(r)) return false
        return r.contains(ev.rawX.toInt(), ev.rawY.toInt())
    }

    private fun snapTo(vx: Float) {
        val w = pageW.coerceAtLeast(1)
        val cur = (pager?.scrollX ?: 0).toFloat() / w
        var page = cur.roundToInt()
        if (vx < -700f) page = ceil(cur).toInt()
        else if (vx > 700f) page = floor(cur).toInt()
        goPage(page)
    }

    // ------------------------------------------------------------------------------------------
    // which panels are shown
    // ------------------------------------------------------------------------------------------
    private fun pageList(): List<String> {
        val known = setOf("apps", "clip", "actions", "compass", "tools", "controls", "device", "timer", "draw")
        val fallback = listOf("apps", "clip", "actions", "controls", "tools", "draw")
        val raw = cfg().optString("pages", fallback.joinToString(","))
        var ps = raw.split(",").map { it.trim() }.filter { it in known }.distinct()
        val sp = Prefs.sp(s)
        // one-time repair: the Clipboard panel is new, so it is added for anyone who has not chosen
        // their panels since. After this, your own choice is left exactly as you set it.
        if (!sp.getBoolean("ep_pages_v3", false)) {
            if (ps.isEmpty()) ps = fallback
            if (ps.none { it == "clip" }) {
                val out = ArrayList(ps)
                val at = if (out.contains("apps")) out.indexOf("apps") + 1 else 0
                out.add(at, "clip")
                ps = out
            }
            try {
                val c = cfg()
                c.put("pages", ps.joinToString(","))
                sp.edit().putString("ep", c.toString()).apply()
            } catch (_: Exception) {}
            sp.edit().putBoolean("ep_pages_v3", true).apply()
        }
        if (ps.isEmpty()) ps = fallback
        return ps
    }

    private fun pageFor(k: String): View = when (k) {
        "apps" -> pageApps()
        "clip" -> pageClip()
        "actions" -> pageActions()
        "compass" -> pageCompass()
        "draw" -> pageDraw()
        "controls" -> pageControls()
        "device" -> pageDevice()
        "timer" -> pageTimer()
        else -> pageTools()
    }

    // ------------------------------------------------------------------------------------------
    // small pieces every page uses
    // ------------------------------------------------------------------------------------------
    private fun pageBox(): LinearLayout = LinearLayout(s).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(1), dp(4), dp(1), dp(2))
    }

    private fun title(t: String): TextView = TextView(s).apply {
        text = t
        textSize = 9f
        setTextColor(th.faint)
        letterSpacing = 0.18f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(2), 0, 0, dp(8))
    }

    private fun chip(label: String, bg: Int, fg: Int): TextView = TextView(s).apply {
        text = label
        textSize = 10f
        gravity = Gravity.CENTER
        setTextColor(fg)
        background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(bg) }
        setPadding(dp(10), 0, dp(10), 0)
    }

    // ------------------------------------------------------------------------------------------
    // Apps: the shortcut strip you reach for first, then your apps
    // ------------------------------------------------------------------------------------------
    private fun pageApps(): View {
        val box = pageBox()
        box.addView(quickStrip(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val head = LinearLayout(s)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(title("APPS"), LinearLayout.LayoutParams(0, -2, 1f))
        val edit = TextView(s)
        edit.text = "Edit"
        edit.textSize = 9.5f
        edit.setTextColor(th.a1)
        edit.setPadding(dp(6), 0, dp(4), dp(8))
        edit.setOnClickListener { openApp("4") }
        head.addView(edit)
        box.addView(head)

        val apps = cfg().optJSONArray("apps") ?: JSONArray()
        val list = ArrayList<Pair<String, String>>()
        for (i in 0 until apps.length()) {
            val o = apps.optJSONObject(i) ?: continue
            val pk = o.optString("p", "")
            if (pk.isEmpty()) continue
            val nm = o.optString("n", "").ifBlank {
                try { s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pk, 0)).toString() } catch (_: Exception) { pk }
            }
            list.add(Pair(pk, nm))
        }

        val grid = LinearLayout(s)
        grid.orientation = LinearLayout.VERTICAL
        val cellW = pageW / 4
        var rl: LinearLayout? = null
        for (i in 0 until 8) {
            if (i % 4 == 0) {
                val r = LinearLayout(s)
                r.gravity = Gravity.CENTER
                grid.addView(r, LinearLayout.LayoutParams(-1, -2))
                rl = r
            }
            val cell = if (i < list.size) appCell(list[i].first, list[i].second, i, cellW)
            else if (i == list.size) appCell(null, null, i, cellW)
            else emptyCell()
            rl?.addView(cell, LinearLayout.LayoutParams(cellW, -2))
        }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2))

        val hint = TextView(s)
        hint.text = if (list.isEmpty()) "Add your apps in the Edge tab" else "Tap to open  ·  hold for app info"
        hint.textSize = 9.5f
        hint.setTextColor(th.faint)
        hint.setPadding(dp(2), dp(8), dp(2), 0)
        box.addView(hint)
        return box
    }

    // four colourful shortcuts at the top of the Apps panel
    private fun quickStrip(): View {
        val strip = LinearLayout(s)
        strip.gravity = Gravity.CENTER
        val items = listOf(
            Triple("call", R.drawable.ic_call, 0xFF6366F1.toInt() to 0xFF8B5CF6.toInt()),
            Triple("camera", R.drawable.ic_cam, 0xFFF59E0B.toInt() to 0xFFEF4444.toInt()),
            Triple("torch", R.drawable.ic_flash, 0xFF14B8A6.toInt() to 0xFF0EA5E9.toInt()),
            Triple("shot", R.drawable.ic_shot, 0xFFEC4899.toInt() to 0xFF8B5CF6.toInt())
        )
        for ((key, icon, pair) in items) {
            val tile = LinearLayout(s)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER
            tile.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pair.first, pair.second)).apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0x26FFFFFF)
            }
            tile.elevation = dpf(2f)
            val iv = ImageView(s)
            try { iv.setImageDrawable(s.getDrawable(icon)) } catch (_: Exception) {}
            iv.setColorFilter(Color.WHITE)
            tile.addView(iv, LinearLayout.LayoutParams(dp(18), dp(18)).apply { topMargin = dp(9) })
            val lb = TextView(s)
            lb.text = when (key) {
                "call" -> "Call"; "camera" -> "Camera"; "torch" -> "Torch"; else -> "Shot"
            }
            lb.textSize = 8.5f
            lb.setTextColor(0xE6FFFFFF.toInt())
            lb.gravity = Gravity.CENTER
            lb.setPadding(0, dp(3), 0, dp(8))
            tile.addView(lb)
            tile.setOnClickListener {
                buzz()
                when (key) {
                    "call" -> dial()
                    "camera" -> { s.doAct("camera", "edge"); closeAnimated() }
                    "torch" -> s.doAct("torch", "edge")
                    else -> { s.doAct("shot", "edge"); closeAnimated() }
                }
            }
            if (key == "call") {
                tile.setOnLongClickListener { contacts(); true }
            }
            strip.addView(tile, LinearLayout.LayoutParams(0, dp(58), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        return strip
    }

    private fun appCell(pk: String?, name: String?, i: Int, cellW: Int): View {
        val cell = LinearLayout(s)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(0, dp(4), 0, dp(8))
        val pair = tilePalette[i % tilePalette.size]
        val holder = FrameLayout(s)
        holder.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pair.first, pair.second)).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(1), 0x33FFFFFF)
        }
        holder.elevation = dpf(2f)
        if (pk != null) {
            val iv = ImageView(s)
            try { iv.setImageDrawable(s.packageManager.getApplicationIcon(pk)) } catch (_: Exception) {}
            holder.addView(iv, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        } else {
            val plus = TextView(s)
            plus.text = "＋"
            plus.textSize = 20f
            plus.gravity = Gravity.CENTER
            plus.setTextColor(Color.WHITE)
            holder.addView(plus, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        cell.addView(holder, LinearLayout.LayoutParams(dp(50), dp(50)))
        val lb = TextView(s)
        lb.text = name ?: "Add"
        lb.textSize = 9.5f
        lb.maxLines = 2
        lb.ellipsize = TextUtils.TruncateAt.END
        lb.gravity = Gravity.CENTER
        lb.setTextColor(if (name == null) th.faint else EdgeTheme.alpha(th.text, 235))
        lb.setPadding(dp(2), dp(6), dp(2), 0)
        cell.addView(lb, LinearLayout.LayoutParams(cellW - dp(2), -2))
        cell.setOnClickListener {
            buzz()
            if (pk == null) { openApp("4"); return@setOnClickListener }
            try {
                s.packageManager.getLaunchIntentForPackage(pk)?.let { s.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            } catch (_: Exception) {}
            closeAnimated()
        }
        return cell
    }

    private fun emptyCell(): View = View(s)

    private fun dial() {
        buzz()
        try { s.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        closeAnimated()
    }

    private fun contacts() {
        buzz()
        try {
            s.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
        closeAnimated()
    }

    // ------------------------------------------------------------------------------------------
    // Clipboard: text and images, hold an item to pop it out and drag it
    // ------------------------------------------------------------------------------------------
    private fun pageClip(): View {
        val box = pageBox()

        val head = LinearLayout(s)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(title("CLIPBOARD"), LinearLayout.LayoutParams(0, -2, 1f))
        val cnt = TextView(s)
        cnt.textSize = 9f
        cnt.setTextColor(th.faint)
        cnt.setPadding(0, 0, dp(8), dp(8))
        clipCount = cnt
        head.addView(cnt)
        val clear = TextView(s)
        clear.text = "Clear"
        clear.textSize = 9.5f
        clear.setTextColor(0xFFEF4444.toInt())
        clear.setPadding(dp(4), 0, dp(2), dp(8))
        clear.setOnClickListener {
            buzz(30)
            ClipStore.clearAll()
            refreshClip()
        }
        head.addView(clear)
        box.addView(head)

        val sv = ScrollView(s)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.tag = "vscroll"
        val lst = LinearLayout(s)
        lst.orientation = LinearLayout.VERTICAL
        sv.addView(lst, FrameLayout.LayoutParams(-1, -2))
        clipList = lst
        clipScroll = sv
        vscroll = sv
        box.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val empty = TextView(s)
        empty.text = "Copy a text or an image and it lands here.\n\nHold an item to pop it out, then drag it onto Copy, Share, Pin or Delete - or drag it out of the panel to paste it into the app behind."
        empty.textSize = 10.5f
        empty.setTextColor(th.faint)
        empty.gravity = Gravity.CENTER
        empty.setPadding(dp(8), dp(20), dp(8), dp(10))
        clipEmpty = empty
        box.addView(empty, LinearLayout.LayoutParams(-1, 0, 1f))

        refreshClip()
        return box
    }

    private fun refreshClip() {
        val lst = clipList ?: return
        if (card == null) return
        lst.removeAllViews()
        val items = ClipStore.items()
        clipCount?.text = if (items.isEmpty()) "" else items.size.toString() + " saved"
        clipEmpty?.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        clipScroll?.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        for (item in items.take(24)) {
            lst.addView(clipRow(item), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }
    }

    private fun clipRow(item: ClipStore.Item): View {
        val rowCard = LinearLayout(s)
        rowCard.orientation = if (item.isImage) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        rowCard.gravity = Gravity.CENTER_VERTICAL
        rowCard.setPadding(dp(10), dp(9), dp(10), dp(9))
        rowCard.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(if (th.dark) 0x14FFFFFF else 0x0A0B0B12)
            setStroke(dp(1), if (th.dark) 0x1FFFFFFF else 0x120B0B12)
        }
        if (item.isImage) {
            val iv = ImageView(s)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            ClipStore.thumb(item, 180)?.let { bmp -> iv.setImageBitmap(bmp) }
            iv.background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(th.tile) }
            rowCard.addView(iv, LinearLayout.LayoutParams(dp(52), dp(52)))
            val colm = LinearLayout(s)
            colm.orientation = LinearLayout.VERTICAL
            colm.setPadding(dp(10), 0, 0, 0)
            val t1 = TextView(s)
            t1.text = "Image"
            t1.textSize = 11.5f
            t1.setTextColor(th.text)
            t1.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            colm.addView(t1)
            val t2 = TextView(s)
            t2.text = ClipStore.whenText(item.at) + "  ·  hold to drag"
            t2.textSize = 8.5f
            t2.setTextColor(th.faint)
            t2.setPadding(0, dp(3), 0, 0)
            colm.addView(t2)
            rowCard.addView(colm, LinearLayout.LayoutParams(0, -2, 1f))
        } else {
            val t = TextView(s)
            t.text = item.text
            t.textSize = 11f
            t.maxLines = 3
            t.ellipsize = TextUtils.TruncateAt.END
            t.setTextColor(EdgeTheme.alpha(th.text, 238))
            t.setLineSpacing(dpf(1.5f), 1f)
            rowCard.addView(t)
            val meta = TextView(s)
            meta.text = ClipStore.whenText(item.at) + (if (item.pin) "  ·  pinned" else "")
            meta.textSize = 8.5f
            meta.setTextColor(if (item.pin) th.a1 else th.faint)
            meta.setPadding(0, dp(4), 0, 0)
            rowCard.addView(meta)
        }

        rowCard.setOnClickListener {
            buzz()
            if (ClipStore.copy(item)) {
                if (item.isImage) closeAnimated()
                else if (autopaste()) {
                    closeAnimated()
                    h.postDelayed({ try { s.pasteClipboard() } catch (_: Exception) {} }, 260)
                } else closeAnimated()
            }
        }
        rowCard.setOnLongClickListener { v -> startPop(item, v); true }
        rowCard.setOnTouchListener { _, ev ->
            if (dragItem == null) return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> { moveGhost(ev.rawX, ev.rawY); true }
                MotionEvent.ACTION_UP -> { endPop(ev.rawX, ev.rawY); true }
                MotionEvent.ACTION_CANCEL -> { hideDrag(); true }
                else -> true
            }
        }
        return rowCard
    }

    // ------------------------------------------------------------------------------------------
    // pop out and drag
    // ------------------------------------------------------------------------------------------
    private fun startPop(item: ClipStore.Item, src: View) {
        val r = root ?: return
        if (dragGhost != null) return
        buzz(35)
        dragItem = item
        // the list must not steal the drag as a scroll
        try { clipScroll?.requestDisallowInterceptTouchEvent(true) } catch (_: Exception) {}

        val gw = dp(200)
        val gh = if (item.isImage) dp(120) else dp(76)
        val loc = IntArray(2)
        src.getLocationOnScreen(loc)

        val ghost = FrameLayout(s)
        ghost.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(if (th.dark) 0xF21E1E26.toInt() else 0xF2FFFFFF.toInt())
            setStroke(dp(1), if (th.dark) 0x33FFFFFF else 0x22000000)
        }
        ghost.elevation = dpf(18f)
        ghost.clipToOutline = true
        if (item.isImage) {
            val iv = ImageView(s)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            ClipStore.thumb(item, 320)?.let { bmp -> iv.setImageBitmap(bmp) }
            ghost.addView(iv, FrameLayout.LayoutParams(-1, -1))
        } else {
            val t = TextView(s)
            t.text = item.text
            t.textSize = 11f
            t.maxLines = 3
            t.ellipsize = TextUtils.TruncateAt.END
            t.setTextColor(th.text)
            t.setPadding(dp(12), dp(10), dp(12), dp(10))
            ghost.addView(t, FrameLayout.LayoutParams(-1, -1))
        }
        val p = lp(gw, gh, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = loc[0]
        p.y = loc[1]
        try { wm.addView(ghost, p) } catch (_: Exception) { dragItem = null; return }
        dragGhost = ghost
        dragLp = p
        ghost.scaleX = 0.92f
        ghost.scaleY = 0.92f
        ghost.alpha = 0.96f
        ghost.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        showDropTargets()
        // lift the whole card so it is clear you are dragging something out of it
        card?.animate()?.scaleX(0.99f)?.scaleY(0.99f)?.setDuration(120)?.start()
        try { r.requestDisallowInterceptTouchEvent(true) } catch (_: Exception) {}
    }

    private fun moveGhost(x: Float, y: Float) {
        val p = dragLp ?: return
        val ghost = dragGhost ?: return
        p.x = (x - ghost.width / 2f).toInt()
        p.y = (y - ghost.height / 2f).toInt()
        try { wm.updateViewLayout(ghost, p) } catch (_: Exception) {}
        // light up whichever target is under the finger
        for ((_, v) in dropTargets) {
            val r = Rect()
            v.getGlobalVisibleRect(r)
            val on = r.contains(x.toInt(), y.toInt())
            v.animate().cancel()
            v.animate().scaleX(if (on) 1.08f else 1f).scaleY(if (on) 1.08f else 1f)
                .alpha(if (on) 1f else 0.82f).setDuration(90).start()
        }
    }

    private fun showDropTargets() {
        val c = card ?: return
        val wrap = LinearLayout(s)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setPadding(dp(8), dp(8), dp(8), dp(8))
        wrap.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (th.dark) 0xF2131319.toInt() else 0xF2FFFFFF.toInt())
            setStroke(dp(1), if (th.dark) 0x33FFFFFF else 0x1F000000)
        }
        wrap.elevation = dpf(14f)

        val pinned = dragItem?.pin == true
        val defs = listOf(
            Triple("copy", "⧉  Copy", 0xFF6366F1.toInt()),
            Triple("share", "↗  Share", 0xFF14B8A6.toInt()),
            Triple("pin", if (pinned) "★  Unpin" else "★  Pin", 0xFFF59E0B.toInt()),
            Triple("del", "🗑  Delete", 0xFFEF4444.toInt())
        )
        val chips = ArrayList<Pair<String, View>>()
        var rowq: LinearLayout? = null
        for ((i, d) in defs.withIndex()) {
            if (i % 2 == 0) {
                val rr = LinearLayout(s)
                wrap.addView(rr, LinearLayout.LayoutParams(-1, -2))
                rowq = rr
            }
            val chip = TextView(s)
            chip.text = d.second
            chip.textSize = 9.5f
            chip.gravity = Gravity.CENTER
            chip.setTextColor(Color.WHITE)
            chip.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(d.third, EdgeTheme.darken(d.third, 0.25f))).apply {
                cornerRadius = dp(12).toFloat()
            }
            chip.alpha = 0.82f
            rowq?.addView(chip, LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            chips.add(Pair(d.first, chip))
        }
        dropTargets = chips
        val fl = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fl.bottomMargin = dp(44)
        fl.leftMargin = dp(12)
        fl.rightMargin = dp(12)
        c.addView(wrap, fl)
        dropBox = wrap
        wrap.alpha = 0f
        wrap.translationY = dpf(14f)
        wrap.animate().alpha(1f).translationY(0f).setDuration(160).start()
    }

    private fun endPop(x: Float, y: Float) {
        val item = dragItem ?: return
        val c = card
        val cardRect = Rect()
        c?.getGlobalVisibleRect(cardRect)
        var target: String? = null
        for ((k, v) in dropTargets) {
            val r = Rect()
            if (v.getGlobalVisibleRect(r) && r.contains(x.toInt(), y.toInt())) { target = k; break }
        }
        hideDrag()
        when (target) {
            "copy" -> {
                ClipStore.copy(item); buzz(30)
                closeAnimated()
                if (!item.isImage && autopaste()) h.postDelayed({ try { s.pasteClipboard() } catch (_: Exception) {} }, 300)
            }
            "share" -> { closeAnimated(); h.postDelayed({ shareItem(item) }, 240) }
            "pin" -> { ClipStore.pinToggle(item.id); buzz(24); refreshClip() }
            "del" -> { ClipStore.remove(item.id); buzz(40); refreshClip() }
            else -> {
                if (cardRect.width() > 0 && !cardRect.contains(x.toInt(), y.toInt())) dropIntoApp(item)
                else refreshClip()
            }
        }
    }

    // dropped outside the panel: close it, put the item on the clipboard and paste it into the app
    private fun dropIntoApp(item: ClipStore.Item) {
        closeAnimated()
        h.postDelayed({
            if (item.isImage) shareItem(item)
            else {
                ClipStore.copy(item)
                try { s.pasteClipboard() } catch (_: Exception) {}
            }
        }, 280)
    }

    private fun hideDrag() {
        dropBox?.let { b ->
            val c = card
            if (b.parent != null && b.parent === c) (b.parent as ViewGroup).removeView(b)
        }
        dropBox = null
        dropTargets = emptyList()
        dragGhost?.let { g ->
            try { wm.removeView(g) } catch (_: Exception) {}
        }
        dragGhost = null
        dragLp = null
        dragItem = null
        card?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(120)?.start()
        try { clipScroll?.requestDisallowInterceptTouchEvent(false) } catch (_: Exception) {}
    }

    private fun shareItem(item: ClipStore.Item) {
        val i = ClipStore.share(item) ?: return
        try { s.startActivity(i) } catch (_: Exception) {}
    }

    // Android only lets the focused app read the clipboard, so the panel takes focus for a moment
    // when it opens, reads it, and hands focus straight back.
    private fun peekClipboard() {
        val r = root ?: return
        val p = r.layoutParams as? WindowManager.LayoutParams ?: return
        val wasFocusable = (p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0
        if (!wasFocusable) {
            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            try { wm.updateViewLayout(r, p) } catch (_: Exception) { return }
        }
        h.postDelayed({
            try {
                ClipStore.capture()
                refreshClip()
            } catch (_: Exception) {}
            try {
                val q = r.layoutParams as WindowManager.LayoutParams
                if (!wasFocusable) q.flags = q.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                wm.updateViewLayout(r, q)
            } catch (_: Exception) {}
        }, 300)
    }

    // ------------------------------------------------------------------------------------------
    // Quick actions
    // ------------------------------------------------------------------------------------------
    private fun pageActions(): View {
        val box = pageBox()
        box.addView(title("QUICK ACTIONS"))
        val grid = LinearLayout(s)
        grid.orientation = LinearLayout.VERTICAL
        var rl: LinearLayout? = null
        for ((i, q) in quick.withIndex()) {
            if (i % 2 == 0) {
                val r = LinearLayout(s)
                grid.addView(r, LinearLayout.LayoutParams(-1, -2))
                rl = r
            }
            val tile = LinearLayout(s)
            tile.gravity = Gravity.CENTER_VERTICAL
            tile.setPadding(dp(9), 0, dp(8), 0)
            tile.background = GradientDrawable().apply {
                cornerRadius = dp(15).toFloat()
                setColor(th.tile)
                setStroke(dp(1), th.tileLine)
            }
            val pair = tilePalette[(i + 2) % tilePalette.size]
            val chipBox = FrameLayout(s)
            chipBox.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pair.first, pair.second)).apply {
                shape = GradientDrawable.OVAL
            }
            val iv = ImageView(s)
            try { iv.setImageDrawable(s.getDrawable(q.second)) } catch (_: Exception) {}
            iv.setColorFilter(Color.WHITE)
            chipBox.addView(iv, FrameLayout.LayoutParams(dp(13), dp(13), Gravity.CENTER))
            tile.addView(chipBox, LinearLayout.LayoutParams(dp(26), dp(26)))
            val lb = TextView(s)
            lb.text = q.third
            lb.textSize = 10.5f
            lb.setTextColor(th.text)
            lb.maxLines = 1
            lb.ellipsize = TextUtils.TruncateAt.END
            lb.setPadding(dp(8), 0, 0, 0)
            tile.addView(lb, LinearLayout.LayoutParams(0, -2, 1f))
            tile.setOnClickListener {
                buzz()
                s.doAct(q.first, "edge")
                if (q.first != "timer" && q.first != "pad") closeAnimated()
            }
            rl?.addView(tile, LinearLayout.LayoutParams(pageW / 2 - dp(3), dp(46)).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            })
        }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    // ------------------------------------------------------------------------------------------
    // Controls
    // ------------------------------------------------------------------------------------------
    private fun pageControls(): View {
        val box = pageBox()
        box.addView(title("CONTROLS"))
        val am = try { s.getSystemService(AudioManager::class.java) } catch (_: Exception) { null }

        fun slider(stream: Int, label: String) {
            val r = LinearLayout(s)
            r.gravity = Gravity.CENTER_VERTICAL
            val lb = TextView(s)
            lb.text = label
            lb.textSize = 10f
            lb.setTextColor(th.sub)
            lb.width = dp(44)
            r.addView(lb, LinearLayout.LayoutParams(dp(44), -2))
            val bar = SeekBar(s)
            try {
                bar.max = am?.getStreamMaxVolume(stream) ?: 15
                bar.progress = am?.getStreamVolume(stream) ?: 0
            } catch (_: Exception) { bar.max = 15 }
            bar.thumbTintList = ColorStateList.valueOf(th.a1)
            bar.progressTintList = ColorStateList.valueOf(th.a1)
            bar.progressBackgroundTintList = ColorStateList.valueOf(if (th.dark) 0x33FFFFFF else 0x1F000000)
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    try { am?.setStreamVolume(stream, p, 0) } catch (_: Exception) {}
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { lockPager = true }
                override fun onStopTrackingTouch(sb: SeekBar?) { lockPager = false }
            })
            r.addView(bar, LinearLayout.LayoutParams(0, dp(30), 1f))
            box.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        slider(AudioManager.STREAM_MUSIC, "Media")
        slider(AudioManager.STREAM_RING, "Ring")
        slider(AudioManager.STREAM_ALARM, "Alarm")

        val rowT = LinearLayout(s)
        rowT.gravity = Gravity.CENTER
        rowT.setPadding(0, dp(10), 0, 0)
        val acts = listOf(
            Triple("torch", R.drawable.ic_flash, "Torch"),
            Triple("mute", R.drawable.ic_mute, "Mute"),
            Triple("shot", R.drawable.ic_cam, "Shot"),
            Triple("rec", R.drawable.ic_stop, "Record")
        )
        for ((i, t) in acts.withIndex()) {
            val cell = LinearLayout(s)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.background = GradientDrawable().apply {
                cornerRadius = dp(15).toFloat()
                setColor(th.tile)
                setStroke(dp(1), th.tileLine)
            }
            val pair = tilePalette[(i + 4) % tilePalette.size]
            val chipBox = FrameLayout(s)
            chipBox.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pair.first, pair.second)).apply {
                shape = GradientDrawable.OVAL
            }
            val iv = ImageView(s)
            try { iv.setImageDrawable(s.getDrawable(t.second)) } catch (_: Exception) {}
            iv.setColorFilter(Color.WHITE)
            chipBox.addView(iv, FrameLayout.LayoutParams(dp(13), dp(13), Gravity.CENTER))
            cell.addView(chipBox, LinearLayout.LayoutParams(dp(26), dp(26)).apply { topMargin = dp(9) })
            val lb = TextView(s)
            lb.text = t.third
            lb.textSize = 9f
            lb.setTextColor(th.sub)
            lb.gravity = Gravity.CENTER
            lb.setPadding(0, dp(5), 0, dp(8))
            cell.addView(lb)
            cell.setOnClickListener {
                buzz()
                s.doAct(t.first, "edge")
                if (t.first == "shot" || t.first == "rec") closeAnimated()
            }
            rowT.addView(cell, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        box.addView(rowT, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    // ------------------------------------------------------------------------------------------
    // Tools: draw pad, timers, clock
    // ------------------------------------------------------------------------------------------
    private fun pageTools(): View {
        val box = pageBox()
        box.addView(title("TOOLS"))

        val draw = LinearLayout(s)
        draw.gravity = Gravity.CENTER
        draw.orientation = LinearLayout.VERTICAL
        draw.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(th.a1, th.a2)).apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), 0x33FFFFFF)
        }
        val dt = TextView(s)
        dt.text = "✍  Draw to open"
        dt.textSize = 13f
        dt.setTextColor(Color.WHITE)
        dt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        dt.gravity = Gravity.CENTER
        draw.addView(dt)
        val ds = TextView(s)
        ds.text = "C camera · W WhatsApp · ← back"
        ds.textSize = 9f
        ds.setTextColor(0xCCFFFFFF.toInt())
        ds.gravity = Gravity.CENTER
        ds.setPadding(0, dp(3), 0, 0)
        draw.addView(ds)
        draw.setOnClickListener {
            buzz()
            closeAnimated()
            h.postDelayed({ s.openPad() }, 180)
        }
        box.addView(draw, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(10) })

        val tl = LinearLayout(s)
        tl.gravity = Gravity.CENTER_VERTICAL
        tl.addView(title("TIMER"), LinearLayout.LayoutParams(0, -2, 1f))
        val chips = LinearLayout(s)
        for ((sec, lbl) in listOf(60 to "1", 300 to "5", 600 to "10", 1800 to "30")) {
            val b = TextView(s)
            b.text = lbl
            b.textSize = 10.5f
            b.gravity = Gravity.CENTER
            b.setTextColor(th.text)
            b.background = GradientDrawable().apply {
                cornerRadius = dp(13).toFloat()
                setColor(th.tile)
                setStroke(dp(1), th.tileLine)
            }
            b.setOnClickListener {
                buzz()
                try { s.island.timerStart(sec) } catch (_: Exception) {}
                closeAnimated()
            }
            chips.addView(b, LinearLayout.LayoutParams(dp(34), dp(30)).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        tl.addView(chips)
        box.addView(tl, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val rowT = LinearLayout(s)
        rowT.gravity = Gravity.CENTER
        val tools = listOf(
            Triple("stopwatch", R.drawable.ic_timer, "Stopwatch"),
            Triple("rec", R.drawable.ic_stop, "Record"),
            Triple("shot", R.drawable.ic_cam, "Capture")
        )
        for ((i, t) in tools.withIndex()) {
            val cell = LinearLayout(s)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.background = GradientDrawable().apply {
                cornerRadius = dp(15).toFloat()
                setColor(th.tile)
                setStroke(dp(1), th.tileLine)
            }
            val pair = tilePalette[(i + 1) % tilePalette.size]
            val chipBox = FrameLayout(s)
            chipBox.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pair.first, pair.second)).apply {
                shape = GradientDrawable.OVAL
            }
            val iv = ImageView(s)
            try { iv.setImageDrawable(s.getDrawable(t.second)) } catch (_: Exception) {}
            iv.setColorFilter(Color.WHITE)
            chipBox.addView(iv, FrameLayout.LayoutParams(dp(12), dp(12), Gravity.CENTER))
            cell.addView(chipBox, LinearLayout.LayoutParams(dp(24), dp(24)).apply { topMargin = dp(9) })
            val lb = TextView(s)
            lb.text = t.third
            lb.textSize = 9f
            lb.setTextColor(th.sub)
            lb.gravity = Gravity.CENTER
            lb.setPadding(0, dp(5), 0, dp(8))
            cell.addView(lb)
            cell.setOnClickListener {
                buzz()
                when (t.first) {
                    "stopwatch" -> { try { s.island.swStart() } catch (_: Exception) {}; closeAnimated() }
                    "rec" -> { s.doAct("rec", "edge"); closeAnimated() }
                    else -> { s.doAct("shot", "edge"); closeAnimated() }
                }
            }
            rowT.addView(cell, LinearLayout.LayoutParams(0, dp(68), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        box.addView(rowT, LinearLayout.LayoutParams(-1, -2))

        val strip = LinearLayout(s)
        strip.gravity = Gravity.CENTER_VERTICAL
        strip.setPadding(dp(4), dp(10), dp(4), 0)
        val t = TextView(s)
        t.text = "—"
        t.textSize = 15f
        t.setTextColor(th.text)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        timeTv = t
        strip.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val b = TextView(s)
        b.text = ""
        b.textSize = 11f
        b.setTextColor(th.sub)
        batTv = b
        strip.addView(b)
        box.addView(strip, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    // ------------------------------------------------------------------------------------------
    // Draw panel
    // ------------------------------------------------------------------------------------------
    private fun pageDraw(): View {
        val box = pageBox()
        box.addView(title("DRAW"))
        val mp = MiniPad(s)
        box.addView(mp, LinearLayout.LayoutParams(-1, 0, 1f))
        val hint = TextView(s)
        hint.text = "C W M O S V U N Z L  ·  ← → ↑ ↓"
        hint.textSize = 9.5f
        hint.setTextColor(th.faint)
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(7), 0, dp(2))
        box.addView(hint)
        return box
    }

    private inner class MiniPad(c: Context) : View(c) {
        private var path = Path()
        private val pts = ArrayList<PointF>()
        private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dpf(5.5f)
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            color = Color.WHITE
        }
        private val face = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        private val box = RectF()
        private var msg = ""
        private var ok = false

        init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat(); val hgt = height.toFloat()
            if (w <= 0f || hgt <= 0f) return
            val rad = dpf(16f)
            box.set(0f, 0f, w, hgt)
            face.style = Paint.Style.FILL
            face.color = th.tile
            cv.drawRoundRect(box, rad, rad, face)
            face.style = Paint.Style.STROKE
            face.strokeWidth = dpf(1f)
            face.color = th.tileLine
            cv.drawRoundRect(box, rad, rad, face)
            ink.color = if (ok) 0xFF34D399.toInt() else th.text
            ink.setShadowLayer(dpf(9f), 0f, 0f, EdgeTheme.alpha(th.a1, 170))
            cv.drawPath(path, ink)
            if (pts.isEmpty()) {
                txt.textSize = dpf(11f)
                txt.color = th.faint
                cv.drawText("draw here", w / 2f, hgt / 2f + dpf(4f), txt)
            } else if (msg.isNotEmpty()) {
                txt.textSize = dpf(24f)
                txt.color = if (ok) 0xFF34D399.toInt() else th.sub
                cv.drawText(msg, w / 2f, hgt - dpf(12f), txt)
            }
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lockPager = true
                    path = Path()
                    pts.clear()
                    msg = ""
                    ok = false
                    path.moveTo(ev.x, ev.y)
                    pts.add(PointF(ev.x, ev.y))
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> { path.lineTo(ev.x, ev.y); pts.add(PointF(ev.x, ev.y)); invalidate() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    lockPager = false
                    val k = Glyphs.match(pts)
                    if (k == null) {
                        msg = "again?"
                        ok = false
                        invalidate()
                        buzz(16)
                        h.postDelayed({ path = Path(); pts.clear(); msg = ""; invalidate() }, 700)
                    } else {
                        msg = Glyphs.glyph(k)
                        ok = true
                        invalidate()
                        buzz(42)
                        h.postDelayed({
                            closeAnimated()
                            h.postDelayed({ try { s.drawGesture(k) } catch (_: Exception) {} }, 190)
                        }, 240)
                    }
                }
            }
            return true
        }
    }

    // ------------------------------------------------------------------------------------------
    // Device: battery, heat, memory, storage, uptime
    // ------------------------------------------------------------------------------------------
    private fun pageDevice(): View {
        val box = pageBox()
        box.addView(title("DEVICE"))
        devViews.clear()
        val grid = LinearLayout(s)
        grid.orientation = LinearLayout.VERTICAL
        var rl: LinearLayout? = null
        val keys = listOf(
            "bat" to "Battery", "state" to "Power", "temp" to "Heat",
            "ram" to "Memory", "store" to "Storage", "up" to "Uptime"
        )
        for ((i, pair) in keys.withIndex()) {
            if (i % 2 == 0) {
                val r = LinearLayout(s)
                grid.addView(r, LinearLayout.LayoutParams(-1, -2))
                rl = r
            }
            val tile = LinearLayout(s)
            tile.orientation = LinearLayout.VERTICAL
            tile.setPadding(dp(10), dp(8), dp(10), dp(9))
            tile.background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(th.tile)
                setStroke(dp(1), th.tileLine)
            }
            val v = TextView(s)
            v.text = "—"
            v.textSize = 15f
            v.setTextColor(th.text)
            v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            tile.addView(v)
            val l = TextView(s)
            l.text = pair.second
            l.textSize = 8.5f
            l.setTextColor(th.faint)
            l.setPadding(0, dp(1), 0, 0)
            tile.addView(l)
            devViews[pair.first] = v
            rl?.addView(tile, LinearLayout.LayoutParams(pageW / 2 - dp(7), -2).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2))
        val hint = TextView(s)
        hint.text = "Updates while the panel is open"
        hint.textSize = 9f
        hint.setTextColor(th.faint)
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(8), 0, 0)
        box.addView(hint)
        refreshDevice()
        return box
    }

    private fun refreshDevice() {
        if (devViews.isEmpty()) return
        try {
            val b = s.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val scale = maxOf(b?.getIntExtra("scale", 100) ?: 100, 1)
            val pct = (b?.getIntExtra("level", 0) ?: 0) * 100 / scale
            val status = b?.getIntExtra("status", 0) ?: 0
            val charging = status == 2 || status == 5
            devViews["bat"]?.text = "$pct%"
            devViews["state"]?.text = if (charging) "Charging" else "Battery"
            val t = (b?.getIntExtra("temperature", 0) ?: 0) / 10f
            devViews["temp"]?.text = String.format(java.util.Locale.US, "%.1f°C", t)
            val am = s.getSystemService(ActivityManager::class.java)
            if (am != null) {
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                devViews["ram"]?.text = (mi.availMem / 1048576L).toString() + " MB"
            }
            val st = StatFs(Environment.getDataDirectory().path)
            val freeGb = st.availableBlocksLong * st.blockSizeLong / 1073741824.0
            devViews["store"]?.text = String.format(java.util.Locale.US, "%.1f GB", freeGb)
            val mins = SystemClock.elapsedRealtime() / 60000L
            devViews["up"]?.text = if (mins < 60) mins.toString() + " min" else (mins / 60).toString() + "h " + (mins % 60) + "m"
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------------------------------
    // Timer
    // ------------------------------------------------------------------------------------------
    private fun pageTimer(): View {
        val box = pageBox()
        box.addView(title("TIMER"))
        val row1 = LinearLayout(s)
        row1.gravity = Gravity.CENTER
        for ((sec, lbl) in listOf(60 to "1 min", 300 to "5 min", 600 to "10 min", 1800 to "30 min")) {
            val b = TextView(s)
            b.text = lbl
            b.textSize = 10f
            b.gravity = Gravity.CENTER
            b.setTextColor(th.text)
            b.background = GradientDrawable().apply {
                cornerRadius = dp(13).toFloat()
                setColor(th.tile)
                setStroke(dp(1), th.tileLine)
            }
            b.setOnClickListener {
                buzz()
                try { s.island.timerStart(sec) } catch (_: Exception) {}
                closeAnimated()
            }
            row1.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        box.addView(row1, LinearLayout.LayoutParams(-1, -2))

        val row2 = LinearLayout(s)
        row2.gravity = Gravity.CENTER
        row2.setPadding(0, dp(10), 0, 0)
        val stop = TextView(s)
        stop.text = "⏱  Stopwatch"
        stop.textSize = 11f
        stop.gravity = Gravity.CENTER
        stop.setTextColor(Color.WHITE)
        stop.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(th.a1, th.a2)).apply {
            cornerRadius = dp(14).toFloat()
        }
        stop.setOnClickListener {
            buzz()
            try { s.island.swStart() } catch (_: Exception) {}
            closeAnimated()
        }
        row2.addView(stop, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(0, 0, dp(3), 0) })

        val clear = TextView(s)
        clear.text = "Stop all"
        clear.textSize = 11f
        clear.gravity = Gravity.CENTER
        clear.setTextColor(th.text)
        clear.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(th.tile)
            setStroke(dp(1), th.tileLine)
        }
        clear.setOnClickListener {
            buzz()
            try { s.island.clock.reset(); s.island.base() } catch (_: Exception) {}
            closeAnimated()
        }
        row2.addView(clear, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), 0, 0, 0) })
        box.addView(row2, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    // ------------------------------------------------------------------------------------------
    // Compass
    // ------------------------------------------------------------------------------------------
    private fun pageCompass(): View {
        val box = pageBox()
        box.addView(title("COMPASS"))
        val cv = CompassView(s)
        compass = cv
        box.addView(cv, LinearLayout.LayoutParams(min(pageW - dp(8), dp(230)), 0, 1f))
        val hint = TextView(s)
        hint.text = "Move the phone in a figure 8 to calibrate"
        hint.textSize = 9.5f
        hint.setTextColor(th.faint)
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(6), 0, dp(4))
        box.addView(hint)
        return box
    }

    private fun openApp(tab: String) {
        try {
            s.startActivity(Intent(s, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("tab", tab))
        } catch (_: Exception) {}
        closeAnimated()
    }

    // ------------------------------------------------------------------------------------------
    // live bits
    // ------------------------------------------------------------------------------------------
    private fun startTick() {
        stopTick()
        val r = object : Runnable {
            override fun run() {
                timeTv?.text = android.text.format.DateFormat.format(
                    if (android.text.format.DateFormat.is24HourFormat(s)) "HH:mm" else "h:mm",
                    java.util.Date()
                ).toString()
                val b = s.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val pct = (b?.getIntExtra("level", 0) ?: 0) * 100 / maxOf(b?.getIntExtra("scale", 100) ?: 100, 1)
                batTv?.text = "$pct%"
                refreshDevice()
                if (root != null) h.postDelayed(this, 5000)
            }
        }
        tick = r
        r.run()
    }

    private fun stopTick() { tick?.let { h.removeCallbacks(it) }; tick = null }

    private fun registerCompass() {
        if (sensReg || compass == null) return
        try {
            val sm = s.getSystemService(SensorManager::class.java)
            val rot = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
                ?: sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            if (rot != null) { sm.registerListener(this, rot, SensorManager.SENSOR_DELAY_UI); sensReg = true }
        } catch (_: Exception) {}
    }

    private fun unregisterCompass() {
        if (!sensReg) return
        try { s.getSystemService(SensorManager::class.java).unregisterListener(this) } catch (_: Exception) {}
        sensReg = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type != Sensor.TYPE_ROTATION_VECTOR && e.sensor.type != Sensor.TYPE_GAME_ROTATION_VECTOR) return
        val r = FloatArray(9)
        val o = FloatArray(3)
        try {
            SensorManager.getRotationMatrixFromVector(r, e.values)
            SensorManager.getOrientation(r, o)
            var deg = Math.toDegrees(o[0].toDouble()).toFloat()
            if (deg < 0) deg += 360f
            compass?.heading = deg
            compass?.invalidate()
        } catch (_: Exception) {}
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private inner class CompassView(c: Context) : View(c) {
        var heading = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        override fun onDraw(cv: Canvas) {
            val d = density
            val w = width.toFloat(); val hgt = height.toFloat()
            val cx = w / 2f; val cy = hgt / 2f
            val rad = min(w, hgt) / 2f - 10 * d
            if (rad <= 0) return
            val t = th
            cv.save()
            cv.rotate(-heading, cx, cy)
            for (i in 0 until 72) {
                val major = i % 18 == 0
                val mid = i % 6 == 0
                p.color = when {
                    major -> EdgeTheme.alpha(t.text, 235)
                    mid -> EdgeTheme.alpha(t.text, 140)
                    else -> EdgeTheme.alpha(t.text, 70)
                }
                p.strokeWidth = (if (major) 2.4f else if (mid) 1.6f else 1f) * d
                val a = Math.toRadians((i * 5).toDouble())
                val sa = sin(a).toFloat(); val ca = cos(a).toFloat()
                val r2 = rad - (if (major) 16 else if (mid) 10 else 6) * d
                cv.drawLine(cx + rad * sa, cy - rad * ca, cx + r2 * sa, cy - r2 * ca, p)
            }
            txt.textSize = 13 * d
            txt.textAlign = Paint.Align.CENTER
            for ((name, ang) in listOf("N" to 0f, "E" to 90f, "S" to 180f, "W" to 270f)) {
                val a = Math.toRadians(ang.toDouble())
                val sa = sin(a).toFloat(); val ca = cos(a).toFloat()
                val rr = rad - 30 * d
                txt.color = if (name == "N") 0xFFFF5A5A.toInt() else EdgeTheme.alpha(t.text, 210)
                cv.drawText(name, cx + rr * sa, cy - rr * ca + 5 * d, txt)
            }
            cv.restore()
            p.color = t.a1
            p.style = Paint.Style.FILL
            val nw = 5 * d
            cv.drawPath(Path().apply {
                moveTo(cx, cy - rad + 2 * d)
                lineTo(cx - nw, cy - rad + 20 * d)
                lineTo(cx + nw, cy - rad + 20 * d)
                close()
            }, p)
            rect.set(cx - rad * 0.62f, cy - rad * 0.62f, cx + rad * 0.62f, cy + rad * 0.62f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.2f * d
            p.color = t.a1
            cv.drawCircle(cx, cy, rad * 0.62f, p)
            p.style = Paint.Style.FILL
            txt.color = t.text
            txt.textSize = 30 * d
            txt.textAlign = Paint.Align.CENTER
            txt.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            cv.drawText("${heading.toInt()}°", cx, cy + 10 * d, txt)
            txt.textSize = 10 * d
            txt.color = t.faint
            cv.drawText(dirName(heading), cx, cy + 26 * d, txt)
            txt.typeface = null
        }

        private fun dirName(h: Float): String {
            val names = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
            return names[(((h + 22.5f) % 360f) / 45f).toInt() % 8]
        }
    }
}
