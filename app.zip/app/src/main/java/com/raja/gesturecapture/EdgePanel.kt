package com.raja.gesturecapture

import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.min

// ---------------------------------------------------------------------------------------------------
// Edge panel: a slim grip on the side of the screen. Tap it (or pull it inwards) and a panel slides
// out with quick actions and your own app shortcuts. Pull it back to the edge to close it.
// ---------------------------------------------------------------------------------------------------
class EdgePanel(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var grip: View? = null
    private var root: FrameLayout? = null
    private var card: View? = null
    private var closing = false

    private fun dp(v: Int) = (v * s.resources.displayMetrics.density).toInt()
    private fun cfg(): JSONObject = try { JSONObject(Prefs.sp(s).getString("ep", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun on() = cfg().optBoolean("on", false)
    private fun right() = cfg().optString("side", "right") != "left"
    private fun lp(w: Int, ht: Int, f: Int = 0) = WindowManager.LayoutParams(w, ht, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or f, PixelFormat.TRANSLUCENT)
    private fun buzz(ms: Long = 30) { try { s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(ms, 255)) } catch (_: Exception) {} }
    private fun round(c: Int, r: Int) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(c) }

    private val quick = listOf(
        Triple("torch", R.drawable.ic_flash, "Torch"),
        Triple("shot", R.drawable.ic_cam, "Screenshot"),
        Triple("timer", R.drawable.ic_timer, "Timer"),
        Triple("lock", R.drawable.ic_lock, "Lock"),
        Triple("home", R.drawable.ic_home, "Home"),
        Triple("back", R.drawable.ic_back, "Back"),
        Triple("notif", R.drawable.ic_bell, "Notifications"),
        Triple("recents", R.drawable.ic_recents, "Recents"))

    fun sync() { h.post { if (on()) showGrip() else { hideGrip(); close() } } }
    fun destroy() { h.post { hideGrip(); close() } }

    // ---- the grip on the edge ----
    private fun showGrip() {
        if (grip != null) return
        val v = View(s)
        v.background = GradientDrawable().apply {
            cornerRadius = dp(7).toFloat(); setColor(0x59FFFFFF); setStroke(dp(1), 0x33FFFFFF)
        }
        var sx = 0f; var sy = 0f; var pulled = false; var tapT = 0L
        v.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; pulled = false; v.alpha = 1f }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - sx
                    val inward = if (right()) -dx else dx
                    if (!pulled && inward > dp(14)) { pulled = true; buzz(); open() }
                }
                MotionEvent.ACTION_UP -> {
                    if (!pulled) {
                        if (ev.eventTime - tapT < 320) { buzz(); open() } else { tapT = ev.eventTime; buzz(20) }
                    }
                    v.alpha = 0.55f
                }
            }
            true
        }
        v.alpha = 0.55f
        val p = lp(dp(11), dp(cfg().optInt("len", 180)))
        p.gravity = (if (right()) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        p.y = dp(cfg().optInt("gy", 0))
        try { wm.addView(v, p) } catch (_: Exception) { return }
        grip = v
    }

    private fun hideGrip() {
        grip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        grip = null
    }

    // ---- the panel ----
    fun open() { h.post {
        if (root != null || closing) return@post
        val dm = s.resources.displayMetrics
        val w = min(dp(cfg().optInt("w", 296)), (dm.widthPixels * 0.84).toInt())
        val full = FrameLayout(s)
        full.setOnClickListener { close() }
        val c = build(w)
        val cp = FrameLayout.LayoutParams(w, -1)
        cp.gravity = if (right()) Gravity.END else Gravity.START
        full.addView(c, cp)
        val p = lp(-1, -1, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        try { wm.addView(full, p) } catch (_: Exception) { return@post }
        root = full; card = c
        c.translationX = if (right()) w.toFloat() else -w.toFloat()
        c.animate().translationX(0f).setDuration(240).start()
    } }

    fun close() {
        val r = root ?: return
        if (closing) return
        closing = true
        val c = card
        if (c == null || c.width == 0) { drop(r); return }
        c.animate().translationX(if (right()) c.width.toFloat() else -c.width.toFloat()).setDuration(180)
            .withEndAction { drop(r) }.start()
    }

    private fun drop(r: View) {
        try { wm.removeView(r) } catch (_: Exception) {}
        root = null; card = null; closing = false
    }

    private fun build(w: Int): View {
        val col = LinearLayout(s); col.orientation = LinearLayout.VERTICAL
        col.background = GradientDrawable().apply {
            setColor(0xF20F1424.toInt()); setStroke(dp(1), 0x1AFFFFFF)
            cornerRadius = dp(28).toFloat()
            val r = dp(28).toFloat()
            // right-hand panel keeps its left corners round (the ones facing the screen)
            if (right()) cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            else cornerRadii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
        }
        col.isClickable = true
        col.setPadding(dp(16), dp(22), dp(16), dp(16))

        // header
        val head = LinearLayout(s); head.gravity = Gravity.CENTER_VERTICAL
        val ht = TextView(s); ht.text = "EDGE PANEL"; ht.setTextColor(0xFFFFFFFF.toInt()); ht.textSize = 12f
        ht.letterSpacing = 0.14f; ht.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        head.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        val xb = TextView(s); xb.text = "✕"; xb.textSize = 16f; xb.setTextColor(0xAAFFFFFF.toInt())
        xb.setPadding(dp(12), dp(4), dp(4), dp(4)); xb.setOnClickListener { close() }
        head.addView(xb)
        col.addView(head, LinearLayout.LayoutParams(-1, -2))

        // quick actions, four to a row
        val grid = LinearLayout(s); grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(0, dp(16), 0, dp(6))
        var row: LinearLayout? = null
        quick.forEachIndexed { i, q ->
            if (i % 4 == 0) { val r = LinearLayout(s); grid.addView(r, LinearLayout.LayoutParams(-1, -2)); row = r }
            val cell = LinearLayout(s); cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER_HORIZONTAL
            val b = FrameLayout(s); b.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x1FFFFFFF) }
            val iv = ImageView(s); try { iv.setImageDrawable(s.getDrawable(q.second)) } catch (_: Exception) {}
            iv.setColorFilter(Color.WHITE)
            b.addView(iv, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
            cell.addView(b, LinearLayout.LayoutParams(dp(44), dp(44)))
            val lb = TextView(s); lb.text = q.third; lb.textSize = 10f; lb.setTextColor(0x99FFFFFF.toInt()); lb.gravity = Gravity.CENTER
            lb.setPadding(0, dp(5), 0, 0); cell.addView(lb)
            cell.setOnClickListener { buzz(); s.doAct(q.first, "edge"); if (q.first != "timer") close() }
            row?.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(grid, LinearLayout.LayoutParams(-1, -2))

        // divider
        val dv = View(s); dv.setBackgroundColor(0x14FFFFFF)
        col.addView(dv, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(4) })

        // app shortcuts
        val apps = cfg().optJSONArray("apps") ?: JSONArray()
        val listBox = LinearLayout(s); listBox.orientation = LinearLayout.VERTICAL
        val scroll = android.widget.ScrollView(s); scroll.isVerticalScrollBarEnabled = false
        scroll.addView(listBox, FrameLayout.LayoutParams(-1, -2))
        var added = 0
        for (i in 0 until apps.length()) {
            val o = apps.optJSONObject(i) ?: continue
            val pk = o.optString("p", "")
            if (pk.isEmpty()) continue
            added++
            val r = LinearLayout(s); r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(10), 0, dp(10)); r.isClickable = true
            val ic = ImageView(s)
            try { ic.setImageDrawable(s.packageManager.getApplicationIcon(pk)) } catch (_: Exception) {}
            r.addView(ic, LinearLayout.LayoutParams(dp(38), dp(38)))
            val nm = TextView(s)
            nm.text = o.optString("n", "").ifBlank {
                try { s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pk, 0)).toString() } catch (_: Exception) { pk }
            }
            nm.setTextColor(Color.WHITE); nm.textSize = 14f; nm.setPadding(dp(14), 0, 0, 0)
            nm.maxLines = 1; nm.ellipsize = android.text.TextUtils.TruncateAt.END
            r.addView(nm, LinearLayout.LayoutParams(0, -2, 1f))
            r.setOnClickListener {
                buzz()
                try { s.packageManager.getLaunchIntentForPackage(pk)?.let { s.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } } catch (_: Exception) {}
                close()
            }
            listBox.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        if (added == 0) {
            val empty = TextView(s)
            empty.text = "No shortcuts yet. Add apps from the Edge tab in the app."
            empty.setTextColor(0x88FFFFFF.toInt()); empty.textSize = 12f; empty.setPadding(0, dp(14), 0, dp(10))
            listBox.addView(empty, LinearLayout.LayoutParams(-1, -2))
        }
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // footer
        val ft = TextView(s); ft.text = "✎ Customise"; ft.textSize = 12f; ft.gravity = Gravity.CENTER
        ft.setTextColor(0xFFFFFFFF.toInt()); ft.setPadding(0, dp(12), 0, dp(12))
        ft.background = round(0x1FFFFFFF, 18)
        ft.setOnClickListener {
            try { s.startActivity(Intent(s, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("tab", "4")) } catch (_: Exception) {}
            close()
        }
        col.addView(ft, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        // pull the card back towards the edge to close it
        var sx = 0f
        col.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> sx = ev.rawX
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - sx
                    val out = if (right()) dx else -dx
                    if (out > 0) col.translationX = out
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (abs(col.translationX) > dp(70)) close() else col.animate().translationX(0f).setDuration(140).start()
                }
            }
            false
        }
        return col
    }
}
