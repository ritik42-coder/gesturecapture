package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------------
// Edge panel. A slim grip on the side of the screen; pull it and the panel follows your finger.
// Inside there are several panels (Apps, Actions, Compass, Tools) that you swipe through one by one,
// exactly like Samsung's edge panels, with page dots at the bottom.
// Look, colour, animation and speed are all settings.
// ---------------------------------------------------------------------------------------------------
class EdgePanel(private val s: GestureService, private val wm: WindowManager) : SensorEventListener {
    private val h = Handler(Looper.getMainLooper())
    private var grip: View? = null
    private var root: FrameLayout? = null
    private var scrim: View? = null
    private var card: LinearLayout? = null
    private var pager: Pager? = null
    private var row: LinearLayout? = null
    private var dotsBox: LinearLayout? = null
    private val dots = ArrayList<View>()
    private var index = 0
    private var pageW = 0
    private var cardW = 0
    private var pages = ArrayList<String>()
    private var built = false
    private var signature = ""
    private var isOpen = false
    private var busy = false
    private var compass: CompassView? = null
    private var sensReg = false
    private var tick: Runnable? = null
    private var timeTv: TextView? = null
    private var batTv: TextView? = null

    private fun dp(v: Int) = (v * s.resources.displayMetrics.density).toInt()
    private fun cfg(): JSONObject = try { JSONObject(Prefs.sp(s).getString("ep", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun on() = cfg().optBoolean("on", false)
    private fun right() = cfg().optString("side", "right") != "left"
    private fun col(k: String, d: String) = try { Color.parseColor(cfg().optString(k, d)) } catch (_: Exception) { Color.parseColor(d) }
    private fun c1() = col("c1", "#2563EB")
    private fun c2() = col("c2", "#0A1730")
    private fun op() = cfg().optInt("op", 94).coerceIn(30, 100)
    private fun radius() = dp(cfg().optInt("radius", 26))
    private fun dim() = cfg().optInt("dim", 45).coerceIn(0, 90)
    private fun style() = cfg().optString("anim", "slide")
    private fun spd() = when (cfg().optString("speed", "normal")) { "fast" -> 0.65f; "slow" -> 1.6f; else -> 1f }
    private fun buzz(ms: Long = 28) { try { s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(ms, 255)) } catch (_: Exception) {} }
    private fun lp(w: Int, ht: Int, f: Int = 0) = WindowManager.LayoutParams(w, ht, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or f, PixelFormat.TRANSLUCENT)

    private val quick = listOf(
        Triple("torch", R.drawable.ic_flash, "Torch"),
        Triple("shot", R.drawable.ic_cam, "Screenshot"),
        Triple("timer", R.drawable.ic_timer, "Timer"),
        Triple("lock", R.drawable.ic_lock, "Lock"),
        Triple("home", R.drawable.ic_home, "Home"),
        Triple("back", R.drawable.ic_back, "Back"),
        Triple("notif", R.drawable.ic_bell, "Alerts"),
        Triple("recents", R.drawable.ic_recents, "Recents"),
        Triple("pad", R.drawable.ic_edit, "Draw"),
        Triple("quick", R.drawable.ic_tune, "Settings"))

    // ------------------------------------------------------------------------------------------
    fun sync() {
        h.post {
            val c = cfg()
            val sig = c.toString()
            if (!c.optBoolean("on", false)) { hideGrip(); closeNow(); signature = ""; return@h.post }
            if (sig != signature) { signature = sig; hideGrip(); closeNow(); built = false; card = null }
            showGrip()
        }
    }

    fun destroy() { h.post { hideGrip(); closeNow() } }

    // ------------------------------------------------------------------------------------------
    // grip
    // ------------------------------------------------------------------------------------------
    private fun showGrip() {
        if (grip != null) return
        val len = dp(cfg().optInt("len", 168))
        val wrap = FrameLayout(s)
        // soft glow behind the pill
        val glow = View(s)
        glow.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(11).toFloat()
            setColor((c1() and 0xFFFFFF) or 0x33000000)
        }
        val gw = dp(20); val gh = len + dp(20)
        wrap.addView(glow, FrameLayout.LayoutParams(gw, gh, Gravity.CENTER))
        // the pill itself
        val pill = View(s)
        pill.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c1(), c2())).apply {
            cornerRadius = dp(6).toFloat(); setStroke(dp(1), 0x66FFFFFF)
        }
        wrap.addView(pill, FrameLayout.LayoutParams(dp(8), len, Gravity.CENTER))
        wrap.alpha = 0.62f

        var sx = 0f; var sy = 0f; var moved = false; var pulled = false
        wrap.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.rawX; sy = ev.rawY; moved = false; pulled = false
                    v.animate().cancel(); v.animate().alpha(1f).setDuration(120).start()
                    attachWindow()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - sx
                    if (abs(dx) > dp(4) || abs(ev.rawY - sy) > dp(4)) moved = true
                    if (moved) {
                        val inward = if (right()) -dx else dx
                        if (inward > dp(10)) pulled = true
                        follow(inward)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().alpha(0.62f).setDuration(220).start()
                    if (pulled) settle() else { settleOpen() ; buzz() }
                }
            }
            true
        }
        val p = lp(dp(34), dp(cfg().optInt("len", 168) + 20))
        p.gravity = (if (right()) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        p.x = if (right()) 0 else 0
        p.y = dp(cfg().optInt("gy", 0))
        try { wm.addView(wrap, p) } catch (_: Exception) { return }
        grip = wrap
    }

    private fun hideGrip() {
        grip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        grip = null
    }

    // ------------------------------------------------------------------------------------------
    // window + card
    // ------------------------------------------------------------------------------------------
    private fun buildCard(): LinearLayout {
        val dm = s.resources.displayMetrics
        cardW = min(dp(cfg().optInt("w", 300)), (dm.widthPixels * 0.86).toInt())
        pageW = cardW - dp(28)
        pages = cfg().optString("pages", "apps,actions,compass,tools").split(",").map { it.trim() }
            .filter { it in setOf("apps", "actions", "compass", "tools") }
        if (pages.isEmpty()) pages = arrayListOf("apps")

        val r = radius()
        val c = LinearLayout(s); c.orientation = LinearLayout.VERTICAL
        val gd = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1(), c2()))
        gd.cornerRadius = r.toFloat()
        gd.alpha = op() * 255 / 100
        gd.setStroke(dp(1), 0x33FFFFFF)
        if (right()) gd.cornerRadii = floatArrayOf(0f, 0f, r.toFloat(), r.toFloat(), r.toFloat(), r.toFloat(), 0f, 0f)
        else gd.cornerRadii = floatArrayOf(r.toFloat(), r.toFloat(), 0f, 0f, 0f, 0f, r.toFloat(), r.toFloat())
        c.background = gd
        c.setPadding(dp(14), dp(16), dp(14), dp(12))

        // header
        val head = LinearLayout(s); head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(4), 0, 0, dp(4))
        val ttl = TextView(s); ttl.text = "EDGE"; ttl.textSize = 11f
        ttl.setTextColor(0xCCFFFFFF.toInt()); ttl.letterSpacing = 0.22f
        ttl.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        head.addView(ttl, LinearLayout.LayoutParams(0, -2, 1f))
        val close = TextView(s); close.text = "✕"; close.textSize = 15f; close.setTextColor(0xCCFFFFFF.toInt())
        close.gravity = Gravity.CENTER
        close.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x24FFFFFF) }
        close.setOnClickListener { closeAnimated() }
        head.addView(close, LinearLayout.LayoutParams(dp(30), dp(30)))
        c.addView(head, LinearLayout.LayoutParams(-1, dp(42)))

        // pager
        val pg = Pager(s)
        val rw = LinearLayout(s); rw.orientation = LinearLayout.HORIZONTAL
        row = rw
        pg.addView(rw, FrameLayout.LayoutParams(pageW * pages.size, -1))
        for (k in pages) {
            val page = when (k) {
                "apps" -> pageApps()
                "actions" -> pageActions()
                "compass" -> pageCompass()
                else -> pageTools()
            }
            rw.addView(page, LinearLayout.LayoutParams(pageW, -1))
        }
        pager = pg
        c.addView(pg, LinearLayout.LayoutParams(-1, 0, 1f))

        // page dots
        val db = LinearLayout(s); db.gravity = Gravity.CENTER; db.setPadding(0, dp(6), 0, dp(2))
        dotsBox = db; dots.clear()
        for (i in pages.indices) {
            val d = View(s)
            d.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            db.addView(d, LinearLayout.LayoutParams(dp(6), dp(6)).apply { setMargins(dp(3), 0, dp(3), 0) })
            dots.add(d)
        }
        if (pages.size > 1) c.addView(db, LinearLayout.LayoutParams(-1, dp(22)))
        paintDots()
        return c
    }

    private fun attachWindow() {
        if (root != null) return
        if (!built) { card = buildCard(); built = true }
        val c = card ?: return
        val full = FrameLayout(s)
        val sc = View(s)
        sc.setBackgroundColor(0xFF000000.toInt())
        sc.alpha = 0f
        sc.setOnClickListener { closeAnimated() }
        full.addView(sc, FrameLayout.LayoutParams(-1, -1))
        if (c.parent != null) (c.parent as FrameLayout).removeView(c)
        val cp = FrameLayout.LayoutParams(cardW, -1)
        cp.gravity = if (right()) Gravity.END else Gravity.START
        cp.rightMargin = 0; cp.leftMargin = 0
        full.addView(c, cp)
        val p = lp(-1, -1, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val b = cfg().optInt("blur", 0)
                if (b > 0) { p.flags = p.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND; p.blurBehindRadius = dp(b) }
            } catch (_: Exception) {}
        }
        try { wm.addView(full, p) } catch (_: Exception) { return }
        root = full; scrim = sc
        c.translationX = if (right()) cardW.toFloat() else -cardW.toFloat()
        if (style() == "fade") { c.alpha = 0f; c.scaleX = 0.94f; c.scaleY = 0.94f }
        if (style() == "cover") { c.rotationY = if (right()) 62f else -62f; c.pivotX = if (right()) cardW.toFloat() else 0f }
        index = 0; applyIndex(false)
        startTick(); registerCompass()
    }

    // follow the finger while the grip is dragged
    private fun follow(inward: Float) {
        val c = card ?: return
        if (isOpen) return
        val w = cardW.toFloat()
        val prog = (inward / w).coerceIn(0f, 1f)
        c.translationX = (if (right()) 1f else -1f) * w * (1f - prog)
        scrim?.alpha = prog * dim() / 100f
        if (style() == "fade") { c.alpha = prog; c.scaleX = 0.94f + 0.06f * prog; c.scaleY = c.scaleX }
        if (style() == "cover") c.rotationY = (if (right()) 62f else -62f) * (1f - prog)
    }

    private fun settle() {
        val c = card ?: return
        val w = cardW.toFloat()
        val prog = 1f - abs(c.translationX) / w
        if (prog > 0.32f) settleOpen() else settleClose()
    }

    private fun settleOpen() {
        val c = card ?: return
        isOpen = true; busy = true
        val dur = (250 * spd()).toLong()
        val itp = when (style()) { "spring" -> OvershootInterpolator(1.5f); "elastic" -> OvershootInterpolator(2.6f); else -> DecelerateInterpolator() }
        val from = c.translationX
        ValueAnimator.ofFloat(from, 0f).apply {
            duration = dur; interpolator = itp
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                c.translationX = f
                if (style() == "fade") { c.alpha = 1f - abs(f) / cardW; c.scaleX = 0.94f + 0.06f * (1f - abs(f) / cardW); c.scaleY = c.scaleX }
                if (style() == "cover") c.rotationY = (if (right()) 62f else -62f) * (abs(f) / cardW)
            }
            start()
        }
        scrim?.animate()?.alpha(dim() / 100f)?.setDuration(dur)?.start()
        h.postDelayed({ busy = false }, dur + 40)
        grip?.animate()?.alpha(0f)?.setDuration(140)?.start()
    }

    private fun settleClose() {
        val c = card ?: return
        val dur = (190 * spd()).toLong()
        val target = if (right()) cardW.toFloat() else -cardW.toFloat()
        isOpen = false
        c.animate().translationX(target).setDuration(dur).setInterpolator(DecelerateInterpolator())
            .withEndAction { detach() }.start()
        scrim?.animate()?.alpha(0f)?.setDuration(dur)?.start()
    }

    fun open() { h.post { if (root == null) { attachWindow(); settleOpen() } } }

    fun close() { h.post { closeAnimated() } }

    private fun closeAnimated() {
        if (root == null) return
        val c = card ?: return detach()
        val dur = (200 * spd()).toLong()
        val target = if (right()) cardW.toFloat() else -cardW.toFloat()
        isOpen = false
        c.animate().translationX(target).setDuration(dur).setInterpolator(DecelerateInterpolator())
            .withEndAction { detach() }.start()
        if (style() == "fade") c.animate().alpha(0f).setDuration(dur).start()
        if (style() == "cover") c.animate().rotationY((if (right()) 62f else -62f)).setDuration(dur).start()
        scrim?.animate()?.alpha(0f)?.setDuration(dur)?.start()
    }

    private fun closeNow() { detach() }

    private fun detach() {
        stopTick(); unregisterCompass()
        if (card?.parent != null) (card!!.parent as FrameLayout).removeView(card)
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; scrim = null; isOpen = false; busy = false
        card?.translationX = 0f; card?.alpha = 1f; card?.scaleX = 1f; card?.scaleY = 1f; card?.rotationY = 0f
        index = 0
        grip?.animate()?.alpha(0.62f)?.setDuration(160)?.start()
    }

    // ------------------------------------------------------------------------------------------
    // paging
    // ------------------------------------------------------------------------------------------
    private fun applyIndex(animate: Boolean) {
        val r = row ?: return
        val target = -index * pageW.toFloat()
        if (!animate) { r.translationX = target; paintDots(); return }
        ValueAnimator.ofFloat(r.translationX, target).apply {
            duration = (240 * spd()).toLong(); interpolator = DecelerateInterpolator()
            addUpdateListener { r.translationX = it.animatedValue as Float }
            start()
        }
        paintDots()
    }

    private fun goPage(to: Int) {
        if (pages.isEmpty()) return
        index = to.coerceIn(0, pages.size - 1)
        applyIndex(true)
        buzz(18)
    }

    private fun paintDots() {
        dots.forEachIndexed { i, d ->
            val on = i == index
            d.alpha = if (on) 1f else 0.35f
            val s = if (on) 1.25f else 1f
            d.scaleX = s; d.scaleY = s
        }
    }

    // swipe through the panels, one by one, and pull down to close
    private inner class Pager(c: Context) : FrameLayout(c) {
        private val slop = ViewConfiguration.get(c).scaledTouchSlop
        private var downX = 0f; private var downY = 0f
        private var dragging = false; private var vertical = false

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; dragging = false; vertical = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    if (!dragging && !vertical && abs(dx) > slop * 1.4f && abs(dx) > abs(dy)) { dragging = true; return true }
                    if (!vertical && !dragging && abs(dy) > slop * 2f && abs(dy) > abs(dx) * 1.5f) { vertical = true; return true }
                }
            }
            return false
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            val r = row ?: return false
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    if (dragging) {
                        var x = -index * pageW + dx
                        val minX = -(pages.size - 1) * pageW.toFloat()
                        if (x > 0f) x *= 0.35f                       // rubber band at the ends
                        if (x < minX) x = minX + (x - minX) * 0.35f
                        r.translationX = x
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (vertical) {
                        val dy = ev.rawY - downY
                        if (dy > dp(70)) closeAnimated() else { }
                    } else if (dragging) {
                        val dx = ev.rawX - downX
                        val moved = (dx / pageW)
                        var to = index
                        if (moved < -0.22f) to = index + 1
                        else if (moved > 0.22f) to = index - 1
                        goPage(to)
                    }
                    dragging = false; vertical = false
                }
            }
            return true
        }
    }

    // ------------------------------------------------------------------------------------------
    // pages
    // ------------------------------------------------------------------------------------------
    private fun pageBox(): LinearLayout = LinearLayout(s).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(2), dp(6), dp(2), dp(2))
    }

    private fun title(t: String): TextView = TextView(s).apply {
        text = t; textSize = 10f; setTextColor(0x99FFFFFF.toInt()); letterSpacing = 0.18f
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        setPadding(dp(2), 0, 0, dp(8))
    }

    private fun pageApps(): View {
        val box = pageBox()
        box.addView(title("APPS"))
        val grid = LinearLayout(s); grid.orientation = LinearLayout.VERTICAL
        val apps = cfg().optJSONArray("apps") ?: JSONArray()
        val list = ArrayList<Pair<String, String>>()
        for (i in 0 until apps.length()) {
            val o = apps.optJSONObject(i) ?: continue
            val pk = o.optString("p", ""); if (pk.isEmpty()) continue
            val nm = o.optString("n", "").ifBlank {
                try { s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pk, 0)).toString() } catch (_: Exception) { pk }
            }
            list.add(Pair(pk, nm))
        }
        val cellW = pageW / 4
        var rl: LinearLayout? = null
        val max = 8
        for (i in 0 until max) {
            if (i % 4 == 0) { val r = LinearLayout(s); grid.addView(r, LinearLayout.LayoutParams(-1, -2)); rl = r }
            val cell = LinearLayout(s); cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(0, dp(6), 0, dp(10))
            val b = FrameLayout(s)
            b.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x26FFFFFF) }
            if (i < list.size) {
                val (pk, nm) = list[i]
                val iv = ImageView(s)
                try { iv.setImageDrawable(s.packageManager.getApplicationIcon(pk)) } catch (_: Exception) {}
                b.addView(iv, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
                cell.addView(b, LinearLayout.LayoutParams(dp(52), dp(52)))
                val lb = TextView(s); lb.text = nm; lb.textSize = 9.5f; lb.maxLines = 1
                lb.ellipsize = TextUtils.TruncateAt.END; lb.setTextColor(0xDDFFFFFF.toInt()); lb.gravity = Gravity.CENTER
                lb.setPadding(0, dp(5), 0, 0)
                cell.addView(lb, LinearLayout.LayoutParams(cellW - dp(4), -2))
                cell.setOnClickListener {
                    buzz()
                    try { s.packageManager.getLaunchIntentForPackage(pk)?.let { s.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } } catch (_: Exception) {}
                    closeAnimated()
                }
            } else if (i == list.size) {
                val iv = ImageView(s); try { iv.setImageDrawable(s.getDrawable(R.drawable.ic_edit)) } catch (_: Exception) {}
                iv.setColorFilter(0xCCFFFFFF.toInt())
                b.addView(iv, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
                cell.addView(b, LinearLayout.LayoutParams(dp(52), dp(52)))
                val lb = TextView(s); lb.text = "Add"; lb.textSize = 9.5f; lb.setTextColor(0xAAFFFFFF.toInt()); lb.gravity = Gravity.CENTER
                lb.setPadding(0, dp(5), 0, 0)
                cell.addView(lb, LinearLayout.LayoutParams(cellW - dp(4), -2))
                cell.setOnClickListener { openApp("4") }
            }
            rl?.addView(cell, LinearLayout.LayoutParams(cellW, -2))
        }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2))
        val hint = TextView(s); hint.text = "Tap an app to open it. Add apps in the Edge tab."
        hint.textSize = 10f; hint.setTextColor(0x77FFFFFF.toInt()); hint.setPadding(dp(2), dp(4), dp(2), 0)
        box.addView(hint)
        return box
    }

    private fun pageActions(): View {
        val box = pageBox()
        box.addView(title("ACTIONS"))
        val grid = LinearLayout(s); grid.orientation = LinearLayout.VERTICAL
        var rl: LinearLayout? = null
        quick.forEachIndexed { i, q ->
            if (i % 2 == 0) { val r = LinearLayout(s); grid.addView(r, LinearLayout.LayoutParams(-1, -2)); rl = r }
            val tile = LinearLayout(s); tile.gravity = Gravity.CENTER_VERTICAL
            tile.setPadding(dp(10), 0, dp(8), 0)
            tile.background = GradientDrawable().apply { cornerRadius = dp(15).toFloat(); setColor(0x1FFFFFFF) }
            val iv = ImageView(s); try { iv.setImageDrawable(s.getDrawable(q.second)) } catch (_: Exception) {}
            iv.setColorFilter(Color.WHITE)
            tile.addView(iv, LinearLayout.LayoutParams(dp(18), dp(18)))
            val lb = TextView(s); lb.text = q.third; lb.textSize = 11.5f; lb.setTextColor(Color.WHITE)
            lb.setPadding(dp(8), 0, 0, 0); lb.maxLines = 1; lb.ellipsize = TextUtils.TruncateAt.END
            tile.addView(lb, LinearLayout.LayoutParams(0, -2, 1f))
            tile.setOnClickListener { buzz(); s.doAct(q.first, "edge"); if (q.first != "timer" && q.first != "pad") closeAnimated() }
            rl?.addView(tile, LinearLayout.LayoutParams(pageW / 2 - dp(3), dp(46)).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    private fun pageCompass(): View {
        val box = pageBox()
        box.addView(title("COMPASS"))
        val cv = CompassView(s); compass = cv
        box.addView(cv, LinearLayout.LayoutParams(min(pageW - dp(8), dp(230)), 0, 1f))
        val hint = TextView(s); hint.text = "Move the phone in a figure 8 to calibrate"
        hint.textSize = 9.5f; hint.setTextColor(0x77FFFFFF.toInt()); hint.gravity = Gravity.CENTER
        hint.setPadding(0, dp(6), 0, dp(4))
        box.addView(hint)
        return box
    }

    private fun pageTools(): View {
        val box = pageBox()
        box.addView(title("TOOLS"))
        // draw pad
        val draw = LinearLayout(s); draw.gravity = Gravity.CENTER; draw.orientation = LinearLayout.VERTICAL
        draw.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1(), (c1() and 0xFFFFFF) or 0xCC000000)).apply {
            cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0x44FFFFFF)
        }
        val dt = TextView(s); dt.text = "✍  Draw to open"; dt.textSize = 14f; dt.setTextColor(Color.WHITE)
        dt.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        dt.gravity = Gravity.CENTER
        draw.addView(dt)
        val ds = TextView(s); ds.text = "C camera · W WhatsApp · ← back"; ds.textSize = 9.5f
        ds.setTextColor(0xCCFFFFFF.toInt()); ds.gravity = Gravity.CENTER; ds.setPadding(0, dp(3), 0, 0)
        draw.addView(ds)
        draw.setOnClickListener { buzz(); closeAnimated(); h.postDelayed({ s.openPad() }, 180) }
        box.addView(draw, LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(10) })

        // timers
        val tl = LinearLayout(s); tl.gravity = Gravity.CENTER_VERTICAL
        tl.addView(title("TIMER"), LinearLayout.LayoutParams(0, -2, 1f))
        val chips = LinearLayout(s)
        listOf(60 to "1", 300 to "5", 600 to "10", 1800 to "30").forEach { (sec, lbl) ->
            val b = TextView(s); b.text = lbl; b.textSize = 11f; b.gravity = Gravity.CENTER
            b.setTextColor(Color.WHITE)
            b.background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0x22FFFFFF) }
            b.setOnClickListener { buzz(); try { s.island.timerStart(sec) } catch (_: Exception) {}; closeAnimated() }
            chips.addView(b, LinearLayout.LayoutParams(dp(34), dp(30)).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        tl.addView(chips)
        box.addView(tl, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val tools = listOf(Triple("stopwatch", R.drawable.ic_timer, "Stopwatch"), Triple("rec", R.drawable.ic_stop, "Record"), Triple("shot", R.drawable.ic_cam, "Capture"))
        val rowT = LinearLayout(s); rowT.gravity = Gravity.CENTER
        tools.forEach { t ->
            val cell = LinearLayout(s); cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0x1FFFFFFF) }
            val iv = ImageView(s); try { iv.setImageDrawable(s.getDrawable(t.second)) } catch (_: Exception) {}
            iv.setColorFilter(Color.WHITE)
            cell.addView(iv, LinearLayout.LayoutParams(dp(20), dp(20)).apply { topMargin = dp(12) })
            val lb = TextView(s); lb.text = t.third; lb.textSize = 10f; lb.setTextColor(0xCCFFFFFF.toInt()); lb.gravity = Gravity.CENTER
            lb.setPadding(0, dp(6), 0, dp(10)); cell.addView(lb)
            cell.setOnClickListener {
                buzz()
                when (t.first) {
                    "stopwatch" -> { try { s.island.swStart() } catch (_: Exception) {}; closeAnimated() }
                    "rec" -> { s.doAct("rec", "edge"); closeAnimated() }
                    else -> { s.doAct("shot", "edge"); closeAnimated() }
                }
            }
            rowT.addView(cell, LinearLayout.LayoutParams(0, dp(72), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        box.addView(rowT, LinearLayout.LayoutParams(-1, -2))

        // time + battery strip
        val strip = LinearLayout(s); strip.gravity = Gravity.CENTER_VERTICAL
        strip.setPadding(dp(4), dp(10), dp(4), 0)
        val t = TextView(s); t.text = "—"; t.textSize = 15f; t.setTextColor(Color.WHITE)
        t.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        timeTv = t; strip.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val b = TextView(s); b.text = ""; b.textSize = 11f; b.setTextColor(0xCCFFFFFF.toInt())
        batTv = b; strip.addView(b)
        box.addView(strip, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    private fun openApp(tab: String) {
        try {
            s.startActivity(Intent(s, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("tab", tab))
        } catch (_: Exception) {}
        closeAnimated()
    }

    // ------------------------------------------------------------------------------------------
    // live bits
    // ------------------------------------------------------------------------------------------
    private fun startTick() {
        stopTick()
        val r = object : Runnable {
            override fun run() {
                timeTv?.text = android.text.format.DateFormat.format(
                    if (android.text.format.DateFormat.is24HourFormat(s)) "HH:mm" else "h:mm", java.util.Date()).toString()
                val b = s.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val pct = (b?.getIntExtra("level", 0) ?: 0) * 100 / maxOf(b?.getIntExtra("scale", 100) ?: 100, 1)
                batTv?.text = "$pct%"
                if (root != null) h.postDelayed(this, 20000)
            }
        }
        tick = r; r.run()
    }

    private fun stopTick() { tick?.let { h.removeCallbacks(it) }; tick = null }

    private fun registerCompass() {
        if (sensReg || compass == null) return
        try {
            val sm = s.getSystemService(SensorManager::class.java)
            val rot = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            if (rot != null) { sm.registerListener(this, rot, SensorManager.SENSOR_DELAY_UI); sensReg = true }
        } catch (_: Exception) {}
    }

    private fun unregisterCompass() {
        if (!sensReg) return
        try { s.getSystemService(SensorManager::class.java).unregisterListener(this) } catch (_: Exception) {}
        sensReg = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type != Sensor.TYPE_ROTATION_VECTOR && e.sensor.type != Sensor.TYPE_GAME_ROTATION_VECTOR) return
        val r = FloatArray(9); val o = FloatArray(3)
        try {
            SensorManager.getRotationMatrixFromVector(r, e.values)
            SensorManager.getOrientation(r, o)
            var deg = Math.toDegrees(o[0].toDouble()).toFloat()
            if (deg < 0) deg += 360f
            compass?.heading = deg
            compass?.invalidate()
        } catch (_: Exception) {}
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // ------------------------------------------------------------------------------------------
    private class CompassView(c: Context) : View(c) {
        var heading = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        override fun onDraw(cv: Canvas) {
            val d = resources.displayMetrics.density
            val w = width.toFloat(); val hgt = height.toFloat()
            val cx = w / 2f; val cy = hgt / 2f
            val rad = min(w, hgt) / 2f - 10 * d
            if (rad <= 0) return
            cv.save(); cv.rotate(-heading, cx, cy)
            // ticks
            for (i in 0 until 72) {
                val major = i % 18 == 0
                val mid = i % 6 == 0
                p.color = if (major) 0xFFFFFFFF.toInt() else if (mid) 0x99FFFFFF.toInt() else 0x44FFFFFF
                p.strokeWidth = (if (major) 2.4f else if (mid) 1.6f else 1f) * d
                val a = Math.toRadians((i * 5).toDouble())
                val sa = sin(a).toFloat(); val ca = cos(a).toFloat()
                val r1 = rad
                val r2 = rad - (if (major) 16 else if (mid) 10 else 6) * d
                cv.drawLine(cx + r1 * sa, cy - r1 * ca, cx + r2 * sa, cy - r2 * ca, p)
            }
            // cardinal letters
            txt.textSize = 13 * d; txt.textAlign = Paint.Align.CENTER
            val cards = listOf("N" to 0f, "E" to 90f, "S" to 180f, "W" to 270f)
            for ((name, ang) in cards) {
                val a = Math.toRadians(ang.toDouble())
                val sa = sin(a).toFloat(); val ca = cos(a).toFloat()
                val rr = rad - 30 * d
                txt.color = if (name == "N") 0xFFFF5A5A.toInt() else 0xCCFFFFFF.toInt()
                cv.drawText(name, cx + rr * sa, cy - rr * ca + 5 * d, txt)
            }
            cv.restore()
            // fixed needle (points up = where you face)
            p.color = c1Blue; p.style = Paint.Style.FILL
            val nw = 5 * d
            cv.drawPath(android.graphics.Path().apply {
                moveTo(cx, cy - rad + 2 * d); lineTo(cx - nw, cy - rad + 20 * d); lineTo(cx + nw, cy - rad + 20 * d); close()
            }, p)
            // centre readout
            rect.set(cx - rad * 0.62f, cy - rad * 0.62f, cx + rad * 0.62f, cy + rad * 0.62f)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.2f * d; p.color = c1Blue
            cv.drawCircle(cx, cy, rad * 0.62f, p)
            txt.color = Color.WHITE; txt.textSize = 30 * d; txt.textAlign = Paint.Align.CENTER
            txt.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
            cv.drawText("${heading.toInt()}°", cx, cy + 10 * d, txt)
            txt.textSize = 10 * d; txt.color = 0x99FFFFFF.toInt()
            cv.drawText(dirName(heading), cx, cy + 26 * d, txt)
            txt.typeface = null
        }

        private fun dirName(h: Float): String {
            val names = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
            return names[(((h + 22.5f) % 360f) / 45f).toInt() % 8]
        }

        companion object { val c1Blue = 0xFF2F7BFF.toInt() }
    }
}
