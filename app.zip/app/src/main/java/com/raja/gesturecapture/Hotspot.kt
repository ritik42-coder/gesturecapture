package com.raja.gesturecapture

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import java.io.File
import java.lang.reflect.Proxy
import java.net.NetworkInterface
import java.util.Collections

// Watches the phone's Wi-Fi hotspot: on/off and the devices connected to it.
// Android never gives apps the device names, only MAC addresses, so names are nicknames the user sets in the app.
class HotspotWatcher(private val ctx: Context, private val h: Handler, private val changed: () -> Unit) {
    private val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
    private var started = false

    var on = false

        private set
    var clients: List<String> = emptyList()
        private set
    var supported = false // true when Android lets this app read the client list
        private set
    private var demo = false

    // WifiManager.SoftApCallback / WifiClient are system (hidden) APIs, so they cannot be referenced at compile time.
    // We reach them through reflection; if the phone refuses, we fall back to polling.
    private var cb: Any? = null

    private fun makeCallback(): Any? = try {
        val cls = Class.forName("android.net.wifi.WifiManager\$SoftApCallback")
        Proxy.newProxyInstance(cls.classLoader, arrayOf(cls)) { proxy, m, args ->
            var result: Any? = null
            when (m.name) {
                "onStateChanged" -> if (!demo) {
                    val state = (args?.getOrNull(0) as? Int) ?: 0
                    on = state == 13 // WIFI_AP_STATE_ENABLED
                    if (!on) clients = emptyList()
                    changed()
                }
                "onConnectedClientsChanged" -> if (!demo) {
                    val list = args?.getOrNull(0) as? List<*> ?: emptyList<Any>()
                    clients = list.mapNotNull { c ->
                        try { c!!.javaClass.getMethod("getMacAddress").invoke(c)?.toString() } catch (_: Exception) { null }
                    }
                    changed()
                }
                "hashCode" -> result = System.identityHashCode(proxy)
                "equals" -> result = proxy === args?.getOrNull(0)
                "toString" -> result = "SoftApCallbackProxy"
            }
            result
        }
    } catch (_: Throwable) { null }

    private val poll = object : Runnable {
        override fun run() {
            if (!started) return
            val now = ifaceOn()
            if (!demo) {
                val c = if (now) arpClients() else emptyList()
                if (now != on || (!supported && c != clients)) { on = now; clients = if (supported) (if (now) clients else emptyList()) else c; changed() }
            }
            h.postDelayed(this, 4000)
        }
    }

    // hotspot on/off broadcast (works without any permission) -> re-check the network interface right away
    private val apRcv = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: Context, i: android.content.Intent) { h.postDelayed({ checkNow() }, 600) }
    }
    private var apReg = false

    private fun checkNow() {
        if (!started || demo) return
        val now = ifaceOn()
        val c = if (now) arpClients() else emptyList()
        if (now != on || (!supported && c != clients)) { on = now; if (!supported) clients = c; changed() }
    }

    private fun tryRegister() {
        supported = try {
            val c = makeCallback() ?: throw IllegalStateException()
            val m = WifiManager::class.java.getMethod("registerSoftApCallback", java.util.concurrent.Executor::class.java, Class.forName("android.net.wifi.WifiManager\$SoftApCallback"))
            m.invoke(wm, ctx.mainExecutor, c)
            cb = c
            true
        } catch (_: Throwable) { false }
    }

    fun start() {
        if (started) { if (!supported) tryRegister(); return }   // retry after a permission was just granted
        started = true
        if (!apReg) try {
            ctx.registerReceiver(apRcv, android.content.IntentFilter("android.net.wifi.WIFI_AP_STATE_CHANGED")); apReg = true
        } catch (_: Exception) {}
        tryRegister()
        // always poll (cheap): catches on/off even when the callback is not allowed, and keeps the state right if it stops firing
        h.post(poll)
    }

    fun stop() {
        try {
            cb?.let { WifiManager::class.java.getMethod("unregisterSoftApCallback", Class.forName("android.net.wifi.WifiManager\$SoftApCallback")).invoke(wm, it) }
        } catch (_: Throwable) {}
        cb = null
        h.removeCallbacks(poll)
        if (apReg) { try { ctx.unregisterReceiver(apRcv) } catch (_: Exception) {}; apReg = false }
        started = false; supported = false; on = false; clients = emptyList()
    }

    // fallback when the callback is not allowed: look for the hotspot's network interface
    private fun ifaceOn(): Boolean = try {
        Collections.list(NetworkInterface.getNetworkInterfaces()).any { ni ->
            val n = ni.name ?: ""
            (n.startsWith("ap") || n.startsWith("swlan") || n == "wlan1") && ni.isUp && ni.inetAddresses.hasMoreElements()
        }
    } catch (_: Exception) { false }

    // best-effort list of connected devices (MAC addresses) from the ARP table; may be empty on newer Android
    private fun arpClients(): List<String> = try {
        File("/proc/net/arp").readLines().drop(1).mapNotNull { l ->
            val p = l.trim().split(Regex("\\s+"))
            if (p.size >= 6 && p[2] != "0x0" && p[3] != "00:00:00:00:00:00" &&
                (p[5].startsWith("ap") || p[5].startsWith("swlan") || p[5] == "wlan1")) p[3] else null
        }.distinct()
    } catch (_: Exception) { emptyList() }

    fun count() = clients.size

    fun startDemo() {
        val so = on; val sc = clients; val ss = supported
        demo = true; on = true; supported = true
        clients = listOf("a4:5e:60:11:c2:9d", "3c:22:fb:7a:05:e1", "f0:18:98:42:bb:36")
        changed()
        h.postDelayed({ demo = false; on = so; clients = sc; supported = ss; changed() }, 7000)
    }
}
