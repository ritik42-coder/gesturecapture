package com.raja.gesturecapture

import android.content.Context
import android.net.wifi.WifiClient
import android.net.wifi.WifiManager
import android.os.Handler
import java.net.NetworkInterface
import java.util.Collections

// Watches the phone's Wi-Fi hotspot: on/off and the devices connected to it.
// Android never gives apps the device names, only MAC addresses, so names are nicknames the user sets in the app.
class HotspotWatcher(private val ctx: Context, private val h: Handler, private val changed: () -> Unit) {
    private val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
    private var started = false

    var on = false

        private set
    var clients: List<String> = emptyList()
        private set
    var supported = false // true when Android lets this app read the client list
        private set
    private var demo = false

    private val cb = object : WifiManager.SoftApCallback {
        override fun onStateChanged(state: Int, failureReason: Int) {
            if (demo) return
            on = state == WifiManager.WIFI_AP_STATE_ENABLED
            if (!on) clients = emptyList()
            changed()
        }
        override fun onConnectedClientsChanged(c: MutableList<WifiClient>) {
            if (demo) return
            clients = c.map { it.macAddress.toString() }
            changed()
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (!started) return
            val now = ifaceOn()
            if (now != on && !demo) { on = now; if (!now) clients = emptyList(); changed() }
            h.postDelayed(this, 4000)
        }
    }

    fun start() {
        if (started) return
        started = true
        supported = try { wm.registerSoftApCallback(ctx.mainExecutor, cb); true } catch (_: Exception) { false }
        if (!supported) h.post(poll)
    }

    fun stop() {
        try { wm.unregisterSoftApCallback(cb) } catch (_: Exception) {}
        h.removeCallbacks(poll)
        started = false; supported = false; on = false; clients = emptyList()
    }

    // fallback when the callback is not allowed: look for the hotspot's network interface
    private fun ifaceOn(): Boolean = try {
        Collections.list(NetworkInterface.getNetworkInterfaces()).any { ni ->
            val n = ni.name ?: ""
            (n.startsWith("ap") || n.startsWith("swlan") || n == "wlan1") && ni.isUp && ni.inetAddresses.hasMoreElements()
        }
    } catch (_: Exception) { false }

    fun count() = clients.size

    fun startDemo() {
        val so = on; val sc = clients; val ss = supported
        demo = true; on = true; supported = true
        clients = listOf("a4:5e:60:11:c2:9d", "3c:22:fb:7a:05:e1", "f0:18:98:42:bb:36")
        changed()
        h.postDelayed({ demo = false; on = so; clients = sc; supported = ss; changed() }, 7000)
    }
}
