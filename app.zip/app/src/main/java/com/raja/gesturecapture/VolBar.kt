package com.raja.gesturecapture

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * Custom volume bar with 12 animated styles:
 *  0 Water, 1 RGB Neon, 2 Red Pill, 3 Equalizer, 4 Lava, 5 Aurora Glass, 6 Candy, 7 Plasma Flow,
 *  8 Neon Dial, 9 Liquid Orb, 10 Activity Rings, 11 Orbit
 * vm: "default" = system panel only, "mine" = my bar replaces it, "both" = system + mine
 */

private val VPAL = arrayOf(
    intArrayOf(0xFF22D3EE.toInt(), 0xFF2563EB.toInt()),
    intArrayOf(0xFFFF5F6D.toInt(), 0xFFFFC371.toInt()),
    intArrayOf(0xFFA855F7.toInt(), 0xFFEC4899.toInt()),
    intArrayOf(0xFF34D399.toInt(), 0xFF0891B2.toInt()),
    intArrayOf(0xFFFF3B30.toInt(), 0xFF7A0D0D.toInt()),
    intArrayOf(0xFFFACC15.toInt(), 0xFFF97316.toInt())
)

private fun pc(x: String): Int = try { Color.parseColor(x) } catch (_: Exception) { Color.CYAN }

private fun ca(c: Int, a: Float): Int = (c and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).roundToInt() shl 24)

private fun hsl(h: Float, s: Float, l: Float): Int {
    val v = l + s * min(l, 1f - l)
    val sv = if (v == 0f) 0f else 2f * (1f - l / v)
    return Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, sv, v))
}

internal class VCfg(j: JSONObject) {
    val st: Int = run {
        val o = j.opt("st")
        val n = when (o) {
            is Number -> o.toInt()
            is String -> when (o) { "vertical" -> 0; "pill" -> 2; "bubble" -> 9; else -> o.toIntOrNull() ?: 0 }
            else -> 0
        }
        n.coerceIn(0, 11)
    }
    val pos: String = run {
        var p = j.optString("pos", "")
        if (p.isEmpty()) p = if (j.optString("st", "") == "pill") "top" else j.optString("side", "right")
        if (p == "left" || p == "right" || p == "center" || p == "top" || p == "bottom") p else "right"
    }
    val pal: Int = if (j.has("pal")) j.optInt("pal", 0).coerceIn(0, 6)
    else when (j.optString("color", "")) { "sunset" -> 1; "mint" -> 3; "accent" -> 6; else -> 0 }
    val rgb: Boolean = j.optBoolean("rgb", false)
    val grad: Boolean = j.optBoolean("grad", true)
    val cust: Boolean = j.optBoolean("cust", false)
    val c1: String = j.optString("c1", "#22d3ee")
    val c2: String = j.optString("c2", "#a855f7")
    val ac1: String = j.optString("ac1", "#6366f1")
    val ac2: String = j.optString("ac2", "#a855f7")
    val sz: Float = j.optDouble("sz", 100.0).toFloat().coerceIn(50f, 160f)
    val dur: Long = j.optInt("dur", 18).coerceIn(5, 60) * 100L
    val speed: Float = j.optDouble("speed", 1.0).toFloat().coerceIn(0.2f, 3f)
    val glow: Float = j.optDouble("glow", 1.0).toFloat().coerceIn(0f, 3f)
    val rn: Float = j.optDouble("rn", 1.0).toFloat().coerceIn(0.2f, 1.6f)
    val alpha: Float = j.optInt("op", 100).coerceIn(30, 100) / 100f
    val dark: Boolean = j.optBoolean("dark", true)
    val haptic: Boolean = j.optBoolean("haptic", true)
    val pct: Boolean = j.optBoolean("pct", true)
    val gap: Float = if (j.has("gap")) j.optDouble("gap", 8.0).toFloat().coerceIn(0f, 200f)
    else when (pos) { "top" -> 56f; "bottom" -> 72f; else -> 8f }
}

internal class StyleView(c: Context, val cfg: VCfg) : View(c) {
    private val d = c.resources.displayMetrics.density
    val sc = d * cfg.sz / 100f

    // layout in logical (dp-like) units
    private val circ = cfg.st >= 8
    private val horiz = !circ && (cfg.pos == "top" || cfg.pos == "bottom")
    private val barW = if (circ) 138f else if (horiz) 60f else 64f
    private val barL = if (circ) 138f else if (horiz) 236f else 224f
    private val lab = if (circ || !cfg.pct) 0f else if (horiz) 44f else 22f
    private val pp = if (circ) 8f else 10f
    val pad = 18f
    private val panelW = if (horiz) barL + lab + 2 * pp else barW + 2 * pp
    private val panelH = if (horiz) barW + 2 * pp else barL + lab + 2 * pp
    val winW = ceil((panelW + 2 * pad) * sc).toInt()
    val winH = ceil((panelH + 2 * pad) * sc).toInt()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val maskMode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    private val addMode = PorterDuffXfermode(PorterDuff.Mode.ADD)

    private val icV = c.getDrawable(R.drawable.ic_vol)?.mutate()
    private val icM = c.getDrawable(R.drawable.ic_mute)?.mutate()
    private val icB = c.getDrawable(R.drawable.ic_bell)?.mutate()
    private val icC = c.getDrawable(R.drawable.ic_call)?.mutate()

    // state
    private var target = 0f
    private var disp = 0f
    private var dv = 0f
    private var vel = 0f
    private var muted = false
    private var streamKind = 3
    private var tm = 0f
    private var accum = 0f
    private val bub = ArrayList<FloatArray>()
    private var attached = false
    private var last = 0L

    var onSet: ((Float) -> Unit)? = null
    var onTouch: ((Boolean) -> Unit)? = null

    fun setLevel(l: Float, m: Boolean, stream: Int) { target = l.coerceIn(0f, 1f); muted = m; streamKind = stream }

    private val ticker = object : Runnable {
        override fun run() {
            if (!attached) return
            val now = System.nanoTime()
            val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1_000_000_000f)
            last = now
            update(dt)
            invalidate()
            postOnAnimation(this)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); attached = true; last = 0L; postOnAnimation(ticker) }
    override fun onDetachedFromWindow() { attached = false; removeCallbacks(ticker); super.onDetachedFromWindow() }

    private fun update(dt: Float) {
        accum += dt * 60f
        val tg = if (muted) 0f else target
        var n = 0
        while (accum >= 1f && n < 8) {
            accum -= 1f; n++
            dv += (tg - disp) * 0.2f; dv *= 0.7f; disp += dv
            vel += (abs(dv) - vel) * 0.15f
        }
        if (accum > 3f) accum = 0f
        tm += dt * cfg.speed
        if (cfg.st == 0) {
            val v = disp.coerceIn(0f, 1f)
            if (v > 0.004f) {
                if (Math.random() < 0.09 * dt * 60) {
                    bub.add(floatArrayOf(8f + Math.random().toFloat() * (barW - 16f), barL, 1.5f + Math.random().toFloat() * 3f, 0.4f + Math.random().toFloat() * 0.9f))
                }
                val top = barL - v * barL
                val iter = bub.iterator()
                while (iter.hasNext()) {
                    val b = iter.next()
                    b[1] -= b[3] * dt * 60f
                    b[0] += sin(b[1] * 0.08f) * 0.3f
                    if (b[1] <= top + 6f) iter.remove()
                }
            } else bub.clear()
        }
    }

    // ---------- touch ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> onTouch?.invoke(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { onTouch?.invoke(false); return true }
        }
        val x = e.x / sc - pad - pp
        val y = e.y / sc - pad - pp
        val f: Float
        if (circ) {
            val c0 = barW / 2f
            var r = (atan2(y - c0, x - c0) + 6.2832f) % 6.2832f
            r = (r - 2.356f + 6.2832f) % 6.2832f
            f = if (r > 4.712f) (if (r < 5.498f) 1f else 0f) else r / 4.712f
        } else {
            val ly = if (horiz) barL - x else y
            f = if (cfg.st == 1) 1f - (ly - 24f) / (barL - 84f) else 1f - ly / barL
        }
        onSet?.invoke(f.coerceIn(0f, 1f))
        return true
    }

    // ---------- paint helpers ----------
    private fun fillP(col: Int): Paint { p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = col; return p }
    private fun strokeP(col: Int, w: Float): Paint {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND; p.color = col; return p
    }
    private fun lg(x0: Float, y0: Float, x1: Float, y1: Float, c0: Int, c1: Int) =
        LinearGradient(x0, y0, x1, y1, c0, c1, Shader.TileMode.CLAMP)
    private fun rad(r: Float, w: Float, h: Float) = min(r * cfg.rn, min(w, h) / 2f)
    private fun glowSh(pt: Paint, col: Int, blur: Float) { if (cfg.glow > 0.02f) pt.setShadowLayer(blur * cfg.glow * sc, 0f, 0f, col) }

    private fun glowRR(cv: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float, col: Int) {
        val g = cfg.glow
        if (g <= 0.02f) return
        for (i in 1..4) {
            val e = i * 1.6f * g
            cv.drawRoundRect(x - e, y - e, x + w + e, y + h + e, r + e, r + e, strokeP(ca(col, min(0.34f * g / i, 0.5f)), 1.7f * g + 0.6f))
        }
    }

    private fun masked(cv: Canvas, x: Float, y: Float, w: Float, h: Float, r: Float, body: () -> Unit) {
        val s = cv.saveLayer(x, y, x + w, y + h, null)
        body()
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = Color.WHITE; p.xfermode = maskMode
        cv.drawRoundRect(x, y, x + w, y + h, r, r, p)
        p.xfermode = null
        cv.restoreToCount(s)
    }

    private fun acc(t: Float): IntArray {
        if (cfg.cust) { val x = pc(cfg.c1); return if (cfg.grad) intArrayOf(x, pc(cfg.c2)) else intArrayOf(x, x) }
        if (cfg.rgb) { val h = (t * 55f) % 360f; return intArrayOf(hsl(h, 0.92f, 0.62f), hsl(h + 75f, 0.92f, 0.55f)) }
        val pr = if (cfg.pal >= 6) intArrayOf(pc(cfg.ac1), pc(cfg.ac2)) else VPAL[cfg.pal]
        return if (cfg.grad) pr else intArrayOf(pr[0], pr[0])
    }

    private fun icon(cv: Canvas, x: Float, y: Float, col: Int) {
        val dr = (if (muted || target <= 0.001f) icM else when (streamKind) { 0 -> icC; 2 -> icB; else -> icV }) ?: return
        val hs = (10f * sc).roundToInt()
        dr.setBounds(-hs, -hs, hs, hs)
        dr.setTint(col)
        cv.save()
        cv.translate(x, y)
        if (horiz && !circ) cv.rotate(-90f)
        cv.scale(1f / sc, 1f / sc)
        dr.draw(cv)
        cv.restore()
    }

    // ---------- draw ----------
    override fun onDraw(cv: Canvas) {
        val v = (if (muted) 0f else disp).coerceIn(0f, 1f)
        val a = acc(tm)
        cv.save()
        cv.scale(sc, sc)
        drawPanel(cv)
        cv.save()
        cv.translate(pad + pp, pad + pp)
        if (circ) drawDial(cv, v, tm, a)
        else {
            if (horiz) { cv.translate(barL, 0f); cv.rotate(90f) }
            drawBar(cv, barW, barL, v, tm, a)
        }
        cv.restore()
        drawLabel(cv, v)
        cv.restore()
    }

    private fun drawPanel(cv: Canvas) {
        val dk = cfg.dark
        val r = min(26f * max(cfg.rn, 0.35f), min(panelW, panelH) / 2f)
        for (i in 3 downTo 1) {
            val e = i * 2.5f
            cv.drawRoundRect(pad - e, pad - e + 3f, pad + panelW + e, pad + panelH + e + 3f, r + e, r + e,
                fillP(Color.argb(if (dk) 22 else 12, 0, 0, 0)))
        }
        cv.drawRoundRect(pad, pad, pad + panelW, pad + panelH, r, r, fillP(if (dk) 0xA8141828.toInt() else 0xB8FFFFFF.toInt()))
        cv.drawRoundRect(pad, pad, pad + panelW, pad + panelH, r, r, strokeP(if (dk) 0x21FFFFFF else 0x1A000000, 1f))
    }

    private fun drawLabel(cv: Canvas, v: Float) {
        if (lab <= 0f) return
        tp.reset(); tp.isAntiAlias = true
        tp.color = if (cfg.dark) 0xCCFFFFFF.toInt() else 0xCC141A2E.toInt()
        tp.textAlign = Paint.Align.CENTER; tp.typeface = Typeface.DEFAULT_BOLD; tp.textSize = 13f
        val fm = tp.fontMetrics
        val cx: Float
        val cy: Float
        if (horiz) { cx = pad + pp + barL + lab / 2f; cy = pad + pp + barW / 2f }
        else { cx = pad + pp + barW / 2f; cy = pad + pp + barL + lab / 2f }
        cv.drawText((v * 100f).roundToInt().toString(), cx, cy - (fm.ascent + fm.descent) / 2f, tp)
    }

    private fun drawBar(cv: Canvas, w: Float, h: Float, v: Float, t: Float, a: IntArray) {
        val dk = cfg.dark
        val track = if (dk) 0x17FFFFFF else 0x17000000
        val base = if (dk) Color.WHITE else 0xFF3A4366.toInt()
        var iy = h - 30f
        var ic = base
        when (cfg.st) {
            0 -> { // Water
                val r = rad(20f, w, h)
                glowRR(cv, 0f, 0f, w, h, r, a[0])
                cv.drawRoundRect(0f, 0f, w, h, r, r, fillP(track))
                val top = h - v * h
                val amp = 3f + vel * 45f
                if (v > 0.004f) {
                    masked(cv, 0f, 0f, w, h, r) {
                        for (L in 0..1) {
                            path.reset(); path.moveTo(0f, h)
                            var x = 0f
                            while (x <= w) {
                                path.lineTo(x, top + sin(x * 0.12f + t * (2.2f + L * 1.4f) + L * 2.2f) * amp * (if (L == 1) 1f else 0.7f) + (if (L == 1) 0f else 3f))
                                x += 3f
                            }
                            path.lineTo(w, h); path.close()
                            val fp = fillP(Color.WHITE)
                            fp.shader = lg(0f, top - amp, 0f, h, a[0], a[1])
                            fp.alpha = if (L == 1) 255 else 128
                            cv.drawPath(path, fp)
                        }
                        val bp = fillP(0x73FFFFFF)
                        for (b in bub) cv.drawCircle(b[0], b[1], b[2], bp)
                        cv.drawRect(9f, top + 10f, 14f, top + 10f + max(0f, h - top - 56f), fillP(0x33FFFFFF))
                    }
                }
                if (v * h > 46f) ic = Color.WHITE
            }
            1 -> { // RGB Neon
                val r = rad(20f, w, h)
                cv.drawRoundRect(1.5f, 1.5f, w - 1.5f, h - 1.5f, r, r, fillP(if (dk) 0x80000000.toInt() else 0x99FFFFFF.toInt()))
                val cols = intArrayOf(0xFFFF2D95.toInt(), 0xFFFFD400.toInt(), 0xFF2DFF7A.toInt(), 0xFF22D3EE.toInt(), 0xFF6366F1.toInt(), 0xFFFF2D95.toInt())
                val sw = SweepGradient(w / 2f, h / 2f, cols, null)
                val m = Matrix()
                m.setRotate(t * 1.3f * 57.29578f, w / 2f, h / 2f)
                sw.setLocalMatrix(m)
                val bp = strokeP(Color.WHITE, 2.6f)
                bp.shader = sw
                glowSh(bp, 0xCC78A0FF.toInt(), 12f)
                cv.drawRoundRect(1.5f, 1.5f, w - 1.5f, h - 1.5f, r, r, bp)
                val y0 = 24f
                val y1 = h - 60f
                val ty = y0 + (1f - v) * (y1 - y0)
                cv.drawLine(w / 2f, y0, w / 2f, y1, strokeP(if (dk) 0x26FFFFFF else 0x26000000, 3f))
                if (v > 0.004f) {
                    val lp = strokeP(Color.WHITE, 3f)
                    lp.shader = lg(0f, ty, 0f, y1, a[0], a[1])
                    glowSh(lp, a[0], 10f)
                    cv.drawLine(w / 2f, ty, w / 2f, y1, lp)
                }
                val kp = fillP(a[0])
                glowSh(kp, a[0], 12f)
                cv.drawCircle(w / 2f, ty, 9f + sin(t * 5f) * 0.9f, kp)
                cv.drawCircle(w / 2f, ty, 3.5f, fillP(0xE6FFFFFF.toInt()))
            }
            2, 6 -> { // Red Pill / Candy
                val r = rad(w / 2.2f, w, h)
                glowRR(cv, 0f, 0f, w, h, r, a[0])
                cv.drawRoundRect(0f, 0f, w, h, r, r, fillP(if (cfg.st == 2) ca(a[1], 0.25f) else track))
                val ph = max(w - 8f, v * (h - 8f))
                val py = h - 4f - ph
                val rr = rad((w - 8f) / 2f, w - 8f, ph)
                masked(cv, 4f, py, w - 8f, ph, rr) {
                    val fp = fillP(Color.WHITE)
                    fp.shader = lg(0f, py, 0f, h, a[0], a[1])
                    cv.drawRect(4f, py, w - 4f, py + ph, fp)
                    if (cfg.st == 6) {
                        val o = (t * 28f) % 44f
                        var kx = -h - 44f
                        while (kx < w) {
                            path.reset()
                            path.moveTo(kx + o, h); path.lineTo(kx + o + 20f, h)
                            path.lineTo(kx + o + 20f + h, py); path.lineTo(kx + o + h, py)
                            path.close()
                            cv.drawPath(path, fillP(0x33FFFFFF))
                            kx += 44f
                        }
                    }
                    val gp = fillP(Color.WHITE)
                    gp.shader = LinearGradient(4f, 0f, w, 0f, intArrayOf(0x4DFFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.4f), Shader.TileMode.CLAMP)
                    cv.drawRect(4f, py, w, py + ph, gp)
                }
                iy = py + 4f + (w - 8f) / 2f
                ic = Color.WHITE
            }
            3 -> { // Equalizer
                val r = rad(18f, w, h)
                glowRR(cv, 0f, 0f, w, h, r, a[0])
                cv.drawRoundRect(0f, 0f, w, h, r, r, fillP(track))
                val n = 14
                val sh = (h - 52f - (n - 1) * 4f) / n
                val gp = Paint(Paint.ANTI_ALIAS_FLAG)
                gp.shader = lg(0f, 42f, 0f, h - 10f, a[0], a[1])
                val up = Paint(Paint.ANTI_ALIAS_FLAG)
                up.color = base
                up.alpha = 31
                val sr = rad(4f, w - 18f, sh)
                for (k in 0 until n) {
                    val y = h - 10f - (k + 1) * sh - k * 4f
                    if (v * n > k) {
                        gp.alpha = ((0.82f + 0.18f * sin(t * 7f + k * 0.8f)) * 255f).roundToInt().coerceIn(0, 255)
                        cv.drawRoundRect(9f, y, w - 9f, y + sh, sr, sr, gp)
                    } else cv.drawRoundRect(9f, y, w - 9f, y + sh, sr, sr, up)
                }
                iy = 22f
            }
            4 -> { // Lava
                val r = rad(20f, w, h)
                glowRR(cv, 0f, 0f, w, h, r, a[0])
                cv.drawRoundRect(0f, 0f, w, h, r, r, fillP(track))
                val top = h - v * h
                if (v > 0.004f) {
                    masked(cv, 0f, 0f, w, h, r) {
                        val fp = Paint(Paint.ANTI_ALIAS_FLAG)
                        fp.shader = lg(0f, top, 0f, h, a[0], a[1])
                        path.reset(); path.moveTo(0f, h)
                        var x = 0f
                        while (x <= w) { path.lineTo(x, top + sin(x * 0.09f + t * 1.4f) * 3f); x += 4f }
                        path.lineTo(w, h); path.close()
                        cv.drawPath(path, fp)
                        for (k in 0..2) {
                            val bx = w / 2f + sin(t * 0.9f + k * 2.1f) * w * 0.3f
                            val by = top - 1f + sin(t * 1.3f + k * 1.7f) * 5f
                            val br = 8f + k * 2f + sin(t * 2f + k) * 2f
                            cv.drawCircle(bx, by, br, fp)
                        }
                        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
                        lp.xfermode = addMode
                        for (k in 0..4) {
                            val y = h + 20f - ((t * (22f + k * 8f) + k * 53f) % (h + 40f))
                            val x2 = w / 2f + sin(t * 0.7f + k * 1.9f) * w * 0.28f
                            val gr = 10f + k * 2f
                            if (y > top + 8f) {
                                lp.shader = RadialGradient(x2, y, gr, 0x80FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
                                cv.drawCircle(x2, y, gr, lp)
                            }
                        }
                    }
                }
                if (v * h > 46f) ic = Color.WHITE
            }
            5 -> { // Aurora Glass
                val r = rad(22f, w, h)
                glowRR(cv, 0f, 0f, w, h, r, a[0])
                cv.drawRoundRect(0.5f, 0.5f, w - 0.5f, h - 0.5f, r, r, fillP(track))
                cv.drawRoundRect(0.5f, 0.5f, w - 0.5f, h - 0.5f, r, r, strokeP(0x40FFFFFF, 1f))
                val top = h - v * h
                masked(cv, 0f, 0f, w, h, r) {
                    if (v > 0.004f) {
                        val ap = Paint(Paint.ANTI_ALIAS_FLAG)
                        ap.alpha = 140
                        for (b in 0..2) {
                            val gy0 = top + sin(t * 0.9f + b * 2f) * 40f
                            val gy1 = h + cos(t * 0.7f + b) * 60f
                            ap.shader = LinearGradient(0f, gy0, w * 1.5f, gy1, intArrayOf(a[0], a[1], a[0]), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                            cv.drawRect(0f, top + b * 3f, w, top + b * 3f + h, ap)
                        }
                        val tg = Paint(Paint.ANTI_ALIAS_FLAG)
                        tg.shader = lg(0f, top, 0f, top + 26f, 0xA6FFFFFF.toInt(), 0x00FFFFFF)
                        cv.drawRect(0f, top, w, top + 26f, tg)
                    }
                    val gl = Paint(Paint.ANTI_ALIAS_FLAG)
                    gl.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(0x4DFFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.35f), Shader.TileMode.CLAMP)
                    cv.drawRect(0f, 0f, w, h, gl)
                }
                if (v * h > 46f) ic = Color.WHITE
            }
            7 -> { // Plasma Flow
                val r = rad(20f, w, h)
                glowRR(cv, 0f, 0f, w, h, r, a[0])
                cv.drawRoundRect(0f, 0f, w, h, r, r, fillP(track))
                val top = h - v * h
                if (v > 0.004f) {
                    masked(cv, 0f, 0f, w, h, r) {
                        cv.save()
                        cv.clipRect(0f, top, w, h)
                        cv.drawRect(0f, top, w, h, fillP(ca(a[1], 0.5f)))
                        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
                        lp.xfermode = addMode
                        for (k in 0..4) {
                            val x = w / 2f + sin(t * (0.9f + k * 0.3f) + k * 2f) * w * 0.45f
                            val y = h / 2f + cos(t * (0.7f + k * 0.25f) + k * 1.3f) * h * 0.45f
                            val pr = w * (0.8f + 0.3f * sin(t + k))
                            lp.shader = RadialGradient(x, y, pr, ca(if (k % 2 == 1) a[0] else a[1], 0.85f), ca(a[0], 0f), Shader.TileMode.CLAMP)
                            cv.drawRect(0f, top, w, h, lp)
                        }
                        cv.restore()
                        cv.drawRect(0f, top, w, top + 2f, fillP(0xBFFFFFFF.toInt()))
                    }
                }
                ic = if (v * h > 46f) Color.WHITE else base
            }
        }
        icon(cv, w / 2f, iy, ic)
    }

    private fun arc(cv: Canvas, cx: Float, r: Float, start: Float, sweep: Float, pt: Paint) {
        cv.drawArc(cx - r, cx - r, cx + r, cx + r, start, sweep, false, pt)
    }

    private fun drawDial(cv: Canvas, v: Float, t: Float, a: IntArray) {
        val w = barW
        val m = cfg.st - 8
        val cx = w / 2f
        val dk = cfg.dark
        val rr = cx - 18f
        val a0 = 2.3562f
        val sw = 4.7124f
        val an = a0 + v * sw
        val ink = if (dk) Color.WHITE else 0xFF141A2E.toInt()
        val dim = if (dk) 0x1FFFFFFF else 0x1A000000
        when (m) {
            0 -> { // Neon Dial
                arc(cv, cx, rr, 135f, 270f, strokeP(dim, 10f))
                if (v > 0.004f) {
                    val gp = strokeP(Color.WHITE, 10f)
                    gp.shader = lg(0f, w, w, 0f, a[0], a[1])
                    glowSh(gp, a[0], 14f)
                    arc(cv, cx, rr, 135f, v * 270f, gp)
                }
                for (k in 0..26) {
                    val q = a0 + k / 26f * sw
                    val lit = k / 26f <= v
                    val col = if (lit) ca(a[k % 2], 0.55f + 0.45f * sin(t * 6f + k)) else dim
                    cv.drawLine(cx + cos(q) * (rr + 9f), cx + sin(q) * (rr + 9f), cx + cos(q) * (rr + 13f), cx + sin(q) * (rr + 13f), strokeP(col, 2f))
                }
                val kp = fillP(Color.WHITE)
                glowSh(kp, a[0], 12f)
                cv.drawCircle(cx + cos(an) * rr, cx + sin(an) * rr, 7f, kp)
            }
            1 -> { // Liquid Orb
                val r = rr + 8f
                val top = cx + r - v * 2f * r
                val amp = 3f + vel * 40f
                glowRR(cv, cx - r, cx - r, 2f * r, 2f * r, r, a[0])
                masked(cv, cx - r, cx - r, 2f * r, 2f * r, r) {
                    cv.drawRect(0f, 0f, w, w, fillP(dim))
                    if (v > 0.004f) {
                        for (L in 0..1) {
                            path.reset(); path.moveTo(0f, w)
                            var x = 0f
                            while (x <= w) {
                                path.lineTo(x, top + sin(x * 0.07f + t * (2f + L * 1.3f) + L * 2f) * amp * (if (L == 1) 1f else 0.7f))
                                x += 3f
                            }
                            path.lineTo(w, w); path.close()
                            val fp = fillP(Color.WHITE)
                            fp.shader = lg(0f, top - amp, 0f, cx + r, a[0], a[1])
                            fp.alpha = if (L == 1) 255 else 128
                            cv.drawPath(path, fp)
                        }
                    }
                    val ex = cx - r * 0.35f
                    val ey = cx - r * 0.45f
                    cv.save()
                    cv.rotate(-34.4f, ex, ey)
                    cv.drawOval(ex - r * 0.28f, ey - r * 0.14f, ex + r * 0.28f, ey + r * 0.14f, fillP(0x2EFFFFFF))
                    cv.restore()
                }
                val rp = strokeP(Color.WHITE, 3f)
                rp.shader = lg(0f, 0f, 0f, w, a[0], a[1])
                cv.drawCircle(cx, cx, r, rp)
            }
            2 -> { // Activity Rings
                for (k in 0..4) {
                    val r = rr * (0.3f + k * 0.185f) + 4f
                    val f = (v * 5f - k).coerceIn(0f, 1f)
                    arc(cv, cx, r, 0f, 360f, strokeP(dim, 7f))
                    if (f > 0.003f) {
                        val rp = strokeP(ca(a[k % 2], 0.95f), 7f)
                        glowSh(rp, a[0], 8f)
                        arc(cv, cx, r, -90f, f * 360f, rp)
                    }
                }
                val pr = (t * 0.7f) % 1f
                cv.drawCircle(cx, cx, max(1f, pr * (rr + 8f)), strokeP(ca(a[0], 0.5f * (1f - pr)), 2f))
            }
            else -> { // Orbit
                arc(cv, cx, rr, 0f, 360f, strokeP(dim, 1.5f))
                if (v > 0.01f) {
                    for (k in 0 until 36) {
                        arc(cv, cx, rr, 135f + k / 36f * v * 270f, v * 270f / 36f + 0.6f, strokeP(ca(a[0], k / 36f * 0.9f), 1f + 5f * k / 36f))
                    }
                }
                val px = cx + cos(an) * rr
                val py = cx + sin(an) * rr
                val gp = fillP(Color.WHITE)
                gp.shader = RadialGradient(px, py, 16f, intArrayOf(Color.WHITE, a[1], ca(a[1], 0f)), floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP)
                cv.drawCircle(px, py, 16f, gp)
                for (k in 0..1) {
                    val q = t * (2.4f + k) + k * 3.1f
                    cv.drawCircle(px + cos(q) * 15f, py + sin(q) * 15f, 2.2f, fillP(ca(a[k], 0.9f)))
                }
            }
        }
        val tc = if (m == 1 && v > 0.55f) Color.WHITE else ink
        if (m == 2) icon(cv, cx, cx, tc)
        else {
            tp.reset(); tp.isAntiAlias = true; tp.color = tc; tp.textAlign = Paint.Align.CENTER
            tp.typeface = Typeface.DEFAULT_BOLD; tp.textSize = w * 0.2f
            val fm = tp.fontMetrics
            cv.drawText((v * 100f).roundToInt().toString(), cx, cx + 14f - (fm.ascent + fm.descent) / 2f, tp)
            icon(cv, cx, cx - 14f, tc)
        }
    }
}

class VolBar(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var view: StyleView? = null
    private var cur: VCfg? = null
    private var hideR: Runnable? = null
    private var demoR: Runnable? = null
    private var sx = 0f
    private var sy = 0f
    private var shrink = false
    private var touching = false
    private var lastLv = -1

    private fun json() = try { JSONObject(Prefs.sp(s).getString("vb", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    fun mode(): String = json().optString("vm", "default")
    private fun dp(v: Number) = v.toFloat() * s.resources.displayMetrics.density
    private fun am() = s.getSystemService(AudioManager::class.java)
    private fun stream() = if (s.isInCall()) 0 else if (s.isRinging()) 2 else 3
    private fun tick() {
        try { s.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)) } catch (_: Exception) {}
    }

    fun adjust(dir: Int) { h.post { try { am().adjustStreamVolume(stream(), dir, 0) } catch (_: Exception) {}; show(true) } }
    fun refresh() { h.post { show(true) } }
    fun demo() { h.post { runDemo() } }
    fun reset() { h.post { hideR?.let { h.removeCallbacks(it) }; demoR?.let { h.removeCallbacks(it) }; kill() } }
    private fun kill() {
        view?.let { it.animate().cancel(); try { wm.removeView(it) } catch (_: Exception) {} }
        view = null; touching = false
    }

    private fun show(buzz: Boolean) {
        val c = VCfg(json()); val st = stream(); val a = am()
        val mx = max(a.getStreamMaxVolume(st), 1); val lv = a.getStreamVolume(st)
        view?.let { it.animate().cancel(); it.alpha = c.alpha; it.translationX = 0f; it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f }
        if (view == null) make(c)
        view?.setLevel(lv.toFloat() / mx, lv == 0, st)
        lastLv = lv
        if (buzz && c.haptic) tick()
        keep(c.dur)
    }

    private fun runDemo() {
        show(false)
        val v = view ?: return
        val st = stream(); val a = am()
        val mx = max(a.getStreamMaxVolume(st), 1)
        val real = a.getStreamVolume(st).toFloat() / mx
        v.setLevel(0.35f + Math.random().toFloat() * 0.55f, false, st)
        keep(max(cur?.dur ?: 1800L, 2800L))
        demoR?.let { h.removeCallbacks(it) }
        val r = Runnable { if (view === v) v.setLevel(real, real <= 0f, st) }
        demoR = r
        h.postDelayed(r, 1500)
    }

    private fun keep(ms: Long) {
        hideR?.let { h.removeCallbacks(it) }
        val r = Runnable { fade() }
        hideR = r
        h.postDelayed(r, ms)
    }

    private fun fade() {
        val v = view ?: return
        if (touching) { keep(1200); return }
        v.animate().alpha(0f).translationX(sx).translationY(sy)
            .scaleX(if (shrink) 0.85f else 1f).scaleY(if (shrink) 0.85f else 1f)
            .setDuration(260).setInterpolator(DecelerateInterpolator())
            .withEndAction { if (view === v) kill() }.start()
    }

    private fun setPct(f: Float) {
        val st = stream(); val a = am()
        val mx = max(a.getStreamMaxVolume(st), 1)
        val lv = (f * mx).roundToInt().coerceIn(0, mx)
        val changed = lv != lastLv
        lastLv = lv
        try { a.setStreamVolume(st, lv, 0) } catch (_: Exception) {}
        view?.setLevel(lv.toFloat() / mx, lv == 0, st)
        if (changed && cur?.haptic == true) tick()
        keep(cur?.dur ?: 1800L)
    }

    private fun make(c: VCfg) {
        val v = StyleView(s, c)
        cur = c
        val lp = WindowManager.LayoutParams(
            v.winW, v.winH, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        val off = (c.gap * s.resources.displayMetrics.density - v.pad * v.sc).toInt()
        shrink = false
        when (c.pos) {
            "left" -> { lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL; lp.x = off; sx = -dp(44); sy = 0f }
            "right" -> { lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL; lp.x = off; sx = dp(44); sy = 0f }
            "top" -> { lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = off; sx = 0f; sy = -dp(36) }
            "bottom" -> { lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = off; sx = 0f; sy = dp(36) }
            else -> { lp.gravity = Gravity.CENTER; sx = 0f; sy = 0f; shrink = true }
        }
        v.onSet = { f -> setPct(f) }
        v.onTouch = { down -> touching = down; if (!down) keep(cur?.dur ?: 1800L) }
        v.alpha = 0f; v.translationX = sx; v.translationY = sy
        if (shrink) { v.scaleX = 0.85f; v.scaleY = 0.85f }
        try { wm.addView(v, lp) } catch (_: Exception) { cur = null; return }
        view = v
        v.animate().alpha(c.alpha).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(340).setInterpolator(OvershootInterpolator(1.4f)).start()
    }
}
