package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import org.json.JSONObject
import kotlin.math.roundToInt
import kotlin.math.sin

// Custom volume bar: "default" = Samsung only, "mine" = my bar replaces it (keys are taken over), "both" = Samsung + mine
class VolBar(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var view: WaterView? = null
    private var hideR: Runnable? = null
    private var sx = 0f; private var sy = 0f

    private fun cfg() = try { JSONObject(Prefs.sp(s).getString("vb", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    fun mode() = cfg().optString("vm", "default")
    private fun dp(v: Number) = (v.toFloat() * s.resources.displayMetrics.density).toInt()
    private fun am() = s.getSystemService(AudioManager::class.java)
    private fun stream() = if (s.isInCall()) 0 else if (s.isRinging()) 2 else 3
    private fun pc(x: String) = try { Color.parseColor(x) } catch (_: Exception) { Color.CYAN }

    fun adjust(dir: Int) { h.post { try { am().adjustStreamVolume(stream(), dir, 0) } catch (_: Exception) {}; show() } }
    fun refresh() { h.post { show() } }
    fun demo() { h.post { show() } }
    fun reset() { h.post { hideR?.let { h.removeCallbacks(it) }; kill() } }
    private fun kill() { view?.let { try { wm.removeView(it) } catch (_: Exception) {} }; view = null }

    private fun show() {
        val c = cfg(); val st = stream(); val a = am(); val mx = maxOf(a.getStreamMaxVolume(st), 1); val lv = a.getStreamVolume(st)
        view?.let { it.animate().cancel(); it.alpha = 1f; it.translationX = 0f; it.translationY = 0f }
        if (view == null) make(c)
        view?.setLevel(lv.toFloat() / mx, lv == 0)
        if (c.optBoolean("haptic", true)) s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
        keep(c.optInt("dur", 18) * 100L)
    }

    private fun keep(ms: Long) { hideR?.let { h.removeCallbacks(it) }; val r = Runnable { fade() }; hideR = r; h.postDelayed(r, ms) }

    private fun fade() {
        val v = view ?: return
        v.animate().alpha(0f).translationX(sx).translationY(sy).setDuration(260).setInterpolator(DecelerateInterpolator()).withEndAction { if (view === v) kill() }.start()
    }

    private fun setPct(f: Float) {
        val st = stream(); val a = am(); val mx = maxOf(a.getStreamMaxVolume(st), 1); val lv = (f * mx).roundToInt().coerceIn(0, mx)
        try { a.setStreamVolume(st, lv, 0) } catch (_: Exception) {}
        view?.setLevel(lv.toFloat() / mx, lv == 0); keep(cfg().optInt("dur", 18) * 100L)
    }

    private fun make(c: JSONObject) {
        val style = c.optString("st", "vertical"); val left = c.optString("side", "right") == "left"; val k = c.optInt("sz", 100) / 100f
        val cols = when (c.optString("color", "ocean")) {
            "accent" -> intArrayOf(pc(c.optString("ac1", "#6366f1")), pc(c.optString("ac2", "#a855f7")))
            "sunset" -> intArrayOf(0xFFEF4444.toInt(), 0xFFFDBA74.toInt())
            "mint" -> intArrayOf(0xFF10B981.toInt(), 0xFFA7F3D0.toInt())
            else -> intArrayOf(0xFF0EA5E9.toInt(), 0xFF67E8F9.toInt())
        }
        val v = WaterView(s, style, cols[0], cols[1], s.resources.displayMetrics.density)
        val w: Int; val hh: Int
        when (style) { "pill" -> { w = dp(270 * k); hh = dp(56 * k) }; "bubble" -> { w = dp(104 * k); hh = w }; else -> { w = dp(56 * k); hh = dp(230 * k) } }
        val lp = WindowManager.LayoutParams(w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        if (style == "pill") { lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(64); sx = 0f; sy = -dp(24).toFloat() }
        else { lp.gravity = (if (left) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL; lp.x = dp(10); sx = (if (left) -dp(36) else dp(36)).toFloat(); sy = 0f }
        v.onSet = { f -> setPct(f) }
        v.alpha = 0f; v.translationX = sx; v.translationY = sy
        try { wm.addView(v, lp) } catch (_: Exception) { return }
        view = v
        v.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(340).setInterpolator(OvershootInterpolator(1.4f)).start()
    }
}

// water-filled bar: wavy surface that sloshes on every change, rising bubbles, glass shine
private class WaterView(c: Context, val style: String, val c1: Int, val c2: Int, val d: Float) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val path = Path(); private val clip = Path()
    private val icV = c.getDrawable(R.drawable.ic_vol)?.mutate(); private val icM = c.getDrawable(R.drawable.ic_mute)?.mutate()
    private var level = 0f; private var shown = 0f; private var phase = 0f; private var slosh = 0f; private var muted = false
    private var lvA: ValueAnimator? = null; private var slA: ValueAnimator? = null; private var loopA: ValueAnimator? = null
    private val bub = Array(7) { floatArrayOf(Math.random().toFloat(), Math.random().toFloat(), 0.4f + Math.random().toFloat()) }
    private val horiz = style == "pill"
    var onSet: ((Float) -> Unit)? = null

    fun setLevel(l: Float, m: Boolean) {
        level = l; muted = m
        lvA?.cancel(); lvA = ValueAnimator.ofFloat(shown, l).apply { duration = 500; interpolator = DecelerateInterpolator(); addUpdateListener { shown = it.animatedValue as Float; invalidate() }; start() }
        slA?.cancel(); slA = ValueAnimator.ofFloat(1f, 0f).apply { duration = 1100; interpolator = DecelerateInterpolator(); addUpdateListener { slosh = it.animatedValue as Float }; start() }
    }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        loopA = ValueAnimator.ofFloat(0f, 6.2832f).apply {
            duration = 1600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                for (b in bub) { b[1] -= 0.01f * b[2]; if (b[1] < 0f) { b[1] = 1f; b[0] = Math.random().toFloat() } }
                invalidate()
            }
            start()
        }
    }
    override fun onDetachedFromWindow() { loopA?.cancel(); lvA?.cancel(); slA?.cancel(); super.onDetachedFromWindow() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_CANCEL) onSet?.invoke((if (horiz) e.x / width else 1f - e.y / height).coerceIn(0f, 1f))
        return true
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val rect = RectF(2 * d, 2 * d, w - 2 * d, h - 2 * d)
        val r = if (style == "bubble") minOf(rect.width(), rect.height()) / 2 else if (horiz) rect.height() / 2 else rect.width() / 2
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0x99101826.toInt()
        cv.drawRoundRect(rect, r, r, p)
        cv.save(); clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW); cv.clipPath(clip)
        val amp = 2 * d + 7 * d * slosh
        fun wave(ph: Float, a: Float, alpha: Int) {
            path.reset()
            if (horiz) {
                val fx = rect.left + rect.width() * shown; path.moveTo(rect.left, rect.top)
                var y = rect.top; while (y <= rect.bottom) { path.lineTo(fx + a * sin(ph + y / (5 * d)), y); y += 2 * d }
                path.lineTo(rect.left, rect.bottom)
            } else {
                val top = rect.bottom - rect.height() * shown; path.moveTo(rect.left, rect.bottom)
                var x = rect.left; while (x <= rect.right) { path.lineTo(x, top + a * sin(ph + x / (6 * d))); x += 2 * d }
                path.lineTo(rect.right, rect.bottom)
            }
            path.close()
            p.shader = if (horiz) LinearGradient(rect.left, 0f, rect.right, 0f, c1, c2, Shader.TileMode.CLAMP) else LinearGradient(0f, rect.bottom, 0f, rect.top, c1, c2, Shader.TileMode.CLAMP)
            p.alpha = alpha; cv.drawPath(path, p); p.shader = null
        }
        if (shown > 0.005f) {
            wave(phase * 0.8f + 2f, amp * 1.3f, 110); wave(phase, amp, 255)
            cv.clipPath(path); p.color = 0x66FFFFFF
            for (b in bub) cv.drawCircle(rect.left + b[0] * rect.width(), rect.top + b[1] * rect.height(), (1.5f + 2.5f * b[2]) * d, p)
        }
        cv.restore()
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = 0x66FFFFFF; cv.drawRoundRect(rect, r, r, p)
        p.style = Paint.Style.FILL; p.color = 0x33FFFFFF
        if (horiz) cv.drawRoundRect(RectF(rect.left + r, rect.top + 4 * d, rect.right - r, rect.top + 7 * d), 2 * d, 2 * d, p)
        else cv.drawRoundRect(RectF(rect.left + 5 * d, rect.top + r, rect.left + 8 * d, rect.bottom - r), 2 * d, 2 * d, p)
        val ic = if (muted) icM else icV; val isz = (22 * d).toInt()
        val (cx, cy) = when { horiz -> Pair(rect.left + 28 * d, h / 2); style == "bubble" -> Pair(w / 2, h / 2 - 12 * d); else -> Pair(w / 2, rect.top + 28 * d) }
        ic?.setBounds((cx - isz / 2).toInt(), (cy - isz / 2).toInt(), (cx + isz / 2).toInt(), (cy + isz / 2).toInt()); ic?.setTint(Color.WHITE); ic?.draw(cv)
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = (if (style == "bubble") 18 else if (horiz) 15 else 13) * d
        val tx = if (horiz) rect.right - 30 * d else w / 2
        val ty = if (horiz) h / 2 + 5 * d else if (style == "bubble") h / 2 + 24 * d else rect.bottom - 14 * d
        cv.drawText((level * 100).toInt().toString(), tx, ty, p)
    }
}
