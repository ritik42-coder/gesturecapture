package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import org.json.JSONObject
import kotlin.math.min

// ---------------------------------------------------------------------------------------------------
// Charging animation. Plug the cable in and the screen dims for a moment while a ring fills up to
// the battery level in the island's colours, then it fades away on its own. Touch passes through.
// ---------------------------------------------------------------------------------------------------
class ChargeFx(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var v: ChargeView? = null
    private var anim: ValueAnimator? = null
    private var end: Runnable? = null

    private fun sec(): JSONObject = try {
        JSONObject(Prefs.sp(s).getString("fx", "{}") ?: "{}").optJSONObject("cf") ?: JSONObject()
    } catch (_: Exception) { JSONObject() }

    private fun dp(x: Int) = (x * s.resources.displayMetrics.density).toInt()
    private fun col(k: String, d: String) = try { Color.parseColor(sec().optString(k, d)) } catch (_: Exception) { Color.parseColor(d) }
    fun on() = sec().optBoolean("on", false)

    fun sync() { if (!on()) hide() }
    fun destroy() { hide() }

    private fun hide() {
        end?.let { h.removeCallbacks(it) }; end = null
        anim?.cancel(); anim = null
        v?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        v = null
    }

    fun show(pct: Int, force: Boolean = false) { h.post {
        if (!force && !on()) return@post
        val c = sec()
        val cv = ChargeView(s)
        cv.pct = pct.coerceIn(0, 100)
        cv.c1 = col("c1", "#22D3EE")
        cv.c2 = col("c2", "#2563EB")
        cv.label = if (c.optString("label", "CHARGING") == "none") "" else c.optString("label", "CHARGING")
        cv.thick = dp(c.optInt("thick", 10).coerceIn(5, 20)).toFloat()
        hide()
        val p = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(cv, p) } catch (_: Exception) { return@post }
        v = cv
        val ms = c.optInt("ms", 3000).coerceIn(1800, 6000).toLong()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                cv.prog = min(1f, f / 0.30f)
                cv.alpha = when {
                    f < 0.08f -> f / 0.08f
                    f < 0.82f -> 1f
                    else -> 1f - (f - 0.82f) / 0.18f
                }.coerceIn(0f, 1f)
                cv.invalidate()
            }
            start()
        }
        val r = Runnable { hide() }
        end = r
        h.postDelayed(r, ms + 40)
    } }

    private class ChargeView(c: Context) : View(c) {
        var pct = 50
        var c1 = 0xFF22D3EE.toInt()
        var c2 = 0xFF2563EB.toInt()
        var label = "CHARGING"
        var thick = 10f
        var prog = 0f

        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val scrim = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
        private val box = RectF()

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat(); val hh = height.toFloat()
            if (w <= 0f || hh <= 0f) return
            val d = resources.displayMetrics.density
            // dim the screen, brightest in the middle so the ring pops
            scrim.shader = RadialGradient(w / 2f, hh / 2f, maxOf(w, hh) * 0.62f,
                intArrayOf(0xE6050812.toInt(), 0xEE02040A.toInt()), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, hh, scrim)

            val cy = hh * 0.46f
            val rad = min(w, hh) * 0.17f
            box.set(w / 2f - rad, cy - rad, w / 2f + rad, cy + rad)

            ring.strokeWidth = thick
            ring.shader = null
            ring.color = 0x2EFFFFFF
            canvas.drawCircle(w / 2f, cy, rad, ring)

            val sweep = 360f * prog * (pct / 100f)
            ring.shader = SweepGradient(w / 2f, cy, intArrayOf(c1, c2, c1), null)
            ring.alpha = 255
            // glow under the arc
            ring.strokeWidth = thick * 3.4f
            ring.alpha = 46
            canvas.drawArc(box, -90f, sweep, false, ring)
            ring.strokeWidth = thick
            ring.alpha = 255
            canvas.drawArc(box, -90f, sweep, false, ring)
            ring.shader = null

            txt.color = Color.WHITE
            txt.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            txt.textSize = rad * 0.62f
            canvas.drawText("${(pct * prog).toInt()}%", w / 2f, cy + rad * 0.22f, txt)

            if (label.isNotEmpty()) {
                txt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                txt.textSize = 11f * d
                txt.color = 0xCCFFFFFF.toInt()
                canvas.drawText(label, w / 2f, cy + rad + 30f * d, txt)
            }
            ring.alpha = 255
        }
    }
}
