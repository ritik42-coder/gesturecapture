package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------------
// Charging animation. Six looks, all drawn on a canvas over the whole screen, all in your colours:
//   ring     - a clean progress ring with the percentage counting up
//   magsafe  - frosted glass ring, expanding pulse waves and orbiting sparks
//   cosmos   - a particle vortex spiralling into a glowing core
//   water    - liquid that fills to your battery level, with a sloshing surface and bubbles
//   prism    - glass shards with a laser sweep and chromatic edges
//   aurora   - ribbons of polar light with rising embers
// It fades in when the cable goes in, holds, and fades away by itself. Touch passes through.
// ---------------------------------------------------------------------------------------------------
class ChargeFx(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var v: ChargeView? = null
    private var anim: ValueAnimator? = null
    private var end: Runnable? = null

    private fun sec(): JSONObject = try {
        JSONObject(Prefs.sp(s).getString("fx", "{}") ?: "{}").optJSONObject("cf") ?: JSONObject()
    } catch (_: Exception) { JSONObject() }

    private fun dp(x: Int) = (x * s.resources.displayMetrics.density).toInt()
    private fun col(k: String, d: String) = try { Color.parseColor(sec().optString(k, d)) } catch (_: Exception) { Color.parseColor(d) }
    fun on() = sec().optBoolean("on", false)

    fun sync() { if (!on()) hide() }
    fun destroy() { hide() }

    private fun hide() {
        end?.let { h.removeCallbacks(it) }; end = null
        anim?.cancel(); anim = null
        v?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        v = null
    }

    fun show(pct: Int, force: Boolean = false) { h.post {
        if (!force && !on()) return@post
        val c = sec()
        val cv = ChargeView(s)
        cv.pct = pct.coerceIn(0, 100)
        cv.preset = c.optString("preset", "magsafe")
        cv.c1 = col("c1", "#10B981")
        cv.c2 = col("c2", "#2DD4BF")
        cv.label = if (c.optString("label", "FAST CHARGING") == "none") "" else c.optString("label", "FAST CHARGING")
        cv.thick = dp(c.optInt("thick", 10).coerceIn(5, 20)).toFloat()
        cv.speed = (c.optInt("cspd", 100).coerceIn(30, 300)) / 100f
        hide()
        val p = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(cv, p) } catch (_: Exception) { return@post }
        v = cv
        val ms = c.optInt("ms", 3400).coerceIn(2000, 8000).toLong()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                cv.prog = min(1f, f / 0.26f)
                cv.alpha = when {
                    f < 0.07f -> f / 0.07f
                    f < 0.84f -> 1f
                    else -> 1f - (f - 0.84f) / 0.16f
                }.coerceIn(0f, 1f)
                cv.invalidate()
            }
            start()
        }
        val r = Runnable { hide() }
        end = r
        h.postDelayed(r, ms + 40)
    } }

    private class Dot {
        var x = 0f; var y = 0f; var ang = 0f; var rad = 0f; var spd = 0f; var size = 2f; var ph = 0f
    }

    private class ChargeView(c: Context) : View(c) {
        var preset = "magsafe"
        var pct = 50
        var c1 = 0xFF10B981.toInt()
        var c2 = 0xFF2DD4BF.toInt()
        var label = "FAST CHARGING"
        var thick = 10f
        var speed = 1f
        var prog = 0f

        private val d = c.resources.displayMetrics.density
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
        private val box = RectF()
        private val path = Path()
        private val dots = ArrayList<Dot>()
        private var t = 0f
        private var lastN = 0L
        private var w = 0f
        private var hh = 0f

        private fun a(c: Int, f: Float): Int =
            Color.argb((255 * f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

        override fun onSizeChanged(nw: Int, nh: Int, ow: Int, oh: Int) {
            super.onSizeChanged(nw, nh, ow, oh)
            w = nw.toFloat(); hh = nh.toFloat()
            dots.clear()
            if (w <= 0f || hh <= 0f) return
            when (preset) {
                "cosmos" -> for (i in 0 until 110) {
                    val q = Dot()
                    q.ang = (Math.random() * 6.2832).toFloat()
                    q.rad = (30 + Math.random() * min(w, hh) * 0.42f).toFloat()
                    q.spd = (0.6 + Math.random() * 1.6).toFloat()
                    q.size = (1f + Math.random().toFloat() * 2.4f) * d
                    dots.add(q)
                }
                "water" -> for (i in 0 until 22) {
                    val q = Dot()
                    q.x = (Math.random() * w).toFloat()
                    q.y = (Math.random() * hh).toFloat()
                    q.size = (2 + Math.random() * 5).toFloat() * d
                    q.spd = (30 + Math.random() * 70).toFloat() * d
                    q.ph = (Math.random() * 6.28).toFloat()
                    dots.add(q)
                }
                "aurora" -> for (i in 0 until 34) {
                    val q = Dot()
                    q.x = (Math.random() * w).toFloat()
                    q.y = (Math.random() * hh).toFloat()
                    q.size = (1.2f + Math.random().toFloat() * 2.2f) * d
                    q.spd = (25 + Math.random() * 60).toFloat() * d
                    q.ph = (Math.random() * 6.28).toFloat()
                    dots.add(q)
                }
                "magsafe" -> for (i in 0 until 16) {
                    val q = Dot()
                    q.ang = (i * 0.3927f)
                    q.spd = (0.4 + Math.random() * 0.8).toFloat()
                    q.size = (1.6f + Math.random().toFloat() * 1.6f) * d
                    dots.add(q)
                }
            }
        }

        private fun glowText(canvas: Canvas, s: String, x: Float, y: Float, size: Float, glow: Int, col: Int = Color.WHITE) {
            txt.textSize = size
            txt.typeface = Typeface.create("sans-serif", Typeface.BOLD)
            txt.color = glow
            txt.alpha = 70
            for (i in 0 until 8) {
                val ang = i * 0.7854f
                canvas.drawText(s, x + cos(ang) * 3.2f * d, y + sin(ang) * 3.2f * d, txt)
            }
            txt.alpha = 255
            txt.color = col
            canvas.drawText(s, x, y, txt)
        }

        private fun small(canvas: Canvas, s: String, x: Float, y: Float, col: Int) {
            if (s.isEmpty()) return
            txt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            txt.textSize = 11f * d
            txt.color = col
            txt.alpha = 210
            canvas.drawText(s, x, y, txt)
            txt.alpha = 255
        }

        private fun number(): String = "${(pct * prog).toInt()}%"

        override fun onDraw(canvas: Canvas) {
            if (w <= 0f || hh <= 0f) return
            val now = System.nanoTime()
            val dt = if (lastN == 0L) 0f else ((now - lastN) / 1_000_000_000f).coerceIn(0f, 0.05f)
            lastN = now
            t += dt * speed
            val cx = w / 2f
            when (preset) {
                "cosmos" -> cosmos(canvas, cx, dt)
                "water" -> water(canvas, cx, dt)
                "prism" -> prism(canvas, cx)
                "aurora" -> aurora(canvas, cx, dt)
                "ring" -> ring(canvas, cx)
                else -> magsafe(canvas, cx, dt)
            }
        }

        // ---------------- ring ----------------
        private fun ring(canvas: Canvas, cx: Float) {
            fill.shader = RadialGradient(cx, hh * 0.46f, maxOf(w, hh) * 0.62f,
                intArrayOf(0xE6050812.toInt(), 0xF002040A.toInt()), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, hh, fill)
            val cy = hh * 0.46f
            val rad = min(w, hh) * 0.17f
            box.set(cx - rad, cy - rad, cx + rad, cy + rad)
            stroke.shader = null
            stroke.color = 0x2EFFFFFF
            stroke.strokeWidth = thick
            stroke.alpha = 255
            canvas.drawCircle(cx, cy, rad, stroke)
            val sweep = 360f * prog * (pct / 100f)
            stroke.shader = SweepGradient(cx, cy, intArrayOf(c1, c2, c1), null)
            stroke.strokeWidth = thick * 3.4f
            stroke.alpha = 46
            canvas.drawArc(box, -90f, sweep, false, stroke)
            stroke.strokeWidth = thick
            stroke.alpha = 255
            canvas.drawArc(box, -90f, sweep, false, stroke)
            stroke.shader = null
            glowText(canvas, number(), cx, cy + rad * 0.22f, rad * 0.62f, c1)
            small(canvas, label, cx, cy + rad + 30f * d, c2)
        }

        // ---------------- magsafe ----------------
        private fun magsafe(canvas: Canvas, cx: Float, dt: Float) {
            canvas.drawColor(0xFF030712.toInt())
            val cy = hh * 0.46f
            val rad = min(w, hh) * 0.19f
            fill.shader = RadialGradient(cx, cy, w * 0.9f,
                intArrayOf(a(c1, 0.26f), a(c1, 0.09f), a(c1, 0f)), floatArrayOf(0f, 0.42f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, hh, fill)
            fill.shader = null

            // expanding pulse waves
            for (i in 0 until 3) {
                val f = ((t * 0.5f) + i / 3f) % 1f
                stroke.shader = null
                stroke.color = c2
                stroke.alpha = ((1f - f) * 120).toInt().coerceIn(0, 255)
                stroke.strokeWidth = 2.4f * d
                canvas.drawCircle(cx, cy, rad + f * rad * 1.9f, stroke)
            }
            // orbiting sparks
            for (q in dots) {
                q.ang += dt * q.spd * 1.6f
                val dist = rad + 24f * d + sin(t * 1.4f + q.ang * 2f) * 7f * d
                fill.color = c2
                fill.alpha = 170
                canvas.drawCircle(cx + cos(q.ang) * dist, cy + sin(q.ang) * dist, q.size, fill)
            }
            fill.alpha = 255
            // frosted disc + progress arc
            fill.color = 0x9F0F172A.toInt()
            canvas.drawCircle(cx, cy, rad, fill)
            stroke.color = 0x26FFFFFF
            stroke.strokeWidth = 1.5f * d
            stroke.alpha = 255
            canvas.drawCircle(cx, cy, rad, stroke)
            box.set(cx - rad, cy - rad, cx + rad, cy + rad)
            val sweep = 360f * prog * (pct / 100f)
            stroke.shader = SweepGradient(cx, cy, intArrayOf(c1, c2, c1), null)
            stroke.strokeWidth = 4.5f * d
            canvas.drawArc(box, -90f, sweep, false, stroke)
            stroke.strokeWidth = 15f * d
            stroke.alpha = 40
            canvas.drawArc(box, -90f, sweep, false, stroke)
            stroke.shader = null
            stroke.alpha = 255
            glowText(canvas, number(), cx, cy + rad * 0.22f, rad * 0.58f, c1)
            small(canvas, label, cx, cy + rad + 34f * d, c2)
        }

        // ---------------- cosmos ----------------
        private fun cosmos(canvas: Canvas, cx: Float, dt: Float) {
            val cy = hh * 0.47f
            fill.shader = RadialGradient(cx, cy, w * 0.95f,
                intArrayOf(a(c1, 0.30f), 0xFF041D1A.toInt(), 0xFF020617.toInt()),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, hh, fill)
            fill.shader = null

            val maxR = min(w, hh) * 0.55f
            for (q in dots) {
                q.ang += dt * q.spd * 1.2f * speed
                q.rad -= 40f * d * dt * speed
                if (q.rad < 16f * d) { q.rad = maxR * (0.8f + 0.2f * Math.random().toFloat()) }
                val x = cx + cos(q.ang) * q.rad
                val y = cy + sin(q.ang) * q.rad * 0.62f
                fill.color = if (q.spd > 1.4f) c2 else c1
                fill.alpha = 210
                canvas.drawCircle(x, y, q.size, fill)
            }
            fill.alpha = 255
            fill.shader = RadialGradient(cx, cy, 78f * d,
                intArrayOf(Color.WHITE, c1, a(c1, 0.35f), a(c1, 0f)),
                floatArrayOf(0f, 0.32f, 0.72f, 1f), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, 78f * d, fill)
            fill.shader = null
            glowText(canvas, number(), cx, cy + 12f * d, 34f * d, c1)
            small(canvas, label, cx, cy + 42f * d, c2)
        }

        // ---------------- water ----------------
        private fun water(canvas: Canvas, cx: Float, dt: Float) {
            canvas.drawColor(0xFF02131B.toInt())
            val level = hh - (prog * pct / 100f) * (hh - 70f * d)
            path.reset()
            path.moveTo(0f, hh)
            path.lineTo(0f, level)
            var x = 0f
            while (x <= w) {
                val wave = sin(x * 0.028f + t * 2.4f) * 7f * d + cos(x * 0.019f - t * 1.6f) * 4.5f * d
                path.lineTo(x, level + wave)
                x += 6f * d
            }
            path.lineTo(w, hh)
            path.close()
            fill.shader = LinearGradient(0f, level, 0f, hh,
                intArrayOf(a(c1, 0.85f), a(c2, 0.95f), a(0xFF042F2E.toInt(), 1f)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            canvas.drawPath(path, fill)
            fill.shader = null
            stroke.shader = null
            stroke.color = c2
            stroke.strokeWidth = 2.6f * d
            stroke.alpha = 235
            canvas.drawPath(path, stroke)

            for (q in dots) {
                q.y -= q.spd * dt
                if (q.y < level) { q.y = hh + 12f * d; q.x = (Math.random() * w).toFloat() }
                val bx = q.x + sin(t * 1.7f + q.ph) * 7f * d
                stroke.color = 0xCCCCFBF1.toInt()
                stroke.strokeWidth = 1.2f * d
                stroke.alpha = 190
                canvas.drawCircle(bx, q.y, q.size, stroke)
                fill.color = 0x66CCFBF1.toInt()
                canvas.drawCircle(bx, q.y, q.size * 0.45f, fill)
            }
            stroke.alpha = 255

            val cy = hh * 0.42f
            val rad = 56f * d
            fill.color = 0xB30F172A.toInt()
            canvas.drawCircle(cx, cy, rad, fill)
            stroke.color = c2
            stroke.strokeWidth = 2f * d
            canvas.drawCircle(cx, cy, rad, stroke)
            glowText(canvas, number(), cx, cy + 11f * d, 30f * d, c2)
            small(canvas, label, cx, cy + rad + 30f * d, c2)
        }

        // ---------------- prism ----------------
        private fun prism(canvas: Canvas, cx: Float) {
            canvas.drawColor(0xFF030712.toInt())
            fill.shader = RadialGradient(cx, hh * 0.46f, w * 0.9f,
                intArrayOf(a(c1, 0.16f), a(c1, 0f)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, hh, fill)
            fill.shader = null

            val cy = hh * 0.46f
            // glass shards
            for (i in 0 until 5) {
                val ang = t * (0.12f + i * 0.03f) + i * 1.2f
                val dist = min(w, hh) * (0.22f + i * 0.045f)
                val sx = cx + cos(ang) * dist
                val sy = cy + sin(ang) * dist * 0.8f
                canvas.save()
                canvas.rotate((i * 37f + t * 14f) % 360f, sx, sy)
                val sz = (26f + i * 7f) * d
                box.set(sx - sz, sy - sz * 0.5f, sx + sz, sy + sz * 0.5f)
                fill.shader = LinearGradient(box.left, box.top, box.right, box.bottom,
                    intArrayOf(a(c1, 0.30f), a(c2, 0.10f), a(c1, 0.02f)), null, Shader.TileMode.CLAMP)
                canvas.drawRoundRect(box, 6f * d, 6f * d, fill)
                fill.shader = null
                stroke.shader = null
                stroke.color = a(Color.WHITE, 0.5f)
                stroke.strokeWidth = 1.2f * d
                canvas.drawRoundRect(box, 6f * d, 6f * d, stroke)
                canvas.restore()
            }
            // laser sweep with a hint of chromatic split
            val sweepX = ((t * 0.55f) % 1f) * w
            stroke.color = a(c1, 0.30f)
            stroke.strokeWidth = 22f * d
            canvas.drawLine(sweepX, 0f, sweepX, hh, stroke)
            val cols = intArrayOf(0xFFFF3355.toInt(), 0xFF33FF88.toInt(), 0xFF3388FF.toInt())
            for (i in 0 until 3) {
                stroke.color = a(cols[i], 0.6f)
                stroke.strokeWidth = 2f * d
                canvas.drawLine(sweepX + (i - 1) * 2.5f * d, 0f, sweepX + (i - 1) * 2.5f * d, hh, stroke)
            }

            val rad = min(w, hh) * 0.18f
            box.set(cx - rad, cy - rad, cx + rad, cy + rad)
            stroke.color = a(c1, 0.9f)
            stroke.strokeWidth = 3f * d
            canvas.drawArc(box, -90f, 360f * prog * (pct / 100f), false, stroke)
            stroke.color = a(Color.WHITE, 0.10f)
            stroke.strokeWidth = 1.5f * d
            canvas.drawCircle(cx, cy, rad, stroke)
            glowText(canvas, number(), cx, cy + rad * 0.2f, rad * 0.6f, c1)
            small(canvas, label, cx, cy + rad + 30f * d, c2)
        }

        // ---------------- aurora ----------------
        private fun aurora(canvas: Canvas, cx: Float, dt: Float) {
            canvas.drawColor(0xFF02030A.toInt())
            for (band in 0 until 3) {
                path.reset()
                val baseY = hh * (0.34f + band * 0.13f)
                val amp = (40f + band * 16f) * d
                path.moveTo(0f, baseY)
                var x = 0f
                while (x <= w) {
                    val y = baseY + sin(x * 0.006f + t * (0.8f + band * 0.25f) + band) * amp +
                        cos(x * 0.0035f - t * 0.6f) * amp * 0.55f
                    path.lineTo(x, y)
                    x += 10f * d
                }
                stroke.shader = LinearGradient(0f, 0f, w, 0f,
                    intArrayOf(a(c1, 0.05f), a(c1, 0.55f), a(c2, 0.55f), a(c2, 0.05f)), null, Shader.TileMode.CLAMP)
                stroke.strokeWidth = (34f - band * 6f) * d
                stroke.alpha = 70
                canvas.drawPath(path, stroke)
                stroke.strokeWidth = 2.4f * d
                stroke.alpha = 200
                canvas.drawPath(path, stroke)
                stroke.shader = null
            }
            stroke.alpha = 255
            for (q in dots) {
                q.y -= q.spd * dt
                if (q.y < -10f * d) { q.y = hh + 10f * d; q.x = (Math.random() * w).toFloat() }
                fill.color = if (q.ph > 3.1f) c2 else c1
                fill.alpha = (120 + 100 * sin(t * 2f + q.ph)).toInt().coerceIn(30, 235)
                canvas.drawCircle(q.x + sin(t + q.ph) * 6f * d, q.y, q.size, fill)
            }
            fill.alpha = 255
            glowText(canvas, number(), cx, hh * 0.46f, 56f * d, c1)
            small(canvas, label, cx, hh * 0.46f + 40f * d, c2)
        }
    }
}
