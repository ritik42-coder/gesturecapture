package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.bluetooth.BluetoothDevice
import android.media.AudioManager
import android.text.format.DateFormat
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.TextUtils
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Date
import kotlin.math.abs
import kotlin.math.sin

// Dynamic Island + nav-bar hybrid. One pill that morphs between: idle (clock/battery), quick dock, music player, hotspot,
// recording, call, message, charging, volume, Bluetooth and ringer states.
private class DockItem(val id: String, val res: Int, val act: String)

class Island(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null; private var card: FrameLayout? = null; private var content: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private val bgd = GradientDrawable()
    private var anim: ValueAnimator? = null
    private var mode = ""; private var expanded = false; private var animIn = true
    private var hideRun: Runnable? = null; private var ticking = false; private var regd = false
    private var recSec = -1; private var callSec = -1; private var volL = 0
    private var timerTv: TextView? = null; private var dotV: View? = null; private var volBar: BarView? = null
    private var seekV: SeekView? = null; private var posTv: TextView? = null; private var durTv: TextView? = null
    private var idleTimeTv: TextView? = null; private var idleBatTv: TextView? = null
    private var caller = "Incoming call"; private var nPkg = ""; private var nTitle = ""; private var nText = ""; private var nApp = ""
    private var chgOn = true; private var chgPct = 0; private var chgLabel = "CHARGING"; private var lastKey = ""; private var lastKeyT = 0L
    private var btName = ""; private var btOn = true; private var ringM = 2; private var prevHot = 0
    private val gray = 0xFFAAAAAA.toInt(); private val green = 0xFF22C55E.toInt(); private val red = 0xFFF43F5E.toInt()

    private val music = MusicWatcher(s, h) { onMusic() }
    val hot = HotspotWatcher(s, h) { onHot() }

    private val dockAll = listOf(
        DockItem("back", R.drawable.ic_back, "back"), DockItem("home", R.drawable.ic_home, "home"), DockItem("recents", R.drawable.ic_recents, "recents"),
        DockItem("notif", R.drawable.ic_bell, "notif"), DockItem("quick", R.drawable.ic_tune, "quick"), DockItem("shot", R.drawable.ic_cam, "shot"),
        DockItem("lock", R.drawable.ic_lock, "lock"), DockItem("torch", R.drawable.ic_flash, "torch"), DockItem("power", R.drawable.ic_power, "power"),
        DockItem("hot", R.drawable.ic_hot, "hotset"), DockItem("bt", R.drawable.ic_bt, "bt"))

    // ---- settings (JSON saved by the web UI) ----
    private fun cfg() = try { JSONObject(Prefs.sp(s).getString("isl", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun num(k: String, d: Int) = cfg().optInt(k, d)
    fun on() = cfg().optBoolean("on", false)
    fun feat(f: String) = on() && cfg().optBoolean("f_$f", true)
    private fun dp(v: Int) = (v * s.resources.displayMetrics.density).toInt()
    private fun spd() = when (cfg().optString("speed", "normal")) { "slow" -> 1.6f; "fast" -> 0.7f; else -> 1f }
    private fun bounce() = when (cfg().optString("bounce", "soft")) { "none" -> 0f; "springy" -> 3.2f; else -> 1.5f }
    private fun buzz() { if (cfg().optBoolean("haptic", true)) s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)) }
    private fun pc(x: String) = try { Color.parseColor(x) } catch (_: Exception) { Color.BLACK }
    fun setCaller(n: String) { caller = n }

    private fun paint() {
        val c = cfg()
        when (val k = c.optString("color", "black")) {
            "accent" -> { bgd.orientation = GradientDrawable.Orientation.LEFT_RIGHT; bgd.colors = intArrayOf(pc(c.optString("ac1", "#6366f1")), pc(c.optString("ac2", "#a855f7"))) }
            else -> bgd.setColor(when (k) { "midnight" -> 0xFF0B1020.toInt(); "graphite" -> 0xFF1C1C1E.toInt(); "glass" -> 0xCC000000.toInt(); else -> Color.BLACK })
        }
        bgd.alpha = c.optInt("op", 100) * 255 / 100; bgd.setStroke(dp(1), 0x26FFFFFF)
    }

    private fun batPct(): Int {
        val b = s.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (b?.getIntExtra("level", 0) ?: 0) * 100 / maxOf(b?.getIntExtra("scale", 100) ?: 100, 1)
    }

    private val rcv = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED -> if (feat("charge")) charge(i.action == Intent.ACTION_POWER_CONNECTED, batPct())
                Intent.ACTION_BATTERY_LOW -> if (feat("lowbat")) charge(false, batPct(), "LOW BATTERY")
                AudioManager.RINGER_MODE_CHANGED_ACTION -> if (feat("ringer")) ringer(s.getSystemService(AudioManager::class.java).ringerMode)
                BluetoothDevice.ACTION_ACL_CONNECTED, BluetoothDevice.ACTION_ACL_DISCONNECTED -> if (feat("bt")) {
                    val d = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    val n = try { d?.name } catch (_: Exception) { null }
                    bt(n ?: "Bluetooth device", i.action == BluetoothDevice.ACTION_ACL_CONNECTED)
                }
            }
        }
    }

    fun sync() {
        if (!on()) { destroy(); return }
        if (!regd) {
            s.registerReceiver(rcv, IntentFilter(Intent.ACTION_POWER_CONNECTED).apply {
                addAction(Intent.ACTION_POWER_DISCONNECTED); addAction(Intent.ACTION_BATTERY_LOW)
                addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
                addAction(BluetoothDevice.ACTION_ACL_CONNECTED); addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            }); regd = true
        }
        if (feat("music")) music.start() else music.stop()
        if (feat("hot")) hot.start() else hot.stop()
        if (root != null) { place(); paint(); render(); morph(target()) } else base()
    }

    fun destroy() {
        if (regd) { try { s.unregisterReceiver(rcv) } catch (_: Exception) {}; regd = false }
        music.stop(); hot.stop()
        hideRun?.let { h.removeCallbacks(it) }; h.removeCallbacks(idleTick); anim?.cancel(); remove(); mode = ""
    }

    private fun remove() { root?.let { try { wm.removeView(it) } catch (_: Exception) {} }; root = null; card = null; content = null }

    private fun place() {
        val p = lp ?: return
        p.x = dp(num("x", 0)); p.y = dp(num("y", 8))
        root?.let { try { wm.updateViewLayout(it, p) } catch (_: Exception) {} }
    }

    private fun ensure() {
        if (root != null) { card?.animate()?.cancel(); card?.alpha = 1f; return }
        val c = FrameLayout(s); c.background = bgd; c.elevation = dp(10).toFloat(); c.clipToOutline = true
        c.outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, bgd.cornerRadius) } }
        val ct = LinearLayout(s); ct.gravity = Gravity.CENTER; ct.orientation = LinearLayout.VERTICAL
        c.addView(ct, FrameLayout.LayoutParams(-1, -1))
        val r = FrameLayout(s); r.addView(c, FrameLayout.LayoutParams(dp(num("w", 126)), dp(num("h", 34)), Gravity.CENTER_HORIZONTAL))
        val l = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp = l; root = r; card = c; content = ct
        paint(); place(); bgd.cornerRadius = dp(num("h", 34)) / 2f
        c.alpha = 0f; c.scaleX = .6f; c.scaleY = .6f
        try { wm.addView(r, l) } catch (_: Exception) { root = null; return }
        c.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration((380 * spd()).toLong()).setInterpolator(OvershootInterpolator(bounce())).start()
        var y0 = 0f; var x0 = 0f
        c.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { y0 = ev.rawY; x0 = ev.rawX }
                MotionEvent.ACTION_UP -> {
                    val dy = ev.rawY - y0; val dx = ev.rawX - x0
                    when {
                        dy < -dp(18) -> collapse()
                        dy > dp(18) -> expand()
                        abs(dx) < dp(10) && abs(dy) < dp(10) -> tap()
                        abs(dx) > dp(40) && mode == "music" -> { if (dx > 0) music.prev() else music.next(); buzz() }
                    }
                }
            }
            true
        }
    }

    private fun collapse() { if (mode == "rec" && expanded) go("rec", false) else if (mode != "call" && mode != "rec") base() }
    private fun expand() {
        when (mode) {
            "" -> go("dock", true, 6000)
            "music" -> go("musicx", true, 12000)
            "hot" -> go("hotx", true, 12000)
            "rec" -> if (!expanded) go("rec", true)
        }
    }
    private fun tap() { when (mode) { "rec" -> go("rec", !expanded); "dock" -> base(); else -> expand() } }
    private fun keep(ms: Long) { hideRun?.let { h.removeCallbacks(it) }; val r = Runnable { base() }; hideRun = r; h.postDelayed(r, ms) }
    private fun openApp(tab: String) {
        s.startActivity(Intent(s, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("tab", tab))
        base()
    }
    private fun openTether() {
        for (i in listOf(Intent("android.settings.TETHER_SETTINGS"), Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS))) {
            try { s.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); base(); return } catch (_: Exception) {}
        }
    }

    // ---- hotspot helpers ----
    fun devName(mac: String, i: Int): String = (Prefs.sp(s).getString("hn_$mac", "") ?: "").ifBlank { "Device ${i + 1}" }
    fun hotJson(): String {
        val o = JSONObject(); o.put("on", hot.on); o.put("supported", hot.supported)
        val a = JSONArray()
        hot.clients.forEachIndexed { i, m -> a.put(JSONObject().put("mac", m).put("name", Prefs.sp(s).getString("hn_$m", "") ?: "").put("label", devName(m, i))) }
        o.put("devices", a); return o.toString()
    }
    private fun hotH(): Int { val n = hot.count(); return dp(70 + 38 * minOf(n, 4) + (if (n > 4 || n == 0) 26 else 0)) }

    private fun target(): Pair<Int, Int> {
        val pw = dp(num("w", 126)); val ph = dp(num("h", 34)); val ew = dp(num("ew", 340))
        return when (mode) {
            "rec" -> if (expanded) Pair(ew, dp(128)) else Pair(pw + dp(70), ph)
            "incall" -> Pair(pw + dp(80), ph)
            "call" -> Pair(ew, dp(92))
            "notif" -> Pair(ew, dp(90))
            "charge" -> Pair(dp(262), dp(72))
            "vol" -> Pair(dp(250), dp(54))
            "dock" -> Pair(minOf(dp(372), s.resources.displayMetrics.widthPixels - dp(16)), dp(64))
            "music" -> Pair(pw + dp(84), ph)
            "musicx" -> Pair(ew, dp(190))
            "hot" -> Pair(pw + dp(70), ph)
            "hotx" -> Pair(ew, hotH())
            "bt" -> Pair(dp(270), dp(64))
            "ringer" -> Pair(dp(200), dp(54))
            else -> Pair(pw, ph)
        }
    }

    // spring-like morph of size and corner radius
    private fun morph(t: Pair<Int, Int>) {
        val c = card ?: return; val l = c.layoutParams as FrameLayout.LayoutParams
        val w0 = l.width; val h0 = l.height
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = (480 * spd()).toLong(); interpolator = OvershootInterpolator(bounce())
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                l.width = maxOf(dp(20), (w0 + (t.first - w0) * f).toInt()); l.height = maxOf(dp(20), (h0 + (t.second - h0) * f).toInt())
                bgd.cornerRadius = minOf(l.height / 2f, dp(34).toFloat())
                c.layoutParams = l; c.invalidateOutline()
            }
            start()
        }
    }

    fun go(m: String, ex: Boolean, ttl: Long = 0, q: Boolean = false) {
        if (!on()) return
        ensure()
        val ct = content ?: return
        hideRun?.let { h.removeCallbacks(it) }; hideRun = null
        mode = m; expanded = ex; animIn = true
        ct.animate().cancel(); ct.alpha = 0f
        render(); morph(target())
        ct.animate().alpha(1f).setStartDelay((150 * spd()).toLong()).setDuration((220 * spd()).toLong()).start()
        if (!q) buzz()
        if (ttl > 0) { val r = Runnable { base() }; hideRun = r; h.postDelayed(r, ttl) }
        if (!ticking) { ticking = true; h.postDelayed(tickR, 1000) }
    }

    // fall back to the persistent state (call > recording > on-call > music > hotspot) or the idle pill
    fun base() { h.post {
        when {
            s.isRinging() && feat("call") -> go("call", true)
            RecorderService.running && feat("rec") -> go("rec", false)
            s.isInCall() && feat("call") -> go("incall", false)
            feat("music") && music.active() -> go("music", false, 0, true)
            feat("hot") && hot.on -> go("hot", false, 0, true)
            else -> idle()
        }
    } }

    private fun idle() {
        mode = ""; expanded = false
        val c = card ?: run { if (cfg().optBoolean("always", true)) go("", false, 0, true); return }
        if (cfg().optBoolean("always", true)) { go("", false, 0, true); return }
        content?.animate()?.alpha(0f)?.setStartDelay(0)?.setDuration(120)?.start()
        morph(target())
        c.animate().alpha(0f).setStartDelay((420 * spd()).toLong()).setDuration(220).withEndAction { if (mode == "") remove() }.start()
    }

    private fun timeNow(): String = DateFormat.format(if (DateFormat.is24HourFormat(s)) "HH:mm" else "h:mm", Date()).toString()
    private val idleTick = object : Runnable {
        override fun run() {
            idleTimeTv?.text = timeNow(); idleBatTv?.text = "${batPct()}%"
            if (mode == "" && root != null) h.postDelayed(this, 15000)
        }
    }

    private val tickR = object : Runnable {
        override fun run() {
            val rec = RecorderService.running
            if (rec && !RecorderService.paused) recSec++
            if (s.isInCall()) callSec++ else callSec = -1
            timerTv?.text = timeStr(); dotV?.alpha = if (RecorderService.paused) .3f else if (recSec % 2 == 0) 1f else .45f
            if (mode == "call" && !s.isRinging()) base()
            if (on() && (rec || mode == "call" || mode == "incall")) h.postDelayed(this, 1000) else ticking = false
        }
    }
    private fun timeStr(): String { val n = maxOf(if (mode == "incall") callSec else recSec, 0); return String.format("%02d:%02d", n / 60, n % 60) }

    // ---- events ----
    fun recording(on: Boolean) { h.post { recSec = -1; if (on) go("rec", false) else base() } }
    fun notif(pkg: String, title: String, text: String) { h.post {
        if (mode == "call") return@post
        val key = pkg + title; val now = System.currentTimeMillis()
        if (key == lastKey && now - lastKeyT < 4000) return@post
        lastKey = key; lastKeyT = now; nPkg = pkg; nTitle = title; nText = text
        nApp = try { s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        go("notif", true, 4500)
    } }
    fun charge(plug: Boolean, pct: Int, label: String? = null) { h.post { if (mode != "call") { chgOn = plug; chgPct = pct; chgLabel = label ?: (if (plug) "CHARGING" else "UNPLUGGED"); go("charge", true, 3200) } } }
    fun bt(name: String, on: Boolean) { h.post {
        if (mode == "call") return@post
        val key = "bt$name$on"; val now = System.currentTimeMillis()
        if (key == lastKey && now - lastKeyT < 4000) return@post
        lastKey = key; lastKeyT = now; btName = name; btOn = on; go("bt", true, 3500)
    } }
    fun ringer(m: Int) { h.post { if (mode != "call") { ringM = m; go("ringer", true, 1800) } } }

    private fun onMusic() { h.post {
        if (!feat("music")) return@post
        when (mode) {
            "music", "musicx" -> if (music.active()) render() else base()
            "", "hot" -> if (music.active() && music.playing) go("music", false, 0, true)
        }
        if (mode == "music" && music.active() && !music.playing) h.postDelayed({ if (mode == "music") base() }, 46000)
    } }

    private fun onHot() { h.post {
        if (!feat("hot")) return@post
        val n = hot.count(); val inc = n > prevHot; prevHot = n
        if (inc && mode != "call" && mode != "rec" && mode != "incall") go("hotx", true, 5000)
        else when (mode) {
            "hotx" -> if (hot.on) render() else base()
            "music" -> render()
            "", "hot" -> base()
        }
    } }
    fun volume(l: Int, m: Int) { h.post {
        volL = l * 100 / maxOf(m, 1)
        if (mode == "vol") { volBar?.set(volL); hideRun?.let { h.removeCallbacks(it) }; val r = Runnable { base() }; hideRun = r; h.postDelayed(r, 1600) }
        else if (mode != "call") go("vol", true, 1600)
    } }
    fun demo(kind: String) { h.post {
        if (!on()) return@post
        when (kind) {
            "rec" -> { recSec = 73; go("rec", true, 4500) }
            "call" -> { caller = "Mom"; go("call", true, 5000) }
            "notif" -> { nPkg = s.packageName; nApp = "Messages"; nTitle = "Alex"; nText = "Hey! Are you free tonight? 🎉"; go("notif", true, 4500) }
            "charge" -> { chgOn = true; chgPct = 78; go("charge", true, 3200) }
            "vol" -> { volL = 60; go("vol", true, 1600) }
            "music" -> { music.startDemo(); go("musicx", true, 6500) }
            "hot" -> { hot.startDemo(); go("hotx", true, 6500) }
            "dock" -> go("dock", true, 6000)
            "bt" -> { btName = "Galaxy Buds"; btOn = true; go("bt", true, 3500) }
            "ringer" -> { ringM = AudioManager.RINGER_MODE_SILENT; go("ringer", true, 1800) }
            "lowbat" -> { chgOn = false; chgPct = 15; chgLabel = "LOW BATTERY"; go("charge", true, 3200) }
            else -> go("", false, 3500)
        }
    } }

    // ---- content ----
    private val fx = ArrayList<ValueAnimator>()
    private fun loop(ms: Long, f: (Float) -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f); a.duration = ms; a.repeatCount = ValueAnimator.INFINITE; a.interpolator = LinearInterpolator()
        a.addUpdateListener { f(it.animatedValue as Float) }; a.start(); fx.add(a)
    }
    private fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(s).apply {
        text = t; textSize = sp; setTextColor(col); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun row() = LinearLayout(s).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(16), 0) }
    private fun col() = LinearLayout(s).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(6), 0) }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun icon(res: Int, c: Int) = ImageView(s).apply { try { setImageDrawable(s.getDrawable(res)) } catch (_: Exception) {}; setColorFilter(c) }
    private fun circ(c: Int, res: Int, size: Int = 44, mt: Int = 8, click: () -> Unit) = FrameLayout(s).apply {
        background = oval(c); layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(7), dp(mt), dp(7), 0) }
        addView(icon(res, Color.WHITE), FrameLayout.LayoutParams(dp(size / 2), dp(size / 2), Gravity.CENTER)); setOnClickListener { click() }
    }

    private fun render() {
        val ct = content ?: return
        fx.forEach { it.cancel() }; fx.clear(); h.removeCallbacks(idleTick)
        ct.removeAllViews(); timerTv = null; dotV = null; volBar = null; seekV = null; posTv = null; durTv = null; idleTimeTv = null; idleBatTv = null
        paint()
        if (mode == "musicx" && music.tint != 0) { bgd.orientation = GradientDrawable.Orientation.TOP_BOTTOM; bgd.colors = intArrayOf(music.tint, Color.BLACK) }
        when (mode) {
            "" -> {
                val m = cfg().optString("idle", "both")
                if (m != "none") {
                    val r = row(); r.setPadding(dp(10), 0, dp(10), 0)
                    val l = tv(if (m == "battery") "" else timeNow(), 12f, Color.WHITE, true); l.gravity = Gravity.CENTER; idleTimeTv = l
                    val rt = tv(if (m == "time") "" else "${batPct()}%", 12f, Color.WHITE, true); rt.gravity = Gravity.CENTER; idleBatTv = rt
                    r.addView(l, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(View(s), LinearLayout.LayoutParams(dp(30), 1)); r.addView(rt, LinearLayout.LayoutParams(0, -2, 1f))
                    ct.addView(r, LinearLayout.LayoutParams(-1, -2))
                    if (m == "battery") idleTimeTv = null; if (m == "time") idleBatTv = null
                    h.postDelayed(idleTick, 15000)
                }
            }
            "dock" -> {
                val ids = cfg().optString("dock", "back,home,recents,notif,quick,shot,lock,torch").split(",")
                val items = ids.mapNotNull { id -> dockAll.find { it.id == id } }.take(8)
                val r = LinearLayout(s); r.gravity = Gravity.CENTER; r.setPadding(dp(10), 0, dp(10), 0)
                val avail = target().first - dp(20)
                val size = minOf(dp(44), avail / maxOf(items.size, 1) - dp(6))
                val views = ArrayList<View>()
                for (it in items) {
                    val on = it.id == "torch" && s.torchIsOn
                    val b = FrameLayout(s); b.background = oval(if (on) 0xFFFBBF24.toInt() else 0x26FFFFFF)
                    b.addView(icon(it.res, if (on) Color.BLACK else Color.WHITE), FrameLayout.LayoutParams(size / 2 + dp(2), size / 2 + dp(2), Gravity.CENTER))
                    b.setOnClickListener { v ->
                        v.animate().scaleX(.8f).scaleY(.8f).setDuration(80).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
                        buzz(); dockDo(it)
                    }
                    r.addView(b, LinearLayout.LayoutParams(size, size).apply { setMargins(dp(3), 0, dp(3), 0) }); views.add(b)
                }
                ct.addView(r, LinearLayout.LayoutParams(-1, -1))
                if (animIn) pop(views)
            }
            "music" -> {
                val r = row(); r.setPadding(dp(10), 0, dp(10), 0)
                r.addView(artView(22, 7), LinearLayout.LayoutParams(dp(22), dp(22)))
                r.addView(View(s), LinearLayout.LayoutParams(0, 1, 1f))
                if (hot.on) {
                    r.addView(icon(R.drawable.ic_hot, green), LinearLayout.LayoutParams(dp(13), dp(13)))
                    r.addView(tv(if (hot.supported) "${hot.count()}" else "", 11f, Color.WHITE, true).apply { setPadding(dp(3), 0, dp(8), 0) })
                }
                r.addView(Bars(s, Color.WHITE).also { it.live = music.playing }, LinearLayout.LayoutParams(dp(22), dp(16)))
                ct.addView(r, LinearLayout.LayoutParams(-1, -2))
            }
            "musicx" -> {
                val top = LinearLayout(s); top.gravity = Gravity.CENTER_VERTICAL; top.setPadding(dp(16), 0, dp(16), 0)
                top.addView(artView(58, 14), LinearLayout.LayoutParams(dp(58), dp(58)))
                val l = col(); l.setPadding(dp(14), 0, dp(6), 0)
                l.addView(tv(music.appName().uppercase(), 10f, gray, true))
                l.addView(tv(music.title.ifEmpty { "Unknown" }, 16f, Color.WHITE, true))
                l.addView(tv(music.artist.ifEmpty { " " }, 13f, 0xFFD0D0D0.toInt()))
                top.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
                top.addView(Bars(s, Color.WHITE).also { it.live = music.playing }, LinearLayout.LayoutParams(dp(26), dp(22)))
                ct.addView(top, LinearLayout.LayoutParams(-1, -2))
                val sk = SeekView(s); seekV = sk
                ct.addView(sk, LinearLayout.LayoutParams(-1, dp(22)).apply { setMargins(dp(18), dp(6), dp(18), 0) })
                val tl = LinearLayout(s); tl.setPadding(dp(18), 0, dp(18), 0)
                val pt = tv("0:00", 11f, gray); posTv = pt; val dt = tv("--:--", 11f, gray); durTv = dt; dt.gravity = Gravity.END
                tl.addView(pt, LinearLayout.LayoutParams(0, -2, 1f)); tl.addView(dt, LinearLayout.LayoutParams(0, -2, 1f))
                ct.addView(tl, LinearLayout.LayoutParams(-1, -2))
                sk.onDrag = { f -> posTv?.text = fmt((music.dur * f).toLong()) }
                sk.onSeek = { f -> music.seek(f); keep(12000) }
                val ctl = LinearLayout(s); ctl.gravity = Gravity.CENTER; ctl.setPadding(0, dp(6), 0, 0)
                val vs = ArrayList<View>()
                vs.add(ctl.add2(true, circ2(R.drawable.ic_music, 38, 0x26FFFFFF, Color.WHITE) { music.open(); base() }))
                vs.add(ctl.add2(true, circ2(R.drawable.ic_prev, 44, 0x26FFFFFF, Color.WHITE) { music.prev() }))
                vs.add(ctl.add2(true, circ2(if (music.playing) R.drawable.ic_pause else R.drawable.ic_play, 54, Color.WHITE, Color.BLACK) { music.toggle() }))
                vs.add(ctl.add2(true, circ2(R.drawable.ic_next, 44, 0x26FFFFFF, Color.WHITE) { music.next() }))
                vs.add(ctl.add2(true, circ2(R.drawable.ic_hot, 38, if (hot.on) 0x5522C55E else 0x26FFFFFF, Color.WHITE) { go("hotx", true, 12000) }))
                ct.addView(ctl, LinearLayout.LayoutParams(-1, -2))
                if (animIn) pop(vs)
                loop(500) { seekTick() }
                seekTick()
            }
            "hot" -> {
                val r = row(); r.setPadding(dp(10), 0, dp(10), 0)
                r.addView(icon(R.drawable.ic_hot, green), LinearLayout.LayoutParams(dp(18), dp(18)))
                r.addView(View(s), LinearLayout.LayoutParams(0, 1, 1f))
                r.addView(tv(if (hot.supported) "${hot.count()}" else "ON", 13f, Color.WHITE, true))
                ct.addView(r, LinearLayout.LayoutParams(-1, -2))
            }
            "hotx" -> {
                val head = LinearLayout(s); head.gravity = Gravity.CENTER_VERTICAL; head.setPadding(dp(18), 0, dp(12), 0)
                head.addView(icon(R.drawable.ic_hot, green), LinearLayout.LayoutParams(dp(24), dp(24)))
                val l = col(); l.setPadding(dp(12), 0, 0, 0)
                val n = hot.count()
                l.addView(tv("HOTSPOT", 10f, gray, true))
                l.addView(tv(when { !hot.on -> "Hotspot is off"; !hot.supported -> "Hotspot is on"; n == 0 -> "No devices yet"; n == 1 -> "1 device connected"; else -> "$n devices connected" }, 16f, Color.WHITE, true))
                head.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
                head.addView(circ2(R.drawable.ic_tune, 38, 0x26FFFFFF, Color.WHITE) { openTether() })
                ct.addView(head, LinearLayout.LayoutParams(-1, dp(58)))
                val rows = ArrayList<View>()
                hot.clients.take(4).forEachIndexed { i, m ->
                    val rr = LinearLayout(s); rr.gravity = Gravity.CENTER_VERTICAL; rr.setPadding(dp(20), 0, dp(20), 0)
                    val dot = View(s); dot.background = oval(green)
                    rr.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)))
                    rr.addView(tv(devName(m, i), 14f, Color.WHITE, true).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
                    rr.addView(tv(m.takeLast(8).uppercase(), 11f, gray))
                    rr.setOnClickListener { openApp("2") }
                    ct.addView(rr, LinearLayout.LayoutParams(-1, dp(38))); rows.add(rr)
                }
                val msg = when {
                    n > 4 -> "+${n - 4} more · tap a device to rename"
                    n == 0 && !hot.on -> "Turn on the hotspot to see devices"
                    n == 0 && hot.supported -> "Waiting for a device to connect"
                    n == 0 -> "Allow Location/Nearby permission in the app to list devices"
                    else -> ""
                }
                if (msg.isNotEmpty()) ct.addView(tv(msg, 11f, gray).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(26)))
                if (animIn) pop(rows)
            }
            "bt" -> {
                val r = row(); r.addView(FrameLayout(s).apply {
                    background = oval(if (btOn) 0xFF2563EB.toInt() else 0x33FFFFFF)
                    addView(icon(R.drawable.ic_bt, Color.WHITE), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
                }, LinearLayout.LayoutParams(dp(40), dp(40)))
                val l = col(); l.setPadding(dp(14), 0, 0, 0)
                l.addView(tv(if (btOn) "CONNECTED" else "DISCONNECTED", 10f, gray, true)); l.addView(tv(btName, 16f, Color.WHITE, true))
                r.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
                if (btOn) r.addView(icon(R.drawable.ic_headset, Color.WHITE), LinearLayout.LayoutParams(dp(22), dp(22)))
                ct.addView(r, LinearLayout.LayoutParams(-1, -2))
            }
            "ringer" -> {
                val r = row(); r.gravity = Gravity.CENTER
                val (res, label) = when (ringM) { AudioManager.RINGER_MODE_SILENT -> Pair(R.drawable.ic_mute, "Silent"); AudioManager.RINGER_MODE_VIBRATE -> Pair(R.drawable.ic_bell, "Vibrate"); else -> Pair(R.drawable.ic_vol, "Sound on") }
                r.addView(icon(res, Color.WHITE), LinearLayout.LayoutParams(dp(22), dp(22)))
                r.addView(tv(label, 15f, Color.WHITE, true).apply { setPadding(dp(10), 0, 0, 0) })
                ct.addView(r, LinearLayout.LayoutParams(-1, -2))
            }
            "rec", "incall" -> {
                val rec = mode == "rec"; val c = if (rec) red else green
                val d = View(s); d.background = oval(c); dotV = d
                val t = tv(timeStr(), if (expanded) 30f else 13f, Color.WHITE, true); timerTv = t
                val r = row(); r.addView(d, LinearLayout.LayoutParams(dp(if (expanded) 11 else 8), dp(if (expanded) 11 else 8)))
                if (!expanded) { t.setPadding(dp(8), 0, 0, 0); r.addView(t); ct.addView(r); return }
                val l = col(); l.addView(tv(if (rec) "RECORDING" else "ON CALL", 10f, gray, true)); l.addView(t)
                r.addView(l, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(Bars(s, c), LinearLayout.LayoutParams(dp(46), dp(28))); ct.addView(r)
                val b = row(); b.gravity = Gravity.CENTER
                b.addView(circ(0x26FFFFFF, if (RecorderService.paused) R.drawable.ic_play else R.drawable.ic_pause) { s.startService(Intent(s, RecorderService::class.java).setAction("pause")); h.postDelayed({ render() }, 200) })
                b.addView(circ(red, R.drawable.ic_stop) { s.startService(Intent(s, RecorderService::class.java).setAction("stop")) })
                b.addView(circ(0x26FFFFFF, R.drawable.ic_edit) { s.startDraw() })
                b.addView(circ(0x26FFFFFF, R.drawable.ic_cam) { s.screenshot() })
                ct.addView(b)
            }
            "call" -> {
                val r = row()
                val av = FrameLayout(s); av.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF8B5CF6.toInt(), 0xFFEC4899.toInt())).apply { shape = GradientDrawable.OVAL }
                av.addView(tv(caller.take(1).uppercase(), 20f, Color.WHITE, true), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
                r.addView(av, LinearLayout.LayoutParams(dp(48), dp(48)))
                val l = col(); l.addView(tv(caller, 18f, Color.WHITE, true)); l.addView(tv("Incoming call", 12f, gray))
                r.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(circ(red, R.drawable.ic_call_end, 46, 0) { s.doAct("reject", "isl") })
                val ans = circ(green, R.drawable.ic_call, 46, 0) { s.doAct("answer", "isl") }
                r.addView(ans); ct.addView(r)
                loop(900) { f -> val k = 1f + 0.1f * sin(f * 6.2832f); ans.scaleX = k; ans.scaleY = k }
            }
            "notif" -> {
                val r = row(); r.setOnClickListener { s.packageManager.getLaunchIntentForPackage(nPkg)?.let { s.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }; base() }
                val ic = ImageView(s); try { ic.setImageDrawable(s.packageManager.getApplicationIcon(nPkg)) } catch (_: Exception) {}
                ic.clipToOutline = true; ic.outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(11).toFloat()) } }
                r.addView(ic, LinearLayout.LayoutParams(dp(42), dp(42)))
                val l = col(); l.addView(tv(nApp.uppercase(), 10f, gray, true)); l.addView(tv(nTitle, 15f, Color.WHITE, true)); l.addView(tv(nText, 13f, 0xFFDDDDDD.toInt()))
                r.addView(l, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(tv("now", 11f, gray)); ct.addView(r)
            }
            "charge" -> {
                val r = row(); r.addView(BatteryView(s, chgPct, chgOn), LinearLayout.LayoutParams(dp(80), dp(34)))
                val l = col(); l.setPadding(dp(16), 0, 0, 0)
                l.addView(tv(chgLabel, 10f, gray, true))
                val pt = tv("0%", 26f, Color.WHITE, true); l.addView(pt); r.addView(l)
                val a = ValueAnimator.ofInt(0, chgPct); a.duration = 1100; a.interpolator = DecelerateInterpolator()
                a.addUpdateListener { pt.text = "${it.animatedValue}%" }; a.start(); fx.add(a); ct.addView(r)
            }
            "vol" -> {
                val r = row(); r.addView(icon(if (volL == 0) R.drawable.ic_mute else R.drawable.ic_vol, Color.WHITE), LinearLayout.LayoutParams(dp(22), dp(22)))
                val b = BarView(s, volL); volBar = b
                r.addView(b, LinearLayout.LayoutParams(0, dp(8), 1f).apply { leftMargin = dp(14) }); ct.addView(r)
            }
        }
        animIn = false
    }

    // ---- helpers for the new states ----
    private fun fmt(ms: Long): String { val t = ms / 1000; return String.format("%d:%02d", t / 60, t % 60) }

    private fun seekTick() {
        val sv = seekV ?: return
        val d = music.dur; val p = music.position()
        sv.set(if (d > 0) p.toFloat() / d else 0f)
        val a = fmt(p); if (posTv?.text?.toString() != a) posTv?.text = a
        val b = if (d > 0) fmt(d) else "--:--"; if (durTv?.text?.toString() != b) durTv?.text = b
    }

    private fun pop(vs: List<View>) {
        vs.forEachIndexed { i, v ->
            v.alpha = 0f; v.translationY = dp(8).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(((140 + i * 45) * spd()).toLong()).setDuration((260 * spd()).toLong()).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun LinearLayout.add2(ok: Boolean, v: View): View { if (ok) addView(v); return v }

    private fun circ2(res: Int, size: Int, bg: Int, tint: Int, click: () -> Unit): View = FrameLayout(s).apply {
        background = oval(bg); layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(8), 0, dp(8), 0) }
        addView(icon(res, tint), FrameLayout.LayoutParams(dp(size / 2 + 2), dp(size / 2 + 2), Gravity.CENTER))
        setOnClickListener { v ->
            v.animate().scaleX(.85f).scaleY(.85f).setDuration(80).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
            buzz(); click()
            if (mode == "musicx") keep(12000)
        }
    }

    private fun artView(size: Int, r: Int): View {
        val iv = ImageView(s); val b = music.art
        if (b != null) { iv.scaleType = ImageView.ScaleType.CENTER_CROP; iv.setImageBitmap(b) }
        else {
            iv.scaleType = ImageView.ScaleType.CENTER_INSIDE; iv.setBackgroundColor(0x33FFFFFF); iv.setPadding(dp(size / 4), dp(size / 4), dp(size / 4), dp(size / 4))
            iv.setImageResource(R.drawable.ic_music); iv.setColorFilter(Color.WHITE)
        }
        iv.clipToOutline = true
        iv.outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(r).toFloat()) } }
        return iv
    }

    private fun dockDo(it: DockItem) {
        when (it.act) {
            "hotset" -> openTether()
            "shot" -> { base(); h.postDelayed({ s.screenshot() }, 500) }
            "torch" -> { s.doAct("torch", "isl"); h.postDelayed({ if (mode == "dock") render() }, 350) }
            else -> { s.doAct(it.act, "isl"); h.postDelayed({ base() }, 250) }
        }
    }
}

// seekable progress bar for the music player
private class SeekView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var frac = 0f; private var drag = false
    var onSeek: ((Float) -> Unit)? = null; var onDrag: ((Float) -> Unit)? = null
    fun set(f: Float) { if (!drag) { frac = f.coerceIn(0f, 1f); invalidate() } }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val f = (e.x / maxOf(width, 1)).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { drag = true; parent?.requestDisallowInterceptTouchEvent(true); frac = f; onDrag?.invoke(f); invalidate() }
            MotionEvent.ACTION_MOVE -> { frac = f; onDrag?.invoke(f); invalidate() }
            MotionEvent.ACTION_UP -> { drag = false; frac = f; onSeek?.invoke(f); invalidate() }
            MotionEvent.ACTION_CANCEL -> { drag = false; invalidate() }
        }
        return true
    }
    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density; val th = 4f * d; val cy = height / 2f; val w = width.toFloat()
        p.style = Paint.Style.FILL; p.color = 0x33FFFFFF
        cv.drawRoundRect(0f, cy - th / 2, w, cy + th / 2, th / 2, th / 2, p)
        val x = w * frac
        p.color = Color.WHITE
        cv.drawRoundRect(0f, cy - th / 2, maxOf(x, th), cy + th / 2, th / 2, th / 2, p)
        cv.drawCircle(x.coerceIn(5f * d, w - 5f * d), cy, (if (drag) 7f else 5f) * d, p)
    }
}

// equalizer bars (recording)
private class Bars(c: Context, val col: Int) : View(c) {
    var live = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var ph = 0f; private var a: ValueAnimator? = null
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        a = ValueAnimator.ofFloat(0f, 6.2832f).apply { duration = 1100; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator(); addUpdateListener { ph = it.animatedValue as Float; invalidate() }; start() }
    }
    override fun onDetachedFromWindow() { a?.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        p.color = col; val n = 5; val g = width / (n * 2f - 1)
        for (i in 0 until n) { val amp = if (live) 0.5f + 0.5f * sin(ph + i * 1.3f) else 0.1f + 0.12f * (i % 3)
            val hh = height * (0.25f + 0.75f * amp); val x = i * g * 2; cv.drawRoundRect(x, (height - hh) / 2, x + g, (height + hh) / 2, g / 2, g / 2, p) }
    }
}

// smooth volume bar
private class BarView(c: Context, p0: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var v = 0f
    init { post { set(p0) } }
    fun set(x: Int) { ValueAnimator.ofFloat(v, x / 100f).apply { duration = 350; interpolator = DecelerateInterpolator(); addUpdateListener { v = it.animatedValue as Float; invalidate() }; start() } }
    override fun onDraw(cv: Canvas) {
        val r = height / 2f; p.color = 0x33FFFFFF; cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, p)
        p.color = Color.WHITE; cv.drawRoundRect(0f, 0f, maxOf(width * v, height.toFloat()), height.toFloat(), r, r, p)
    }
}

// liquid battery: fill rises to the real percent, wavy surface, charging shimmer + pulsing bolt, colour by level
private class BatteryView(c: Context, val pct: Int, val charging: Boolean) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val path = Path(); private val clip = Path()
    private var level = 0f; private var phase = 0f; private var sweep = 0f; private val an = ArrayList<ValueAnimator>()
    private fun go(a: ValueAnimator, f: (Float) -> Unit) { a.addUpdateListener { f(it.animatedValue as Float); invalidate() }; a.start(); an.add(a) }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        go(ValueAnimator.ofFloat(0f, pct / 100f).apply { duration = 1100; interpolator = DecelerateInterpolator() }) { level = it }
        go(ValueAnimator.ofFloat(0f, 6.2832f).apply { duration = 1400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator() }) { phase = it }
        go(ValueAnimator.ofFloat(0f, 1f).apply { duration = 1700; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator() }) { sweep = it }
    }
    override fun onDetachedFromWindow() { an.forEach { it.cancel() }; an.clear(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density; val w = width.toFloat(); val h = height.toFloat()
        val sw = 2 * d; val bw = w - 4 * d; val r = 9 * d
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = 0x99FFFFFF.toInt()
        cv.drawRoundRect(RectF(sw / 2, sw / 2, bw - sw / 2, h - sw / 2), r, r, p)
        p.style = Paint.Style.FILL; cv.drawRoundRect(RectF(bw + d, h * 0.33f, w, h * 0.67f), 2 * d, 2 * d, p)
        val inner = RectF(sw * 2, sw * 2, bw - sw * 2, h - sw * 2)
        cv.save(); clip.reset(); clip.addRoundRect(inner, r - sw, r - sw, Path.Direction.CW); cv.clipPath(clip)
        val col = if (pct < 20) 0xFFF43F5E.toInt() else if (pct < 50) 0xFFFBBF24.toInt() else 0xFF22C55E.toInt()
        val fx = inner.left + inner.width() * level
        path.reset(); path.moveTo(inner.left, inner.top)
        var y = inner.top
        while (y <= inner.bottom) { path.lineTo(fx + 2.5f * d * sin(phase + y / (4 * d)), y); y += 2 * d }
        path.lineTo(inner.left, inner.bottom); path.close()
        p.shader = LinearGradient(inner.left, 0f, inner.right, 0f, (col and 0xFFFFFF) or 0x99000000.toInt(), col, Shader.TileMode.CLAMP)
        cv.drawPath(path, p); p.shader = null
        if (charging) {
            cv.clipPath(path)
            val sx = inner.left - 30 * d + (inner.width() + 60 * d) * sweep
            p.shader = LinearGradient(sx, 0f, sx + 30 * d, 0f, intArrayOf(0x00FFFFFF, 0x77FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
            cv.drawRect(sx, inner.top, sx + 30 * d, inner.bottom, p); p.shader = null
        }
        cv.restore()
        if (charging) {
            p.color = Color.WHITE; p.alpha = (200 + 55 * sin(phase)).toInt().coerceIn(0, 255)
            val cx = bw / 2; val cy = h / 2; path.reset()
            path.moveTo(cx + 2 * d, cy - 8 * d); path.lineTo(cx - 4 * d, cy + d); path.lineTo(cx - 0.5f * d, cy + d)
            path.lineTo(cx - 2 * d, cy + 8 * d); path.lineTo(cx + 4 * d, cy - d); path.lineTo(cx + 0.5f * d, cy - d); path.close()
            cv.drawPath(path, p)
        }
    }
}
