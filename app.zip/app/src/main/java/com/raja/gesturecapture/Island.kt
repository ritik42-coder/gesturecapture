package com.raja.gesturecapture

import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.TextUtils
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.sin

// Dynamic Island: a pill that morphs (width / height / corner radius) between recording, call, message, charging and volume states.
class Island(private val s: GestureService, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null; private var card: FrameLayout? = null; private var content: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private val bgd = GradientDrawable()
    private var anim: ValueAnimator? = null
    private var mode = ""; private var expanded = false
    private var hideRun: Runnable? = null; private var ticking = false; private var regd = false
    private var recSec = -1; private var callSec = -1; private var volL = 0
    private var timerTv: TextView? = null; private var dotV: View? = null; private var volBar: BarView? = null
    private var caller = "Incoming call"; private var nPkg = ""; private var nTitle = ""; private var nText = ""; private var nApp = ""
    private var chgOn = true; private var chgPct = 0; private var lastKey = ""; private var lastKeyT = 0L
    private val gray = 0xFFAAAAAA.toInt(); private val green = 0xFF22C55E.toInt(); private val red = 0xFFF43F5E.toInt()

    // ---- settings (JSON saved by the web UI) ----
    private fun cfg() = try { JSONObject(Prefs.sp(s).getString("isl", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun num(k: String, d: Int) = cfg().optInt(k, d)
    fun on() = cfg().optBoolean("on", false)
    fun feat(f: String) = on() && cfg().optBoolean("f_$f", true)
    private fun dp(v: Int) = (v * s.resources.displayMetrics.density).toInt()
    private fun spd() = when (cfg().optString("speed", "normal")) { "slow" -> 1.6f; "fast" -> 0.7f; else -> 1f }
    private fun bounce() = when (cfg().optString("bounce", "soft")) { "none" -> 0f; "springy" -> 3.2f; else -> 1.5f }
    private fun buzz() { if (cfg().optBoolean("haptic", true)) s.getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)) }
    private fun pc(x: String) = try { Color.parseColor(x) } catch (_: Exception) { Color.BLACK }
    fun setCaller(n: String) { caller = n }

    private fun paint() {
        val c = cfg()
        when (val k = c.optString("color", "black")) {
            "accent" -> { bgd.orientation = GradientDrawable.Orientation.LEFT_RIGHT; bgd.colors = intArrayOf(pc(c.optString("ac1", "#6366f1")), pc(c.optString("ac2", "#a855f7"))) }
            else -> bgd.setColor(when (k) { "midnight" -> 0xFF0B1020.toInt(); "graphite" -> 0xFF1C1C1E.toInt(); "glass" -> 0xCC000000.toInt(); else -> Color.BLACK })
        }
        bgd.alpha = c.optInt("op", 100) * 255 / 100; bgd.setStroke(dp(1), 0x26FFFFFF)
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!feat("charge")) return
            val b = s.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            charge(i.action == Intent.ACTION_POWER_CONNECTED, (b?.getIntExtra("level", 0) ?: 0) * 100 / maxOf(b?.getIntExtra("scale", 100) ?: 100, 1))
        }
    }

    fun sync() {
        if (!on()) { destroy(); return }
        if (!regd) { s.registerReceiver(rcv, IntentFilter(Intent.ACTION_POWER_CONNECTED).apply { addAction(Intent.ACTION_POWER_DISCONNECTED) }); regd = true }
        if (root != null) { place(); paint(); render(); morph(target()) } else if (cfg().optBoolean("always", false)) base()
    }

    fun destroy() {
        if (regd) { try { s.unregisterReceiver(rcv) } catch (_: Exception) {}; regd = false }
        hideRun?.let { h.removeCallbacks(it) }; anim?.cancel(); remove(); mode = ""
    }

    private fun remove() { root?.let { try { wm.removeView(it) } catch (_: Exception) {} }; root = null; card = null; content = null }

    private fun place() {
        val p = lp ?: return
        p.x = dp(num("x", 0)); p.y = dp(num("y", 8))
        root?.let { try { wm.updateViewLayout(it, p) } catch (_: Exception) {} }
    }

    private fun ensure() {
        if (root != null) { card?.animate()?.cancel(); card?.alpha = 1f; return }
        val c = FrameLayout(s); c.background = bgd; c.elevation = dp(10).toFloat(); c.clipToOutline = true
        c.outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, bgd.cornerRadius) } }
        val ct = LinearLayout(s); ct.gravity = Gravity.CENTER; ct.orientation = LinearLayout.VERTICAL
        c.addView(ct, FrameLayout.LayoutParams(-1, -1))
        val r = FrameLayout(s); r.addView(c, FrameLayout.LayoutParams(dp(num("w", 126)), dp(num("h", 34)), Gravity.CENTER_HORIZONTAL))
        val l = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp = l; root = r; card = c; content = ct
        paint(); place(); bgd.cornerRadius = dp(num("h", 34)) / 2f
        c.alpha = 0f; c.scaleX = .6f; c.scaleY = .6f
        try { wm.addView(r, l) } catch (_: Exception) { root = null; return }
        c.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration((380 * spd()).toLong()).setInterpolator(OvershootInterpolator(bounce())).start()
        var y0 = 0f
        c.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> y0 = ev.rawY
                MotionEvent.ACTION_UP -> {
                    val dy = ev.rawY - y0
                    if (dy < -dp(18)) { if (mode == "rec" && expanded) go("rec", false) else if (mode != "call" && mode != "rec") base() }
                    else if (abs(dy) < dp(10) && mode == "rec") go("rec", !expanded)
                }
            }
            true
        }
    }

    private fun target(): Pair<Int, Int> {
        val pw = dp(num("w", 126)); val ph = dp(num("h", 34)); val ew = dp(num("ew", 340))
        return when (mode) {
            "rec" -> if (expanded) Pair(ew, dp(128)) else Pair(pw + dp(70), ph)
            "incall" -> Pair(pw + dp(80), ph)
            "call" -> Pair(ew, dp(92))
            "notif" -> Pair(ew, dp(90))
            "charge" -> Pair(dp(262), dp(72))
            "vol" -> Pair(dp(250), dp(54))
            else -> Pair(pw, ph)
        }
    }

    // spring-like morph of size and corner radius
    private fun morph(t: Pair<Int, Int>) {
        val c = card ?: return; val l = c.layoutParams as FrameLayout.LayoutParams
        val w0 = l.width; val h0 = l.height
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = (480 * spd()).toLong(); interpolator = OvershootInterpolator(bounce())
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                l.width = maxOf(dp(20), (w0 + (t.first - w0) * f).toInt()); l.height = maxOf(dp(20), (h0 + (t.second - h0) * f).toInt())
                bgd.cornerRadius = minOf(l.height / 2f, dp(34).toFloat())
                c.layoutParams = l; c.invalidateOutline()
            }
            start()
        }
    }

    fun go(m: String, ex: Boolean, ttl: Long = 0) {
        if (!on()) return
        ensure()
        val ct = content ?: return
        hideRun?.let { h.removeCallbacks(it) }; hideRun = null
        mode = m; expanded = ex
        ct.animate().cancel(); ct.alpha = 0f
        render(); morph(target())
        ct.animate().alpha(1f).setStartDelay((150 * spd()).toLong()).setDuration((220 * spd()).toLong()).start()
        buzz()
        if (ttl > 0) { val r = Runnable { base() }; hideRun = r; h.postDelayed(r, ttl) }
        if (!ticking) { ticking = true; h.postDelayed(tickR, 1000) }
    }

    // fall back to the persistent state (call > recording > on-call) or hide
    fun base() { h.post {
        when {
            s.isRinging() && feat("call") -> go("call", true)
            RecorderService.running && feat("rec") -> go("rec", false)
            s.isInCall() && feat("call") -> go("incall", false)
            else -> idle()
        }
    } }

    private fun idle() {
        mode = ""; expanded = false
        val c = card ?: return
        if (cfg().optBoolean("always", false)) { go("", false); return }
        content?.animate()?.alpha(0f)?.setStartDelay(0)?.setDuration(120)?.start()
        morph(target())
        c.animate().alpha(0f).setStartDelay((420 * spd()).toLong()).setDuration(220).withEndAction { if (mode == "") remove() }.start()
    }

    private val tickR = object : Runnable {
        override fun run() {
            val rec = RecorderService.running
            if (rec && !RecorderService.paused) recSec++
            if (s.isInCall()) callSec++ else callSec = -1
            timerTv?.text = timeStr(); dotV?.alpha = if (RecorderService.paused) .3f else if (recSec % 2 == 0) 1f else .45f
            if (mode == "call" && !s.isRinging()) base()
            if (on() && (rec || mode == "call" || mode == "incall")) h.postDelayed(this, 1000) else ticking = false
        }
    }
    private fun timeStr(): String { val n = maxOf(if (mode == "incall") callSec else recSec, 0); return String.format("%02d:%02d", n / 60, n % 60) }

    // ---- events ----
    fun recording(on: Boolean) { h.post { recSec = -1; if (on) go("rec", false) else base() } }
    fun notif(pkg: String, title: String, text: String) { h.post {
        if (mode == "call") return@post
        val key = pkg + title; val now = System.currentTimeMillis()
        if (key == lastKey && now - lastKeyT < 4000) return@post
        lastKey = key; lastKeyT = now; nPkg = pkg; nTitle = title; nText = text
        nApp = try { s.packageManager.getApplicationLabel(s.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        go("notif", true, 4500)
    } }
    fun charge(plug: Boolean, pct: Int) { h.post { if (mode != "call") { chgOn = plug; chgPct = pct; go("charge", true, 3200) } } }
    fun volume(l: Int, m: Int) { h.post {
        volL = l * 100 / maxOf(m, 1)
        if (mode == "vol") { volBar?.set(volL); hideRun?.let { h.removeCallbacks(it) }; val r = Runnable { base() }; hideRun = r; h.postDelayed(r, 1600) }
        else if (mode != "call") go("vol", true, 1600)
    } }
    fun demo(kind: String) { h.post {
        if (!on()) return@post
        when (kind) {
            "rec" -> { recSec = 73; go("rec", true, 4500) }
            "call" -> { caller = "Mom"; go("call", true, 5000) }
            "notif" -> { nPkg = s.packageName; nApp = "Messages"; nTitle = "Alex"; nText = "Hey! Are you free tonight? 🎉"; go("notif", true, 4500) }
            "charge" -> { chgOn = true; chgPct = 78; go("charge", true, 3200) }
            "vol" -> { volL = 60; go("vol", true, 1600) }
            else -> go("", false, 3500)
        }
    } }

    // ---- content ----
    private val fx = ArrayList<ValueAnimator>()
    private fun loop(ms: Long, f: (Float) -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f); a.duration = ms; a.repeatCount = ValueAnimator.INFINITE; a.interpolator = LinearInterpolator()
        a.addUpdateListener { f(it.animatedValue as Float) }; a.start(); fx.add(a)
    }
    private fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(s).apply {
        text = t; textSize = sp; setTextColor(col); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun row() = LinearLayout(s).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(16), 0) }
    private fun col() = LinearLayout(s).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(6), 0) }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun icon(res: Int, c: Int) = ImageView(s).apply { try { setImageDrawable(s.getDrawable(res)) } catch (_: Exception) {}; setColorFilter(c) }
    private fun circ(c: Int, res: Int, size: Int = 44, mt: Int = 8, click: () -> Unit) = FrameLayout(s).apply {
        background = oval(c); layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(7), dp(mt), dp(7), 0) }
        addView(icon(res, Color.WHITE), FrameLayout.LayoutParams(dp(size / 2), dp(size / 2), Gravity.CENTER)); setOnClickListener { click() }
    }

    private fun render() {
        val ct = content ?: return
        fx.forEach { it.cancel() }; fx.clear()
        ct.removeAllViews(); timerTv = null; dotV = null; volBar = null
        when (mode) {
            "rec", "incall" -> {
                val rec = mode == "rec"; val c = if (rec) red else green
                val d = View(s); d.background = oval(c); dotV = d
                val t = tv(timeStr(), if (expanded) 30f else 13f, Color.WHITE, true); timerTv = t
                val r = row(); r.addView(d, LinearLayout.LayoutParams(dp(if (expanded) 11 else 8), dp(if (expanded) 11 else 8)))
                if (!expanded) { t.setPadding(dp(8), 0, 0, 0); r.addView(t); ct.addView(r); return }
                val l = col(); l.addView(tv(if (rec) "RECORDING" else "ON CALL", 10f, gray, true)); l.addView(t)
                r.addView(l, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(Bars(s, c), LinearLayout.LayoutParams(dp(46), dp(28))); ct.addView(r)
                val b = row(); b.gravity = Gravity.CENTER
                b.addView(circ(0x26FFFFFF, if (RecorderService.paused) R.drawable.ic_play else R.drawable.ic_pause) { s.startService(Intent(s, RecorderService::class.java).setAction("pause")); h.postDelayed({ render() }, 200) })
                b.addView(circ(red, R.drawable.ic_stop) { s.startService(Intent(s, RecorderService::class.java).setAction("stop")) })
                b.addView(circ(0x26FFFFFF, R.drawable.ic_edit) { s.startDraw() })
                b.addView(circ(0x26FFFFFF, R.drawable.ic_cam) { s.screenshot() })
                ct.addView(b)
            }
            "call" -> {
                val r = row()
                val av = FrameLayout(s); av.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF8B5CF6.toInt(), 0xFFEC4899.toInt())).apply { shape = GradientDrawable.OVAL }
                av.addView(tv(caller.take(1).uppercase(), 20f, Color.WHITE, true), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
                r.addView(av, LinearLayout.LayoutParams(dp(48), dp(48)))
                val l = col(); l.addView(tv(caller, 18f, Color.WHITE, true)); l.addView(tv("Incoming call", 12f, gray))
                r.addView(l, LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(circ(red, R.drawable.ic_call_end, 46, 0) { s.doAct("reject", "isl") })
                val ans = circ(green, R.drawable.ic_call, 46, 0) { s.doAct("answer", "isl") }
                r.addView(ans); ct.addView(r)
                loop(900) { f -> val k = 1f + 0.1f * sin(f * 6.2832f); ans.scaleX = k; ans.scaleY = k }
            }
            "notif" -> {
                val r = row(); r.setOnClickListener { s.packageManager.getLaunchIntentForPackage(nPkg)?.let { s.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }; base() }
                val ic = ImageView(s); try { ic.setImageDrawable(s.packageManager.getApplicationIcon(nPkg)) } catch (_: Exception) {}
                ic.clipToOutline = true; ic.outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(11).toFloat()) } }
                r.addView(ic, LinearLayout.LayoutParams(dp(42), dp(42)))
                val l = col(); l.addView(tv(nApp.uppercase(), 10f, gray, true)); l.addView(tv(nTitle, 15f, Color.WHITE, true)); l.addView(tv(nText, 13f, 0xFFDDDDDD.toInt()))
                r.addView(l, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(tv("now", 11f, gray)); ct.addView(r)
            }
            "charge" -> {
                val r = row(); r.addView(BatteryView(s, chgPct, chgOn), LinearLayout.LayoutParams(dp(80), dp(34)))
                val l = col(); l.setPadding(dp(16), 0, 0, 0)
                l.addView(tv(if (chgOn) "CHARGING" else "UNPLUGGED", 10f, gray, true))
                val pt = tv("0%", 26f, Color.WHITE, true); l.addView(pt); r.addView(l)
                val a = ValueAnimator.ofInt(0, chgPct); a.duration = 1100; a.interpolator = DecelerateInterpolator()
                a.addUpdateListener { pt.text = "${it.animatedValue}%" }; a.start(); fx.add(a); ct.addView(r)
            }
            "vol" -> {
                val r = row(); r.addView(icon(if (volL == 0) R.drawable.ic_mute else R.drawable.ic_vol, Color.WHITE), LinearLayout.LayoutParams(dp(22), dp(22)))
                val b = BarView(s, volL); volBar = b
                r.addView(b, LinearLayout.LayoutParams(0, dp(8), 1f).apply { leftMargin = dp(14) }); ct.addView(r)
            }
        }
    }
}

// equalizer bars (recording)
private class Bars(c: Context, val col: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var ph = 0f; private var a: ValueAnimator? = null
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        a = ValueAnimator.ofFloat(0f, 6.2832f).apply { duration = 1100; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator(); addUpdateListener { ph = it.animatedValue as Float; invalidate() }; start() }
    }
    override fun onDetachedFromWindow() { a?.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        p.color = col; val n = 5; val g = width / (n * 2f - 1)
        for (i in 0 until n) { val hh = height * (0.25f + 0.75f * (0.5f + 0.5f * sin(ph + i * 1.3f))); val x = i * g * 2; cv.drawRoundRect(x, (height - hh) / 2, x + g, (height + hh) / 2, g / 2, g / 2, p) }
    }
}

// smooth volume bar
private class BarView(c: Context, p0: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var v = 0f
    init { post { set(p0) } }
    fun set(x: Int) { ValueAnimator.ofFloat(v, x / 100f).apply { duration = 350; interpolator = DecelerateInterpolator(); addUpdateListener { v = it.animatedValue as Float; invalidate() }; start() } }
    override fun onDraw(cv: Canvas) {
        val r = height / 2f; p.color = 0x33FFFFFF; cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, p)
        p.color = Color.WHITE; cv.drawRoundRect(0f, 0f, maxOf(width * v, height.toFloat()), height.toFloat(), r, r, p)
    }
}

// liquid battery: fill rises to the real percent, wavy surface, charging shimmer + pulsing bolt, colour by level
private class BatteryView(c: Context, val pct: Int, val charging: Boolean) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val path = Path(); private val clip = Path()
    private var level = 0f; private var phase = 0f; private var sweep = 0f; private val an = ArrayList<ValueAnimator>()
    private fun go(a: ValueAnimator, f: (Float) -> Unit) { a.addUpdateListener { f(it.animatedValue as Float); invalidate() }; a.start(); an.add(a) }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        go(ValueAnimator.ofFloat(0f, pct / 100f).apply { duration = 1100; interpolator = DecelerateInterpolator() }) { level = it }
        go(ValueAnimator.ofFloat(0f, 6.2832f).apply { duration = 1400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator() }) { phase = it }
        go(ValueAnimator.ofFloat(0f, 1f).apply { duration = 1700; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator() }) { sweep = it }
    }
    override fun onDetachedFromWindow() { an.forEach { it.cancel() }; an.clear(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density; val w = width.toFloat(); val h = height.toFloat()
        val sw = 2 * d; val bw = w - 4 * d; val r = 9 * d
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = 0x99FFFFFF.toInt()
        cv.drawRoundRect(RectF(sw / 2, sw / 2, bw - sw / 2, h - sw / 2), r, r, p)
        p.style = Paint.Style.FILL; cv.drawRoundRect(RectF(bw + d, h * 0.33f, w, h * 0.67f), 2 * d, 2 * d, p)
        val inner = RectF(sw * 2, sw * 2, bw - sw * 2, h - sw * 2)
        cv.save(); clip.reset(); clip.addRoundRect(inner, r - sw, r - sw, Path.Direction.CW); cv.clipPath(clip)
        val col = if (pct < 20) 0xFFF43F5E.toInt() else if (pct < 50) 0xFFFBBF24.toInt() else 0xFF22C55E.toInt()
        val fx = inner.left + inner.width() * level
        path.reset(); path.moveTo(inner.left, inner.top)
        var y = inner.top
        while (y <= inner.bottom) { path.lineTo(fx + 2.5f * d * sin(phase + y / (4 * d)), y); y += 2 * d }
        path.lineTo(inner.left, inner.bottom); path.close()
        p.shader = LinearGradient(inner.left, 0f, inner.right, 0f, (col and 0xFFFFFF) or 0x99000000.toInt(), col, Shader.TileMode.CLAMP)
        cv.drawPath(path, p); p.shader = null
        if (charging) {
            cv.clipPath(path)
            val sx = inner.left - 30 * d + (inner.width() + 60 * d) * sweep
            p.shader = LinearGradient(sx, 0f, sx + 30 * d, 0f, intArrayOf(0x00FFFFFF, 0x77FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
            cv.drawRect(sx, inner.top, sx + 30 * d, inner.bottom, p); p.shader = null
        }
        cv.restore()
        if (charging) {
            p.color = Color.WHITE; p.alpha = (200 + 55 * sin(phase)).toInt().coerceIn(0, 255)
            val cx = bw / 2; val cy = h / 2; path.reset()
            path.moveTo(cx + 2 * d, cy - 8 * d); path.lineTo(cx - 4 * d, cy + d); path.lineTo(cx - 0.5f * d, cy + d)
            path.lineTo(cx - 2 * d, cy + 8 * d); path.lineTo(cx + 4 * d, cy - d); path.lineTo(cx + 0.5f * d, cy - d); path.close()
            cv.drawPath(path, p)
        }
    }
}
