package com.raja.gesturecapture

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject

val REMOTE = "NETLIFY_URL_PLACEHOLDER"  // filled in automatically by the build
val REPO = "REPO_PLACEHOLDER"

object Prefs { fun sp(c: Context) = c.getSharedPreferences("gc", 0) }

class MainActivity : Activity() {
    lateinit var web: WebView
    var mode = "video_mic"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this); setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = WebChromeClient() // lets alert() prompts show
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) v.loadUrl("file:///android_asset/index.html") // offline fallback
            }
        }
        web.loadUrl(if (REMOTE.startsWith("http")) REMOTE else "file:///android_asset/index.html")
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.ANSWER_PHONE_CALLS), 1)
        onNewIntent(intent)
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        i?.getStringExtra("start")?.let { begin(it) }
        i?.getStringExtra("tab")?.let { t -> web.postDelayed({ web.evaluateJavascript("var b=document.querySelector('nav button[data-p=\"$t\"]');if(b)b.click()", null) }, 400) }
    }

    // ask for permissions; if Android will no longer show the dialog (denied before), open this app's settings page instead
    fun ask(perms: Array<String>, code: Int) {
        val sp = Prefs.sp(this)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) return
        val askedBefore = sp.getBoolean("asked_$code", false)
        val blocked = askedBefore && missing.none { shouldShowRequestPermissionRationale(it) }
        sp.edit().putBoolean("asked_$code", true).apply()
        if (blocked) {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
        } else requestPermissions(missing.toTypedArray(), code)
    }

    override fun onRequestPermissionsResult(rq: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rq, p, r)
        GestureService.inst?.islandRefresh()
    }

    override fun onResume() { super.onResume(); GestureService.inst?.islandRefresh() }

    fun begin(m: String) {
        mode = m; Prefs.sp(this).edit().putString("mode", m).apply()
        if (m == "audio_mic") go(0, null)
        else startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7)
    }

    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) { if (rq == 7 && rc == RESULT_OK) go(rc, d) }

    fun go(rc: Int, d: Intent?) {
        startForegroundService(Intent(this, RecorderService::class.java).putExtra("mode", mode).putExtra("code", rc).putExtra("data", d))
        moveTaskToBack(true)
    }

    fun away(f: (GestureService) -> Unit) { runOnUiThread { moveTaskToBack(true); web.postDelayed({ GestureService.inst?.let(f) }, 700) } }

    inner class Bridge {
        @JavascriptInterface fun version(): String = packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        @JavascriptInterface fun repo(): String = REPO
        @JavascriptInterface fun getVol(): String = Prefs.sp(this@MainActivity).getString("vb", "{}") ?: "{}"
        @JavascriptInterface fun setVol(j: String) { Prefs.sp(this@MainActivity).edit().putString("vb", j).apply(); runOnUiThread { GestureService.inst?.vbar?.reset() } }
        @JavascriptInterface fun volDemo() { runOnUiThread { GestureService.inst?.vbar?.demo() } }
        @JavascriptInterface fun getIsland(): String = Prefs.sp(this@MainActivity).getString("isl", "{}") ?: "{}"
        @JavascriptInterface fun setIsland(j: String) { Prefs.sp(this@MainActivity).edit().putString("isl", j).apply(); runOnUiThread { GestureService.inst?.islandRefresh() } }
        @JavascriptInterface fun agentRun(t: String) { runOnUiThread { startActivity(Intent(this@MainActivity, AgentActivity::class.java).putExtra("text", t)) } }
        @JavascriptInterface fun getAgentCfg(): String = Prefs.sp(this@MainActivity).getString("agcfg", "{}") ?: "{}"
        @JavascriptInterface fun setAgentCfg(j: String) { Prefs.sp(this@MainActivity).edit().putString("agcfg", j).apply() }
        @JavascriptInterface fun agentListen() { runOnUiThread { startActivity(Intent(this@MainActivity, AgentActivity::class.java)) } }
        @JavascriptInterface fun timerStart(sec: Int) { runOnUiThread { GestureService.inst?.island?.timerStart(sec) } }
        @JavascriptInterface fun swStart() { runOnUiThread { GestureService.inst?.island?.swStart() } }
        @JavascriptInterface fun clockReset() { runOnUiThread { GestureService.inst?.island?.clockReset() } }
        @JavascriptInterface fun islandDemo(kind: String) { runOnUiThread { GestureService.inst?.islandDemo(kind) } }
        // ---- island: music / hotspot / bluetooth ----
        @JavascriptInterface fun notifAccess(): Boolean = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        @JavascriptInterface fun openNotifAccess() { try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
        @JavascriptInterface fun hotPerm(): Boolean = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
            (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED)
        @JavascriptInterface fun askHot() { runOnUiThread {
            val want = ArrayList<String>()
            want.add(Manifest.permission.ACCESS_FINE_LOCATION); want.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) want.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            ask(want.toTypedArray(), 2)
        } }
        @JavascriptInterface fun btPerm(): Boolean = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        @JavascriptInterface fun askBt() { runOnUiThread { ask(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 3) } }
        @JavascriptInterface fun hotDevices(): String = GestureService.inst?.island?.hotJson() ?: "{\"on\":false,\"supported\":false,\"devices\":[]}"
        @JavascriptInterface fun setDevName(mac: String, name: String) { Prefs.sp(this@MainActivity).edit().putString("hn_$mac", name.trim()).apply(); runOnUiThread { GestureService.inst?.islandRefresh() } }
        @JavascriptInterface fun paused() = RecorderService.paused
        @JavascriptInterface fun getBar() = Prefs.sp(this@MainActivity).getBoolean("bar", true)
        @JavascriptInterface fun setBar(on: Boolean) { Prefs.sp(this@MainActivity).edit().putBoolean("bar", on).apply() }
        @JavascriptInterface fun appName(id: String): String = Prefs.sp(this@MainActivity).getString("appn_$id", "") ?: ""
        @JavascriptInterface fun setApp(id: String, pkg: String, label: String) { Prefs.sp(this@MainActivity).edit().putString("app_$id", pkg).putString("appn_$id", label).apply() }
        @JavascriptInterface fun apps(): String {
            val a = JSONArray()
            packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
                .sortedBy { it.first.lowercase() }.forEach { a.put(JSONObject().put("n", it.first).put("p", it.second)) }
            return a.toString()
        }
        @JavascriptInterface fun start(m: String) { runOnUiThread { begin(m) } }
        @JavascriptInterface fun stop() { startService(Intent(this@MainActivity, RecorderService::class.java).setAction("stop")) }
        @JavascriptInterface fun screenshot() { away { it.screenshot() } }
        @JavascriptInterface fun longShot() { away { it.longShot() } }
        @JavascriptInterface fun draw() { away { it.startDraw() } }
        @JavascriptInterface fun bubble() { away { it.showBubble(true) } }
        @JavascriptInterface fun gallery() { try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
        @JavascriptInterface fun recording() = RecorderService.running
        @JavascriptInterface fun a11yEnabled() = GestureService.inst != null
        @JavascriptInterface fun openA11y() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        @JavascriptInterface fun openUrl(u: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        @JavascriptInterface fun setGesture(id: String, action: String) { Prefs.sp(this@MainActivity).edit().putString("g_$id", action).apply(); GestureService.inst?.refresh() }
        // ---- draw pad (letters + arrows) and edge panel ----
        @JavascriptInterface fun getDpad(): String = Prefs.sp(this@MainActivity).getString("dpad", "{}") ?: "{}"
        @JavascriptInterface fun setDpad(j: String) { Prefs.sp(this@MainActivity).edit().putString("dpad", j).apply(); runOnUiThread { GestureService.inst?.refresh() } }
        @JavascriptInterface fun drawPad() { away { it.openPad() } }
        @JavascriptInterface fun getEdge(): String = Prefs.sp(this@MainActivity).getString("ep", "{}") ?: "{}"
        @JavascriptInterface fun setEdge(j: String) { Prefs.sp(this@MainActivity).edit().putString("ep", j).apply(); runOnUiThread { GestureService.inst?.refresh() } }
        @JavascriptInterface fun edgePanel() { away { it.openPanel() } }
        // ---- premium extras: edge lighting, charging animation, glance, app lock ----
        @JavascriptInterface fun getFx(): String = Prefs.sp(this@MainActivity).getString("fx", "{}") ?: "{}"
        @JavascriptInterface fun setFx(j: String) { Prefs.sp(this@MainActivity).edit().putString("fx", j).apply(); runOnUiThread { GestureService.inst?.refresh() } }
        @JavascriptInterface fun fxDemo(k: String) { away { it.fxDemo(k) } }
        // ---- app lock: PIN, pattern, fingerprint / face ----
        @JavascriptInterface fun fxPinSet(): Boolean = LockStore.hasPin(this@MainActivity)
        @JavascriptInterface fun fxSetPin(p: String) {
            val t = p.filter { it.isDigit() }.take(8)
            if (t.length >= 4) { LockStore.setPin(this@MainActivity, t); GestureService.inst?.al?.sync() }
        }
        @JavascriptInterface fun fxLockState(): String = LockStore.stateJson(this@MainActivity)
        @JavascriptInterface fun fxSetPattern(seq: String): Boolean {
            val ok = LockStore.setPattern(this@MainActivity, seq)
            if (ok) { LockStore.setMethod(this@MainActivity, "pattern"); GestureService.inst?.al?.sync() }
            return ok
        }
        @JavascriptInterface fun fxClearPattern() { LockStore.clearPattern(this@MainActivity) }
        @JavascriptInterface fun fxSetMethod(m: String) { LockStore.setMethod(this@MainActivity, m) }
        @JavascriptInterface fun fxSetBio(on: Boolean) { LockStore.setBio(this@MainActivity, on) }
        @JavascriptInterface fun fxSetBioAuto(on: Boolean) { LockStore.setBioAuto(this@MainActivity, on) }
        @JavascriptInterface fun fxSetHaptics(on: Boolean) { LockStore.setHaptics(this@MainActivity, on) }
        @JavascriptInterface fun fxBioInfo(): String {
            val o = JSONObject()
            o.put("fingerprint", LockBio.hasFingerprint(this@MainActivity))
            o.put("face", LockBio.hasFace(this@MainActivity))
            o.put("enrolled", LockBio.enrolled(this@MainActivity))
            return o.toString()
        }
        @JavascriptInterface fun fxOpenBioEnroll() {
            try {
                startActivity(Intent(Settings.ACTION_BIOMETRIC_ENROLL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                try { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }
        }
        @JavascriptInterface fun fxSetLockOpt(k: String, v: String) {
            val c = this@MainActivity
            when (k) {
                "shuffle" -> LockStore.setShuffle(c, v == "1")
                "hideIcon" -> LockStore.setHideIcon(c, v == "1")
                "haptics" -> LockStore.setHaptics(c, v == "1")
                "bio" -> LockStore.setBio(c, v == "1")
                "auto" -> LockStore.setBioAuto(c, v == "1")
                "accent" -> LockStore.setAccent(c, v.toIntOrNull() ?: 0)
                "relock" -> LockStore.setRelock(c, v.toIntOrNull() ?: 0)
            }
        }
        @JavascriptInterface fun fxLockNow() { runOnUiThread { GestureService.inst?.al?.lockNow() } }
        // ---- charging show ----
        @JavascriptInterface fun csInfo(): String {
            val o = JSONObject()
            o.put("on", ChargeShow.on())
            o.put("mode", ChargeShow.mode())
            o.put("secs", ChargeShow.secs())
            o.put("style", ChargeShow.style())
            o.put("dim", ChargeShow.dim())
            o.put("full", ChargeShow.autoFull())
            o.put("drift", ChargeShow.drift())
            o.put("styles", ChargeView.NAMES.joinToString("|"))
            return o.toString()
        }
        @JavascriptInterface fun csSet(on: Boolean) { ChargeShow.setOn(on) }
        @JavascriptInterface fun csMode(n: Int) { ChargeShow.setMode(n) }
        @JavascriptInterface fun csSecs(n: Int) { ChargeShow.setSecs(n) }
        @JavascriptInterface fun csStyle(n: Int) { ChargeShow.setStyle(n) }
        @JavascriptInterface fun csDim(n: Int) { ChargeShow.setDim(n) }
        @JavascriptInterface fun csFull(v: Boolean) { ChargeShow.setAutoFull(v) }
        @JavascriptInterface fun csDrift(v: Boolean) { ChargeShow.setDrift(v) }
        @JavascriptInterface fun csPreview() { runOnUiThread { try { AppCtx.ctx = this@MainActivity; ChargeShow.preview(this@MainActivity) } catch (_: Exception) {} } }
        // ---- recent apps ----
        @JavascriptInterface fun recentsShow() { runOnUiThread { GestureService.inst?.recents?.show() } }
        @JavascriptInterface fun recentsClear() { GestureService.inst?.recents?.clear() }
        @JavascriptInterface fun recentsLayout(v: String) { GestureService.inst?.recents?.setLayout(v) }
        @JavascriptInterface fun recentsInfo(): String {
            val o = JSONObject()
            val r = GestureService.inst?.recents
            o.put("count", r?.count() ?: 0)
            o.put("layout", r?.layout() ?: "stack")
            return o.toString()
        }
        // ---- fingerprint gestures ----
        @JavascriptInterface fun fgSupported(): Boolean = try { GestureService.inst?.finger?.available() == true } catch (_: Exception) { false }
        @JavascriptInterface fun fgHasSensor(): Boolean = try { GestureService.inst?.finger?.hasSensor() == true } catch (_: Exception) { LockBio.hasFingerprint(this@MainActivity) }
        @JavascriptInterface fun getFinger(): String {
            val o = JSONObject(); val sp = Prefs.sp(this@MainActivity)
            listOf("up", "down", "left", "right").forEach { o.put(it, sp.getString("fg_$it", "none")) }
            return o.toString()
        }
        @JavascriptInterface fun setFinger(dir: String, act: String) {
            Prefs.sp(this@MainActivity).edit().putString("fg_$dir", act).apply()
        }
        @JavascriptInterface fun fxLockReset() { LockStore.reset(this@MainActivity); GestureService.inst?.al?.sync() }
        @JavascriptInterface fun fxLockDemo() { runOnUiThread { GestureService.inst?.al?.demo() } }
        @JavascriptInterface fun fxLockPreview(mode: String) {
            runOnUiThread { web.loadUrl("file:///android_asset/lock.html" + if (mode.isNotEmpty()) "#" + mode else "") }
        }
        @JavascriptInterface fun getGset(): String = Prefs.sp(this@MainActivity).getString("gset", "{}") ?: "{}"
        @JavascriptInterface fun setGset(j: String) { Prefs.sp(this@MainActivity).edit().putString("gset", j).apply(); runOnUiThread { GestureService.inst?.refresh() } }
        @JavascriptInterface fun resetGestures() {
            val e = Prefs.sp(this@MainActivity).edit()
            Prefs.sp(this@MainActivity).all.keys.filter { it.startsWith("g_") }.forEach { e.remove(it) }
            e.apply(); runOnUiThread { GestureService.inst?.refresh() }
        }
        @JavascriptInterface fun getGestures(): String {
            val o = JSONObject(); val sp = Prefs.sp(this@MainActivity)
            listOf("shake", "vol_both", "vol_double", "flip", "wave", "corner", "edge_up", "edge_down", "edge_hold", "dot_dbl", "dot_up", "dot_down", "dot_left", "dot_right", "vol_up_double", "twist", "cover", "edge_dbl", "call_ear", "call_wave", "call_shake", "call_flip", "back_tap", "back_triple", "ledge_up", "ledge_down", "ledge_hold", "ledge_dbl", "pill_dbl", "pill_hold", "pill_left", "pill_right",
            "draw_C", "draw_O", "draw_S", "draw_W", "draw_M", "draw_V", "draw_U", "draw_N", "draw_Z", "draw_L",
            "draw_left", "draw_right", "draw_up", "draw_down").forEach { o.put(it, sp.getString("g_$it", "none")) }
            return o.toString()
        }
    }
}
