package com.raja.gesturecapture

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject

val REMOTE = "NETLIFY_URL_PLACEHOLDER"  // filled in automatically by the build
val REPO = "REPO_PLACEHOLDER"

object Prefs { fun sp(c: Context) = c.getSharedPreferences("gc", 0) }

class MainActivity : Activity() {
    lateinit var web: WebView
    var mode = "video_mic"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this); setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = WebChromeClient() // lets alert() prompts show
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) v.loadUrl("file:///android_asset/index.html") // offline fallback
            }
        }
        web.loadUrl(if (REMOTE.startsWith("http")) REMOTE else "file:///android_asset/index.html")
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.ANSWER_PHONE_CALLS), 1)
        onNewIntent(intent)
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        i?.getStringExtra("start")?.let { begin(it) }
    }

    fun begin(m: String) {
        mode = m; Prefs.sp(this).edit().putString("mode", m).apply()
        if (m == "audio_mic") go(0, null)
        else startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7)
    }

    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) { if (rq == 7 && rc == RESULT_OK) go(rc, d) }

    fun go(rc: Int, d: Intent?) {
        startForegroundService(Intent(this, RecorderService::class.java).putExtra("mode", mode).putExtra("code", rc).putExtra("data", d))
        moveTaskToBack(true)
    }

    fun away(f: (GestureService) -> Unit) { runOnUiThread { moveTaskToBack(true); web.postDelayed({ GestureService.inst?.let(f) }, 700) } }

    inner class Bridge {
        @JavascriptInterface fun version(): String = packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        @JavascriptInterface fun repo(): String = REPO
        @JavascriptInterface fun getVol(): String = Prefs.sp(this@MainActivity).getString("vb", "{}") ?: "{}"
        @JavascriptInterface fun setVol(j: String) { Prefs.sp(this@MainActivity).edit().putString("vb", j).apply(); runOnUiThread { GestureService.inst?.vbar?.reset() } }
        @JavascriptInterface fun volDemo() { runOnUiThread { GestureService.inst?.vbar?.demo() } }
        @JavascriptInterface fun getIsland(): String = Prefs.sp(this@MainActivity).getString("isl", "{}") ?: "{}"
        @JavascriptInterface fun setIsland(j: String) { Prefs.sp(this@MainActivity).edit().putString("isl", j).apply(); runOnUiThread { GestureService.inst?.islandRefresh() } }
        @JavascriptInterface fun islandDemo(kind: String) { runOnUiThread { GestureService.inst?.islandDemo(kind) } }
        @JavascriptInterface fun paused() = RecorderService.paused
        @JavascriptInterface fun getBar() = Prefs.sp(this@MainActivity).getBoolean("bar", true)
        @JavascriptInterface fun setBar(on: Boolean) { Prefs.sp(this@MainActivity).edit().putBoolean("bar", on).apply() }
        @JavascriptInterface fun appName(id: String): String = Prefs.sp(this@MainActivity).getString("appn_$id", "") ?: ""
        @JavascriptInterface fun setApp(id: String, pkg: String, label: String) { Prefs.sp(this@MainActivity).edit().putString("app_$id", pkg).putString("appn_$id", label).apply() }
        @JavascriptInterface fun apps(): String {
            val a = JSONArray()
            packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
                .sortedBy { it.first.lowercase() }.forEach { a.put(JSONObject().put("n", it.first).put("p", it.second)) }
            return a.toString()
        }
        @JavascriptInterface fun start(m: String) { runOnUiThread { begin(m) } }
        @JavascriptInterface fun stop() { startService(Intent(this@MainActivity, RecorderService::class.java).setAction("stop")) }
        @JavascriptInterface fun screenshot() { away { it.screenshot() } }
        @JavascriptInterface fun longShot() { away { it.longShot() } }
        @JavascriptInterface fun draw() { away { it.startDraw() } }
        @JavascriptInterface fun bubble() { away { it.showBubble(true) } }
        @JavascriptInterface fun gallery() { try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
        @JavascriptInterface fun recording() = RecorderService.running
        @JavascriptInterface fun a11yEnabled() = GestureService.inst != null
        @JavascriptInterface fun openA11y() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        @JavascriptInterface fun openUrl(u: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        @JavascriptInterface fun setGesture(id: String, action: String) { Prefs.sp(this@MainActivity).edit().putString("g_$id", action).apply(); GestureService.inst?.refresh() }
        @JavascriptInterface fun getGestures(): String {
            val o = JSONObject(); val sp = Prefs.sp(this@MainActivity)
            listOf("shake", "vol_both", "vol_double", "flip", "wave", "corner", "edge_up", "edge_down", "edge_hold", "dot_dbl", "dot_up", "dot_down", "dot_left", "dot_right", "vol_up_double", "twist", "cover", "edge_dbl", "call_ear", "call_wave", "call_shake", "call_flip").forEach { o.put(it, sp.getString("g_$it", "none")) }
            return o.toString()
        }
    }
}
