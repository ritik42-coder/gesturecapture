package com.raja.gesturecapture

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import org.json.JSONObject

val REMOTE = "NETLIFY_URL_PLACEHOLDER"  // filled in automatically by the build
val REPO = "REPO_PLACEHOLDER"

object Prefs { fun sp(c: Context) = c.getSharedPreferences("gc", 0) }

class MainActivity : Activity() {
    lateinit var web: WebView
    var mode = "video_mic"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this); setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) v.loadUrl("file:///android_asset/index.html") // offline fallback
            }
        }
        web.loadUrl(if (REMOTE.startsWith("http")) REMOTE else "file:///android_asset/index.html")
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        onNewIntent(intent)
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        i?.getStringExtra("start")?.let { begin(it) }
    }

    fun begin(m: String) {
        mode = m; Prefs.sp(this).edit().putString("mode", m).apply()
        if (m == "audio_mic") go(0, null)
        else startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7)
    }

    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) { if (rq == 7 && rc == RESULT_OK) go(rc, d) }

    fun go(rc: Int, d: Intent?) = startForegroundService(
        Intent(this, RecorderService::class.java).putExtra("mode", mode).putExtra("code", rc).putExtra("data", d))

    inner class Bridge {
        @JavascriptInterface fun version(): String = packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        @JavascriptInterface fun repo(): String = REPO
        @JavascriptInterface fun start(m: String) { runOnUiThread { begin(m) } }
        @JavascriptInterface fun stop() { startService(Intent(this@MainActivity, RecorderService::class.java).setAction("stop")) }
        @JavascriptInterface fun screenshot() { GestureService.inst?.screenshot() }
        @JavascriptInterface fun recording() = RecorderService.running
        @JavascriptInterface fun a11yEnabled() = GestureService.inst != null
        @JavascriptInterface fun openA11y() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        @JavascriptInterface fun openUrl(u: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        @JavascriptInterface fun setGesture(id: String, action: String) { Prefs.sp(this@MainActivity).edit().putString("g_$id", action).apply() }
        @JavascriptInterface fun getGestures(): String {
            val o = JSONObject(); val sp = Prefs.sp(this@MainActivity)
            listOf("shake", "vol_both", "vol_double").forEach { o.put(it, sp.getString("g_$it", "none")) }
            return o.toString()
        }
    }
}
