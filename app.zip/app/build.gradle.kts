plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.raja.gesturecapture"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.raja.gesturecapture"
        minSdk = 30; targetSdk = 34
        versionCode = (findProperty("vc") ?: "1").toString().toInt()
        versionName = (findProperty("vn") ?: "1.0.0").toString()
    }
    signingConfigs {
        create("rel") {
            val p = System.getenv("KS_PATH")
            if (p != null) { storeFile = file(p); storePassword = System.getenv("KS_PASS"); keyAlias = System.getenv("KS_ALIAS"); keyPassword = System.getenv("KS_PASS") }
        }
    }
    buildTypes { release { signingConfig = signingConfigs.getByName(if (System.getenv("KS_PATH") != null) "rel" else "debug") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // fingerprint + face: the standard biometric prompt (the platform BiometricPrompt constructors
    // are hidden from apps, this is the supported way in)
    implementation("androidx.biometric:biometric:1.1.0")
}
